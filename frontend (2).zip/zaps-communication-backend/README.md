# Zaps Communication Platform

Centralized communication platform for EMAIL, SMS, PUSH, and WHATSAPP APIs.

## Phase 1 - Foundation

Completed foundation pieces:

- Spring Boot Java 17 backend under `com.zaps.communication`
- MySQL, Kafka, Validation, Mail, Security JWT dependencies
- Request ID filter using `X-Request-Id`
- Standard API response with `success`, `message`, `requestId`, and `data`
- Global exception handling without stack traces in API responses
- Flyway migration folder
- Dockerfile and Docker Compose for MySQL and backend
- Frontend scaffold expected at sibling folder `zaps-communication-frontend`

## Run Backend

```powershell
.\mvnw.cmd spring-boot:run
```

Backend runs on:

```text
http://localhost:5000
```

## Docker

```powershell
docker compose up -d --build
```

Docker exposes:

```text
Backend: http://localhost:5000
MySQL: localhost:3307 -> container mysql:3306
Kafka: uses existing host Kafka at localhost:9092
```

## Environment

```text
MYSQL_URL=jdbc:mysql://localhost:3307/zaps_communication
MYSQL_USERNAME=root
MYSQL_PASSWORD=root
KAFKA_BOOTSTRAP_SERVERS=localhost:9092
JWT_SECRET=0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef
```

Inside Docker, the backend connects to host Kafka with `host.docker.internal:9092`.

If Kafka is running in Docker, configure its advertised listener to a Docker/host reachable address:

```text
advertised.listeners=PLAINTEXT://host.docker.internal:9092
```

## Standard Response

```json
{
  "success": true,
  "message": "Success",
  "requestId": "uuid",
  "data": {}
}
```

## Sample

See `samples/phase1-health.http`.

## Phase 2 - Project Onboarding

Project is the production platform name for an external or internal application such as `CRM`, `Valet`, `Booking`, or `Payment`.

Completed Phase 2 pieces:

- `projects` table
- `services` table reuse for EMAIL, SMS, PUSH, WHATSAPP
- `countries` table with default seed values
- `project_services` table with independent service enablement
- `project_countries` table with default country support
- `users` table with `SUPER_ADMIN` and `PROJECT_ADMIN`
- `POST /api/v1/projects`
- `GET /api/v1/projects`
- API key generation with hash-only storage
- Plain API key returned once during onboarding

### Onboard Project

```http
POST /api/v1/projects
Content-Type: application/json
```

```json
{
  "projectCode": "CRM",
  "projectName": "Zaps CRM",
  "description": "CRM project using communication APIs",
  "services": ["EMAIL", "SMS"],
  "countries": ["IN", "US"],
  "defaultCountry": "IN"
}
```

See `samples/phase2-project-onboarding.http`.

## Phases 3-14 - Platform Expansion

Implemented in this pass:

- Per-project service controls for `DIRECT_PAYLOAD` and `TEMPLATE_PAYLOAD`
- Country validation on communication APIs
- Provider model for EMAIL and SMS with priority-based failover
- Encrypted credential storage hook through `CredentialEncryptionService`
- Template rendering with `{{variableName}}` replacements
- Direct and template EMAIL APIs
- Direct and template SMS APIs
- Direct and template PUSH APIs
- Direct and template WHATSAPP APIs
- Kafka topics:
  - `communication.email.events`
  - `communication.sms.events`
  - `communication.email.retry`
  - `communication.sms.retry`
  - `communication.email.dlt`
  - `communication.sms.dlt`
  - `communication.push.events`
  - `communication.whatsapp.events`
  - `communication.push.retry`
  - `communication.whatsapp.retry`
  - `communication.push.dlt`
  - `communication.whatsapp.dlt`
- Async consumers for email and SMS
- `email_logs`, `sms_logs`, and `provider_attempts`
- Provider result mapping into delivery status
- Consumer catch blocks so Kafka listeners do not crash on provider errors
- API key and secret-safe error responses
- Rate limiting for communication APIs
- Actuator health/metrics exposure
- Dashboard summary API
- Frontend dashboard shell with project/service/log visibility
- Postman collection at `postman/ZapsCommunicationPlatform.postman_collection.json`

## Communication API Samples

See `samples/phase7-communication-apis.http`.
See `samples/phase_all_push_whatsapp.http`.
See `samples/phase_all_auth.http`.

## Default Admin

The development seed creates a default super admin if it does not exist:

```text
email: admin@zaps.local
password: Admin@123
role: SUPER_ADMIN
```

Login:

```http
POST /api/v1/auth/login
```

```json
{
  "email": "admin@zaps.local",
  "password": "Admin@123"
}
```

## Dashboard

```http
GET /api/v1/dashboard/summary
```

Response:

```json
{
  "success": true,
  "message": "Dashboard summary fetched",
  "requestId": "uuid",
  "data": {
    "totalProjects": 1,
    "activeProjects": 1,
    "emails": 10,
    "sms": 5,
    "failed": 0,
    "pending": 2,
    "kafkaQueue": 0
  }
}
```
