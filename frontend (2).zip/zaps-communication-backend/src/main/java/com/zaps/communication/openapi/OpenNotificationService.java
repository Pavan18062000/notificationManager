package com.zaps.communication.openapi;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaps.communication.channel.entity.Channel;
import com.zaps.communication.channel.repository.ChannelRepository;
import com.zaps.communication.common.enums.ChannelCode;
import com.zaps.communication.common.enums.NotificationStatus;
import com.zaps.communication.country.entity.Country;
import com.zaps.communication.country.repository.CountryRepository;
import com.zaps.communication.event.entity.EventType;
import com.zaps.communication.event.repository.EventTypeRepository;
import com.zaps.communication.notification.entity.NotificationLog;
import com.zaps.communication.notification.entity.NotificationRequest;
import com.zaps.communication.notification.dto.NotificationDeliveryJob;
import com.zaps.communication.notification.repository.NotificationLogRepository;
import com.zaps.communication.notification.repository.NotificationRequestRepository;
import com.zaps.communication.openapi.dto.OpenApiRequestDto;
import com.zaps.communication.project.entity.Project;
import com.zaps.communication.routing.entity.NotificationRoute;
import com.zaps.communication.routing.repository.NotificationRouteRepository;

@Service
public class OpenNotificationService {
    private static final Logger log = LoggerFactory.getLogger(OpenNotificationService.class);
    private static final Pattern TEMPLATE_PATTERN = Pattern.compile("\\{\\{\\s*([a-zA-Z0-9_.-]+)\\s*}}");
    private static final DateTimeFormatter REQUEST_TS = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    private final CountryRepository countryRepository;
    private final EventTypeRepository eventTypeRepository;
    private final ChannelRepository channelRepository;
    private final NotificationRouteRepository notificationRouteRepository;
    private final NotificationRequestRepository notificationRequestRepository;
    private final NotificationLogRepository notificationLogRepository;
    private final ObjectMapper objectMapper;
    private final ObjectProvider<RabbitTemplate> rabbitTemplateProvider;
    private final ObjectProvider<StringRedisTemplate> redisTemplateProvider;

    public OpenNotificationService(
            CountryRepository countryRepository,
            EventTypeRepository eventTypeRepository,
            ChannelRepository channelRepository,
            NotificationRouteRepository notificationRouteRepository,
            NotificationRequestRepository notificationRequestRepository,
            NotificationLogRepository notificationLogRepository,
            ObjectMapper objectMapper,
            ObjectProvider<RabbitTemplate> rabbitTemplateProvider,
            ObjectProvider<StringRedisTemplate> redisTemplateProvider) {
        this.countryRepository = countryRepository;
        this.eventTypeRepository = eventTypeRepository;
        this.channelRepository = channelRepository;
        this.notificationRouteRepository = notificationRouteRepository;
        this.notificationRequestRepository = notificationRequestRepository;
        this.notificationLogRepository = notificationLogRepository;
        this.objectMapper = objectMapper;
        this.rabbitTemplateProvider = rabbitTemplateProvider;
        this.redisTemplateProvider = redisTemplateProvider;
    }

    @Transactional
    public OpenApiProcessResult process(Project project, OpenApiRequestDto request, String idempotencyKey) {
        return processInternal(project, request, idempotencyKey, true);
    }

    @Transactional
    public OpenApiProcessResult processDirect(Project project, OpenApiRequestDto request, String idempotencyKey) {
        return processInternal(project, request, idempotencyKey, false);
    }

    private OpenApiProcessResult processInternal(Project project, OpenApiRequestDto request, String idempotencyKey, boolean applyTemplateRendering) {
        ChannelCode channelCode = resolveChannel(request.getChannel());
        validateChannelFields(channelCode, request);

        Country country = countryRepository.findByCountryCode(request.getCountryCode().trim().toUpperCase())
                .filter(Country::isActive)
                .orElseThrow(() -> new OpenApiException(HttpStatus.BAD_REQUEST, OpenApiErrorCode.INVALID_COUNTRY, "Invalid country"));

        EventType eventType = eventTypeRepository.findByEventCode(request.getEventCode().trim().toUpperCase())
                .orElseThrow(() -> new OpenApiException(HttpStatus.BAD_REQUEST, OpenApiErrorCode.INVALID_EVENT, "Invalid event"));

        Channel channel = channelRepository.findByCode(channelCode)
                .filter(Channel::isActive)
                .orElseThrow(() -> new OpenApiException(HttpStatus.BAD_REQUEST, OpenApiErrorCode.INVALID_CHANNEL, "Invalid channel"));

        NotificationRoute selectedRoute = resolveRoute(project, country, channel, eventType);
        if (selectedRoute == null) {
            throw new OpenApiException(HttpStatus.BAD_REQUEST, OpenApiErrorCode.PROVIDER_NOT_CONFIGURED, "No active notification route configured");
        }

        applyRateLimit(project, channelCode, selectedRoute.getRateLimitPerMinute());
        OpenApiProcessResult existing = resolveIdempotency(project, idempotencyKey);
        if (existing != null) return existing;

        String renderedBody = applyTemplateRendering
                ? render(request.getBody(), request.getTemplateData())
                : request.getBody();
        String renderedSubject = request.getSubject() == null
                ? null
                : (applyTemplateRendering ? render(request.getSubject(), request.getTemplateData()) : request.getSubject());
        String requestId = "REQ-" + LocalDateTime.now().format(REQUEST_TS) + "-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        String requestUuid = UUID.randomUUID().toString();

        NotificationRequest nr = new NotificationRequest();
        nr.setRequestId(requestId);
        nr.setRequestUuid(requestUuid);
        nr.setProject(project);
        nr.setCountry(country);
        nr.setEventType(eventType);
        nr.setStatus(NotificationStatus.QUEUED);
        Map<String, Object> rendered = new HashMap<>();
        rendered.put("subject", renderedSubject);
        rendered.put("body", renderedBody);
        Map<String, Object> payloadData = new HashMap<>();
        payloadData.put("original", request);
        payloadData.put("rendered", rendered);
        nr.setPayload(toJson(payloadData));
        nr = notificationRequestRepository.save(nr);

        NotificationLog log = new NotificationLog();
        log.setRequest(nr);
        log.setProject(project);
        log.setCountry(country);
        log.setChannel(channel);
        log.setProvider(selectedRoute.getProvider());
        log.setTemplate(null);
        log.setRecipient(request.getRecipient().trim());
        log.setRetryCount(0);
        log.setAttemptNo(1);
        log.setProviderCode(selectedRoute.getProvider().getProviderCode());
        log.setStatus(NotificationStatus.QUEUED);
        log = notificationLogRepository.save(log);

        publish(requestId, project, country, eventType, channelCode, request, renderedSubject, renderedBody, log.getId(), selectedRoute);
        storeIdempotency(project, idempotencyKey, requestId);
        return OpenApiProcessResult.queued(requestId);
    }

    private void publish(String requestId, Project project, Country country, EventType eventType, ChannelCode channelCode, OpenApiRequestDto request,
                         String renderedSubject, String renderedBody, Long logId, NotificationRoute route) {
        RabbitTemplate rabbitTemplate = rabbitTemplateProvider.getIfAvailable();
        if (rabbitTemplate == null) return;
        String routingKey = "notification." + channelCode.name().toLowerCase();
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("providerApiKey", route.getProviderApiKey());
        metadata.put("fromEmail", route.getFromEmail());
        metadata.put("senderId", route.getSenderId());
        metadata.put("routeId", route.getId());
        metadata.put("providerAccountKey", route.getProviderAccountKey() == null ? "default" : route.getProviderAccountKey());
        NotificationDeliveryJob job = NotificationDeliveryJob.builder()
                .requestId(requestId)
                .deliveryId(logId)
                .projectId(project.getId())
                .projectCode(project.getProjectCode())
                .countryCode(country.getCountryCode())
                .eventCode(eventType.getEventCode())
                .channel(channelCode.name())
                .providerCode(route.getProvider().getProviderCode())
                .recipient(request.getRecipient())
                .subject(renderedSubject)
                .body(renderedBody)
                .templateData(request.getTemplateData())
                .metadata(metadata)
                .providerApiKey(route.getProviderApiKey())
                .fromEmail(route.getFromEmail())
                .correlationId(UUID.randomUUID().toString())
                .createdAt(System.currentTimeMillis())
                .build();
        rabbitTemplate.convertAndSend("notification.exchange", routingKey, job);
    }

    private NotificationRoute resolveRoute(Project project, Country country, Channel channel, EventType eventType) {
        List<NotificationRoute> exact = notificationRouteRepository.findByProjectAndCountryAndChannelAndEventTypeAndEnabledTrueOrderByPriorityAsc(project, country, channel, eventType);
        if (!exact.isEmpty()) return exact.get(0);
        List<NotificationRoute> countryGenericEvent = notificationRouteRepository.findByProjectAndCountryAndChannelAndEventTypeIsNullAndEnabledTrueOrderByPriorityAsc(project, country, channel);
        if (!countryGenericEvent.isEmpty()) return countryGenericEvent.get(0);
        List<NotificationRoute> globalCountryExactEvent = notificationRouteRepository.findByProjectAndCountryIsNullAndChannelAndEventTypeAndEnabledTrueOrderByPriorityAsc(project, channel, eventType);
        if (!globalCountryExactEvent.isEmpty()) return globalCountryExactEvent.get(0);
        List<NotificationRoute> globalGeneric = notificationRouteRepository.findByProjectAndCountryIsNullAndChannelAndEventTypeIsNullAndEnabledTrueOrderByPriorityAsc(project, channel);
        return globalGeneric.isEmpty() ? null : globalGeneric.get(0);
    }

    private OpenApiProcessResult resolveIdempotency(Project project, String idempotencyKey) {
        if (idempotencyKey == null || idempotencyKey.isBlank()) return null;
        StringRedisTemplate redis = redisTemplateProvider.getIfAvailable();
        if (redis == null) return null;
        String key = "idempotency:" + project.getProjectCode() + ":" + idempotencyKey.trim();
        try {
            String requestId = redis.opsForValue().get(key);
            if (requestId == null || requestId.isBlank()) return null;
            return OpenApiProcessResult.accepted(requestId);
        } catch (Exception ex) {
            log.warn("Redis unavailable for idempotency lookup, continuing without idempotency cache. project={}", project.getProjectCode());
            return null;
        }
    }

    private void storeIdempotency(Project project, String idempotencyKey, String requestId) {
        if (idempotencyKey == null || idempotencyKey.isBlank()) return;
        StringRedisTemplate redis = redisTemplateProvider.getIfAvailable();
        if (redis == null) return;
        String key = "idempotency:" + project.getProjectCode() + ":" + idempotencyKey.trim();
        try {
            redis.opsForValue().setIfAbsent(key, requestId, Duration.ofHours(24));
        } catch (Exception ex) {
            log.warn("Redis unavailable for idempotency store, continuing. project={}", project.getProjectCode());
        }
    }

    private void applyRateLimit(Project project, ChannelCode channelCode, Integer rateLimit) {
        if (rateLimit == null || rateLimit <= 0) return;
        StringRedisTemplate redis = redisTemplateProvider.getIfAvailable();
        if (redis == null) return;
        String key = "rate:project:" + project.getProjectCode() + ":" + channelCode.name();
        try {
            Long count = redis.opsForValue().increment(key);
            if (count != null && count == 1L) redis.expire(key, Duration.ofMinutes(1));
            if (count != null && count > rateLimit) {
                throw new OpenApiException(HttpStatus.TOO_MANY_REQUESTS, OpenApiErrorCode.RATE_LIMIT_EXCEEDED,
                        "Rate limit exceeded for " + channelCode.name() + ". Please try again later.");
            }
        } catch (OpenApiException ex) {
            throw ex;
        } catch (Exception ex) {
            log.warn("Redis unavailable for rate limit, skipping rate-limit check. project={} channel={}", project.getProjectCode(), channelCode);
        }
    }

    private void validateChannelFields(ChannelCode channelCode, OpenApiRequestDto request) {
        if (request.getRecipient() == null || request.getRecipient().isBlank()) {
            throw new OpenApiException(HttpStatus.BAD_REQUEST, OpenApiErrorCode.VALIDATION_FAILED, "Recipient is required");
        }
        if (request.getBody() == null || request.getBody().isBlank()) {
            throw new OpenApiException(HttpStatus.BAD_REQUEST, OpenApiErrorCode.VALIDATION_FAILED, "Body is required");
        }
        if ((channelCode == ChannelCode.EMAIL || channelCode == ChannelCode.PUSH) && (request.getSubject() == null || request.getSubject().isBlank())) {
            throw new OpenApiException(HttpStatus.BAD_REQUEST, OpenApiErrorCode.VALIDATION_FAILED, "Subject is required");
        }
    }

    private ChannelCode resolveChannel(String channel) {
        try {
            return ChannelCode.valueOf(channel.trim().toUpperCase());
        } catch (Exception e) {
            throw new OpenApiException(HttpStatus.BAD_REQUEST, OpenApiErrorCode.INVALID_CHANNEL, "Invalid channel");
        }
    }

    private String render(String template, Map<String, Object> data) {
        if (template == null) return null;
        Matcher matcher = TEMPLATE_PATTERN.matcher(template);
        StringBuffer output = new StringBuffer();
        while (matcher.find()) {
            String key = matcher.group(1);
            Object value = data == null ? null : data.get(key);
            if (value == null) {
                throw new OpenApiException(HttpStatus.BAD_REQUEST, OpenApiErrorCode.VALIDATION_FAILED, "Missing template value for " + key);
            }
            matcher.appendReplacement(output, Matcher.quoteReplacement(String.valueOf(value)));
        }
        matcher.appendTail(output);
        return output.toString();
    }

    private String toJson(Object value) {
        try {
            return objectMapper.writeValueAsString(value);
        } catch (JsonProcessingException e) {
            throw new OpenApiException(HttpStatus.BAD_REQUEST, OpenApiErrorCode.VALIDATION_FAILED, "Invalid payload");
        }
    }

    public record OpenApiProcessResult(String requestId, String status) {
        public static OpenApiProcessResult accepted(String requestId) {
            return new OpenApiProcessResult(requestId, "ACCEPTED");
        }
        public static OpenApiProcessResult queued(String requestId) {
            return new OpenApiProcessResult(requestId, "QUEUED");
        }
    }
}
