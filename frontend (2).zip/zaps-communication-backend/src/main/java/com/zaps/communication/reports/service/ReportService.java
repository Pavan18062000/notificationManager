package com.zaps.communication.reports.service;

import java.util.Map;

import com.zaps.communication.reports.dto.ReportFilterRequest;

public interface ReportService {
    Object getSummary(ReportFilterRequest filter, String authorizationHeader);
    Object getTrend(ReportFilterRequest filter, String authorizationHeader);
    Object getStatusDistribution(ReportFilterRequest filter, String authorizationHeader);
    Object getChannelSummary(ReportFilterRequest filter, String authorizationHeader);
    Object getProviderSummary(ReportFilterRequest filter, String authorizationHeader);
    Object getProjectSummary(ReportFilterRequest filter, String authorizationHeader);
    Object getEventSummary(ReportFilterRequest filter, String authorizationHeader);
    Map<String, Object> getNotificationDetails(ReportFilterRequest filter, String authorizationHeader);
    Object getNotificationDetailsByRequestId(String requestId, String authorizationHeader);
    Map<String, Object> getFilterLookups(String authorizationHeader, Long projectId);
}
