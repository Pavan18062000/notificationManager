package com.zaps.communication.event.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zaps.communication.event.entity.EventType;

public interface EventTypeRepository extends JpaRepository<EventType, Long> {
    Optional<EventType> findByEventCode(String eventCode);
}
