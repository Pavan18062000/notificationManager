package com.zaps.communication.reports.dto;

import java.time.LocalDateTime;
import java.util.List;

import lombok.Data;

@Data
public class NotificationDetailResponse {
    private String requestId;
    private String requestUuid;
    private Long projectId;
    private String projectCode;
    private String projectName;
    private Long countryId;
    private String countryCode;
    private String countryName;
    private Long eventTypeId;
    private String eventCode;
    private String eventName;
    private String requestStatus;
    private String payload;
    private LocalDateTime requestCreatedAt;

    private Long logId;
    private String channel;
    private String provider;
    private String recipient;
    private String status;
    private Integer attemptNo;
    private Integer retryCount;
    private Integer httpStatus;
    private String providerMessageId;
    private String providerResponse;
    private String errorMessage;
    private Long latencyMs;
    private LocalDateTime createdAt;
    private LocalDateTime sentAt;
    private LocalDateTime failedAt;

    private List<NotificationDetailResponse> attempts;
}

