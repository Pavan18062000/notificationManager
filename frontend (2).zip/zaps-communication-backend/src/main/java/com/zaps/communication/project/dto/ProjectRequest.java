package com.zaps.communication.project.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ProjectRequest {
    @NotBlank private String projectCode;
    @NotBlank private String projectName;
    private Boolean active = true;
}
