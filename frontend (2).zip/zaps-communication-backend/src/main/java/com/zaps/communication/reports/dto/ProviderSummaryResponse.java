package com.zaps.communication.reports.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ProviderSummaryResponse {
    private Long providerId;
    private String provider;
    private long count;
    private double avgLatencyMs;
}

