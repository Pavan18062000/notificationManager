package com.zaps.communication.user.service;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import com.zaps.communication.common.exception.BadRequestException;
import com.zaps.communication.user.dto.LoginRequest;
import com.zaps.communication.user.dto.LoginResponse;
import com.zaps.communication.user.dto.UserResponse;
import com.zaps.communication.user.entity.User;
import com.zaps.communication.user.repository.UserRepository;

@Service
public class AuthService {
    private static final String AUTH_PREFIX = "Bearer ";
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final Map<String, Long> tokenStore = new ConcurrentHashMap<>();

    public AuthService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public LoginResponse login(LoginRequest request) {
        User user = userRepository.findByEmailIgnoreCase(request.getEmail())
                .orElseThrow(() -> new BadRequestException("Invalid email or password"));
        if (!user.isActive()) throw new BadRequestException("User is inactive");
        if (!passwordEncoder.matches(request.getPassword(), user.getPasswordHash())) {
            throw new BadRequestException("Invalid email or password");
        }
        String token = UUID.randomUUID().toString();
        tokenStore.put(token, user.getId());
        return LoginResponse.builder().token(token).user(toUserResponse(user)).build();
    }

    public void logout(String authorizationHeader) {
        parseToken(authorizationHeader).ifPresent(tokenStore::remove);
    }

    public User requireUser(String authorizationHeader) {
        String token = parseToken(authorizationHeader)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Missing Authorization header"));
        Long userId = tokenStore.get(token);
        if (userId == null) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid or expired token");
        return userRepository.findById(userId).orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "User not found"));
    }

    public UserResponse me(String authorizationHeader) {
        return toUserResponse(requireUser(authorizationHeader));
    }

    public UserResponse toUserResponse(User user) {
        return UserResponse.builder()
                .id(user.getId())
                .email(user.getEmail())
                .role(user.getRole())
                .active(user.isActive())
                .projectId(user.getProject() != null ? user.getProject().getId() : null)
                .projectCode(user.getProject() != null ? user.getProject().getProjectCode() : null)
                .projectName(user.getProject() != null ? user.getProject().getProjectName() : null)
                .build();
    }

    private Optional<String> parseToken(String authorizationHeader) {
        if (authorizationHeader == null || !authorizationHeader.startsWith(AUTH_PREFIX)) return Optional.empty();
        return Optional.of(authorizationHeader.substring(AUTH_PREFIX.length()).trim());
    }
}
