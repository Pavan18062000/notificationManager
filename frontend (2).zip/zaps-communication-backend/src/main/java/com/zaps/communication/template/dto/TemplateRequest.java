package com.zaps.communication.template.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class TemplateRequest {
    @NotNull private Long projectId;
    @NotNull private Long countryId;
    @NotNull private Long channelId;
    @NotNull private Long eventTypeId;
    @NotBlank private String templateName;
    private String language;
    private String subject;
    @NotBlank private String body;
    private Boolean active = true;
}
