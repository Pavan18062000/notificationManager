package com.zaps.communication.template.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zaps.communication.channel.entity.Channel;
import com.zaps.communication.country.entity.Country;
import com.zaps.communication.event.entity.EventType;
import com.zaps.communication.project.entity.Project;
import com.zaps.communication.template.entity.Template;

public interface TemplateRepository extends JpaRepository<Template, Long> {
    Optional<Template> findByProjectAndCountryAndChannelAndEventTypeAndActiveTrue(Project project, Country country, Channel channel, EventType eventType);
    List<Template> findByProjectId(Long projectId);
    List<Template> findByProjectIdAndCountryIdAndChannelIdAndEventTypeId(Long projectId, Long countryId, Long channelId, Long eventTypeId);
}
