package com.zaps.communication.reports.repository;

import java.util.List;
import java.util.Map;

import com.zaps.communication.reports.dto.*;

public interface ReportRepository {
    NotificationSummaryResponse fetchSummary(ReportFilterRequest filter, Long scopedProjectId);
    List<NotificationTrendResponse> fetchTrend(ReportFilterRequest filter, Long scopedProjectId);
    List<StatusDistributionResponse> fetchStatusDistribution(ReportFilterRequest filter, Long scopedProjectId);
    List<ChannelSummaryResponse> fetchChannelSummary(ReportFilterRequest filter, Long scopedProjectId);
    List<ProviderSummaryResponse> fetchProviderSummary(ReportFilterRequest filter, Long scopedProjectId);
    List<ProjectSummaryResponse> fetchProjectSummary(ReportFilterRequest filter, Long scopedProjectId);
    List<EventSummaryResponse> fetchEventSummary(ReportFilterRequest filter, Long scopedProjectId);
    List<NotificationDetailResponse> fetchNotificationDetails(ReportFilterRequest filter, Long scopedProjectId);
    long countNotificationDetails(ReportFilterRequest filter, Long scopedProjectId);
    NotificationDetailResponse fetchNotificationDetailsByRequestId(String requestId, Long scopedProjectId);
    List<NotificationDetailResponse> fetchAttemptsByRequestId(String requestId, Long scopedProjectId);
    List<Map<String, Object>> fetchProjectsForFilter(Long scopedProjectId);
    List<Map<String, Object>> fetchCountriesForFilter(Long scopedProjectId, Long selectedProjectId);
    List<Map<String, Object>> fetchEventTypesForFilter();
    List<Map<String, Object>> fetchChannelsForFilter();
    List<Map<String, Object>> fetchProvidersForFilter();
}
