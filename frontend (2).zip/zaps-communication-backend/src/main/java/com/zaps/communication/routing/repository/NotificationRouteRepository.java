package com.zaps.communication.routing.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zaps.communication.channel.entity.Channel;
import com.zaps.communication.country.entity.Country;
import com.zaps.communication.event.entity.EventType;
import com.zaps.communication.project.entity.Project;
import com.zaps.communication.routing.entity.NotificationRoute;

public interface NotificationRouteRepository extends JpaRepository<NotificationRoute, Long> {
    List<NotificationRoute> findByProjectAndCountryAndChannelAndEventTypeAndEnabledTrueOrderByPriorityAsc(Project project, Country country, Channel channel, EventType eventType);
    List<NotificationRoute> findByProjectAndCountryAndChannelAndEventTypeIsNullAndEnabledTrueOrderByPriorityAsc(Project project, Country country, Channel channel);
    List<NotificationRoute> findByProjectAndCountryIsNullAndChannelAndEventTypeAndEnabledTrueOrderByPriorityAsc(Project project, Channel channel, EventType eventType);
    List<NotificationRoute> findByProjectAndCountryIsNullAndChannelAndEventTypeIsNullAndEnabledTrueOrderByPriorityAsc(Project project, Channel channel);
}

