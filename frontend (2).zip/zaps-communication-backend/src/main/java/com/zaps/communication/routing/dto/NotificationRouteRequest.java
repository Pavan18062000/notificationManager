package com.zaps.communication.routing.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class NotificationRouteRequest {
    @NotNull private Long projectId;
    private Long countryId;
    @NotNull private Long channelId;
    private Long eventTypeId;
    @NotNull private Long providerId;
    @NotNull private Integer priority;
    private Boolean enabled = true;
    private Integer rateLimitPerMinute;
    private Integer maxRetries;
    private String fromEmail;
    private String senderId;
    private String providerApiKey;
    private String providerAccountKey;
    private String configJson;
}
