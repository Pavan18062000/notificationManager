package com.zaps.communication.notification.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
import java.time.LocalDateTime;
import com.zaps.communication.common.enums.NotificationStatus;
import com.zaps.communication.common.enums.ChannelCode;

import com.zaps.communication.notification.entity.NotificationLog;

public interface NotificationLogRepository extends JpaRepository<NotificationLog, Long> {
    List<NotificationLog> findByProjectIdAndStatus(Long projectId, NotificationStatus status);
    long countByProjectIdAndChannelCodeAndStatus(Long projectId, ChannelCode channelCode, NotificationStatus status);
    List<NotificationLog> findByRequest_IdOrderByAttemptNoDesc(Long requestId);
    List<NotificationLog> findByRequest_RequestIdOrderByAttemptNoAscCreatedAtAsc(String requestId);
    Optional<NotificationLog> findByIdAndRequest_RequestId(Long id, String requestId);
    List<NotificationLog> findByRequest_IdAndStatus(Long requestId, NotificationStatus status);
    List<NotificationLog> findByStatusAndCreatedAtBefore(NotificationStatus status, LocalDateTime before);
}
