package com.zaps.communication.channel.service;

import java.util.List;

import com.zaps.communication.channel.dto.ChannelRequest;
import com.zaps.communication.channel.dto.ChannelResponse;

public interface ChannelService {
    ChannelResponse create(ChannelRequest request);
    List<ChannelResponse> getAll();
    ChannelResponse update(Long id, ChannelRequest request);
}
