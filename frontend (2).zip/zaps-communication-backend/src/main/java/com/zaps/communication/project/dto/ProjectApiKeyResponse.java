package com.zaps.communication.project.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ProjectApiKeyResponse {
    private Long projectId;
    private String projectCode;
    private String apiKey;
    private String message;
}

