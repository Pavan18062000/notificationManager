package com.zaps.communication.notification.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

@Data
@Configuration
@ConfigurationProperties(prefix = "providers")
public class ProviderCredentialsProperties {
    private Sendgrid sendgrid = new Sendgrid();

    @Data
    public static class Sendgrid {
        private Map<String, Account> accounts = new HashMap<>();
    }

    @Data
    public static class Account {
        private String apiKey;
        private String fromEmail;
        private String fromName;
    }
}

