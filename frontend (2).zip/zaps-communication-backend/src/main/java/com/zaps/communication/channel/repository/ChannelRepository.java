package com.zaps.communication.channel.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zaps.communication.channel.entity.Channel;
import com.zaps.communication.common.enums.ChannelCode;

public interface ChannelRepository extends JpaRepository<Channel, Long> {
    Optional<Channel> findByCode(ChannelCode code);
    boolean existsByCode(ChannelCode code);
    boolean existsByCodeAndIdNot(ChannelCode code, Long id);
}
