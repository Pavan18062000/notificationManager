package com.zaps.communication.channel.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.zaps.communication.channel.dto.ChannelRequest;
import com.zaps.communication.channel.dto.ChannelResponse;
import com.zaps.communication.channel.entity.Channel;
import com.zaps.communication.channel.repository.ChannelRepository;
import com.zaps.communication.channel.service.ChannelService;
import com.zaps.communication.common.exception.DuplicateResourceException;
import com.zaps.communication.common.exception.ResourceNotFoundException;

@Service
public class ChannelServiceImpl implements ChannelService {
    private final ChannelRepository repository;
    public ChannelServiceImpl(ChannelRepository repository) { this.repository = repository; }

    public ChannelResponse create(ChannelRequest request){
        if (repository.existsByCode(request.getCode())) {
            throw new DuplicateResourceException("Channel code already exists");
        }
        Channel c = new Channel();
        c.setCode(request.getCode());
        c.setActive(Boolean.TRUE.equals(request.getActive()));
        return toResponse(repository.save(c));
    }
    public List<ChannelResponse> getAll(){ return repository.findAll().stream().map(this::toResponse).toList(); }
    public ChannelResponse update(Long id, ChannelRequest request){
        Channel c = repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Channel not found"));
        if (repository.existsByCodeAndIdNot(request.getCode(), id)) {
            throw new DuplicateResourceException("Channel code already exists");
        }
        c.setCode(request.getCode());
        c.setActive(Boolean.TRUE.equals(request.getActive()));
        return toResponse(repository.save(c));
    }
    private ChannelResponse toResponse(Channel c){ return ChannelResponse.builder().id(c.getId()).code(c.getCode()).active(c.isActive()).build(); }
}
