package com.zaps.communication.notification.consumer;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.core.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.zaps.communication.common.enums.ChannelCode;
import com.zaps.communication.common.enums.NotificationStatus;
import com.zaps.communication.config.RabbitMqConfig;
import com.zaps.communication.notification.dto.NotificationDeliveryJob;
import com.zaps.communication.notification.entity.NotificationLog;
import com.zaps.communication.notification.entity.NotificationRequest;
import com.zaps.communication.notification.provider.NotificationProvider;
import com.zaps.communication.notification.provider.ProviderResolver;
import com.zaps.communication.notification.provider.dto.NotificationProviderRequest;
import com.zaps.communication.notification.provider.dto.ProviderDeliveryResponse;
import com.zaps.communication.notification.repository.NotificationLogRepository;
import com.zaps.communication.notification.repository.NotificationRequestRepository;

@Component
public class NotificationRabbitConsumers {
    private static final Logger log = LoggerFactory.getLogger(NotificationRabbitConsumers.class);
    private static final int MAX_RETRY = 3;

    private final NotificationLogRepository notificationLogRepository;
    private final NotificationRequestRepository notificationRequestRepository;
    private final ProviderResolver providerResolver;
    private final ObjectProvider<RabbitTemplate> rabbitTemplateProvider;
    private final ObjectMapper objectMapper;

    public NotificationRabbitConsumers(
            NotificationLogRepository notificationLogRepository,
            NotificationRequestRepository notificationRequestRepository,
            ProviderResolver providerResolver,
            ObjectProvider<RabbitTemplate> rabbitTemplateProvider,
            ObjectMapper objectMapper) {
        this.notificationLogRepository = notificationLogRepository;
        this.notificationRequestRepository = notificationRequestRepository;
        this.providerResolver = providerResolver;
        this.rabbitTemplateProvider = rabbitTemplateProvider;
        this.objectMapper = objectMapper;
    }

    @RabbitListener(queues = RabbitMqConfig.SMS_QUEUE)
    public void smsNotificationConsumer(NotificationDeliveryJob job) {
        process(job, ChannelCode.SMS);
    }

    @RabbitListener(queues = RabbitMqConfig.EMAIL_QUEUE)
    public void emailNotificationConsumer(NotificationDeliveryJob job) {
        process(job, ChannelCode.EMAIL);
    }

    @RabbitListener(queues = RabbitMqConfig.WHATSAPP_QUEUE)
    public void whatsappNotificationConsumer(NotificationDeliveryJob job) {
        process(job, ChannelCode.WHATSAPP);
    }

    @RabbitListener(queues = RabbitMqConfig.PUSH_QUEUE)
    public void pushNotificationConsumer(NotificationDeliveryJob job) {
        process(job, ChannelCode.PUSH);
    }

    @RabbitListener(queues = RabbitMqConfig.EMAIL_DLQ)
    @Transactional
    public void emailDlqConsumer(Message message) {
        NotificationDeliveryJob job = parseDlqMessage(message);
        if (job == null || job.getDeliveryId() == null || job.getRequestId() == null) {
            log.error("Unable to resolve request/delivery from DLQ message. messageId={}", message.getMessageProperties().getMessageId());
            return;
        }
        NotificationLog delivery = notificationLogRepository.findByIdAndRequest_RequestId(job.getDeliveryId(), job.getRequestId()).orElse(null);
        NotificationRequest request = notificationRequestRepository.findByRequestId(job.getRequestId()).orElse(null);
        if (delivery == null || request == null) {
            log.warn("DLQ message has unknown request/log requestId={} deliveryId={}", job.getRequestId(), job.getDeliveryId());
            return;
        }

        if (delivery.getStatus() == NotificationStatus.SENT || request.getStatus() == NotificationStatus.SENT) {
            return;
        }
        markFailed(delivery, request, 500, "Moved to DLQ: message processing failed", 0L);
        log.error("Marked FAILED from DLQ requestId={} deliveryId={} channel={}",
                job.getRequestId(), job.getDeliveryId(), job.getChannel());
    }

    @Transactional
    protected void process(NotificationDeliveryJob job, ChannelCode expectedChannel) {
        if (job == null || job.getDeliveryId() == null || job.getRequestId() == null) {
            log.warn("Skipping {} message due to missing identifiers: {}", expectedChannel, job);
            return;
        }
        ChannelCode jobChannel;
        try {
            jobChannel = ChannelCode.valueOf(job.getChannel());
        } catch (Exception ex) {
            log.warn("Invalid channel in job requestId={} deliveryId={} channel={}", job.getRequestId(), job.getDeliveryId(), job.getChannel());
            return;
        }
        if (jobChannel != expectedChannel) {
            log.warn("Channel mismatch for requestId={} deliveryId={} expected={} actual={}",
                    job.getRequestId(), job.getDeliveryId(), expectedChannel, jobChannel);
            return;
        }

        NotificationLog delivery = notificationLogRepository.findById(job.getDeliveryId()).orElse(null);
        NotificationRequest request = notificationRequestRepository.findByRequestId(job.getRequestId()).orElse(null);
        if (delivery == null || request == null) {
            log.warn("Request/log not found for requestId={} deliveryId={}", job.getRequestId(), job.getDeliveryId());
            return;
        }

        delivery.setStatus(NotificationStatus.PROCESSING);
        request.setStatus(NotificationStatus.PROCESSING);
        notificationLogRepository.save(delivery);
        notificationRequestRepository.save(request);

        String correlationId = job.getCorrelationId();
        String providerCode = job.getProviderCode();
        NotificationProvider provider = providerResolver.resolve(jobChannel, providerCode);
        if (provider == null) {
            markFailed(delivery, request, 500, "Provider not found for " + jobChannel + "/" + providerCode, 0L);
            log.error("Provider resolution failed requestId={} deliveryId={} channel={} provider={} correlationId={}",
                    job.getRequestId(), job.getDeliveryId(), jobChannel, providerCode, correlationId);
            return;
        }

        NotificationProviderRequest providerRequest = NotificationProviderRequest.builder()
                .requestId(job.getRequestId())
                .deliveryId(job.getDeliveryId())
                .projectId(job.getProjectId())
                .projectCode(job.getProjectCode())
                .countryCode(job.getCountryCode())
                .eventCode(job.getEventCode())
                .channel(job.getChannel())
                .providerCode(job.getProviderCode())
                .recipient(job.getRecipient())
                .subject(job.getSubject())
                .body(job.getBody())
                .templateData(job.getTemplateData())
                .metadata(job.getMetadata())
                .correlationId(correlationId)
                .build();

        ProviderDeliveryResponse response = provider.send(providerRequest);
        if (response.isSuccess()) {
            delivery.setStatus(NotificationStatus.SENT);
            delivery.setProviderMessageId(response.getProviderMessageId());
            delivery.setProviderResponse(response.getProviderResponse());
            delivery.setHttpStatus(response.getHttpStatus());
            delivery.setLatencyMs(response.getLatencyMs());
            delivery.setProviderCode(provider.providerCode());
            delivery.setErrorMessage(null);
            delivery.setSentAt(LocalDateTime.now());
            notificationLogRepository.save(delivery);

            request.setStatus(NotificationStatus.SENT);
            notificationRequestRepository.save(request);

            log.info("Delivery sent requestId={} deliveryId={} channel={} provider={} correlationId={}",
                    job.getRequestId(), job.getDeliveryId(), jobChannel, provider.providerCode(), correlationId);
            return;
        }

        markFailed(delivery, request, response.getHttpStatus(), response.getErrorMessage(), response.getLatencyMs());
        log.error("Delivery failed requestId={} deliveryId={} channel={} provider={} retryable={} correlationId={}",
                job.getRequestId(), job.getDeliveryId(), jobChannel, provider.providerCode(), response.isRetryable(), correlationId);

        if (response.isRetryable() && (delivery.getRetryCount() == null ? 0 : delivery.getRetryCount()) < MAX_RETRY) {
            createRetryAttempt(delivery, request, job, provider.providerCode());
        }
    }

    private void markFailed(NotificationLog delivery, NotificationRequest request, Integer httpStatus, String errorMessage, Long latencyMs) {
        delivery.setStatus(NotificationStatus.FAILED);
        delivery.setHttpStatus(httpStatus);
        delivery.setErrorMessage(errorMessage == null ? "Delivery failed" : errorMessage);
        delivery.setLatencyMs(latencyMs);
        delivery.setFailedAt(LocalDateTime.now());
        notificationLogRepository.save(delivery);

        request.setStatus(NotificationStatus.FAILED);
        notificationRequestRepository.save(request);
    }

    private void createRetryAttempt(NotificationLog previous, NotificationRequest request, NotificationDeliveryJob job, String providerCode) {
        int previousRetry = previous.getRetryCount() == null ? 0 : previous.getRetryCount();
        NotificationLog retry = new NotificationLog();
        retry.setRequest(request);
        retry.setProject(previous.getProject());
        retry.setCountry(previous.getCountry());
        retry.setChannel(previous.getChannel());
        retry.setProvider(previous.getProvider());
        retry.setTemplate(previous.getTemplate());
        retry.setRecipient(previous.getRecipient());
        retry.setStatus(NotificationStatus.QUEUED);
        retry.setRetryCount(previousRetry + 1);
        retry.setAttemptNo((previous.getAttemptNo() == null ? 1 : previous.getAttemptNo()) + 1);
        retry.setProviderCode(providerCode);
        retry = notificationLogRepository.save(retry);

        NotificationDeliveryJob retryJob = NotificationDeliveryJob.builder()
                .requestId(job.getRequestId())
                .deliveryId(retry.getId())
                .projectId(job.getProjectId())
                .projectCode(job.getProjectCode())
                .countryCode(job.getCountryCode())
                .eventCode(job.getEventCode())
                .channel(job.getChannel())
                .providerCode(job.getProviderCode())
                .recipient(job.getRecipient())
                .subject(job.getSubject())
                .body(job.getBody())
                .templateData(job.getTemplateData())
                .metadata(job.getMetadata())
                .correlationId(job.getCorrelationId())
                .createdAt(System.currentTimeMillis())
                .build();

        RabbitTemplate rabbitTemplate = rabbitTemplateProvider.getIfAvailable();
        if (rabbitTemplate == null) return;
        String routingKey = "notification." + job.getChannel().toLowerCase();
        rabbitTemplate.convertAndSend(RabbitMqConfig.NOTIFICATION_EXCHANGE, routingKey, retryJob);
        log.info("Retry queued requestId={} deliveryId={} attemptNo={}", job.getRequestId(), retry.getId(), retry.getAttemptNo());
    }

    private NotificationDeliveryJob parseDlqMessage(Message message) {
        try {
            return objectMapper.readValue(message.getBody(), NotificationDeliveryJob.class);
        } catch (Exception ex) {
            log.error("Failed to parse DLQ message body as NotificationDeliveryJob", ex);
            return null;
        }
    }
}
