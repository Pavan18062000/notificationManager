package com.zaps.communication.notification.provider.impl;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.zaps.communication.common.enums.ChannelCode;
import com.zaps.communication.notification.config.ProviderCredentialsProperties;
import com.zaps.communication.notification.provider.EmailProvider;
import com.zaps.communication.notification.provider.dto.NotificationProviderRequest;
import com.zaps.communication.notification.provider.dto.ProviderDeliveryResponse;
import com.zaps.communication.notification.service.SendgridEmailService;

@Component
public class SendGridEmailProvider implements EmailProvider {
    private final SendgridEmailService sendgridEmailService;
    private final ProviderCredentialsProperties providerCredentialsProperties;

    public SendGridEmailProvider(SendgridEmailService sendgridEmailService, ProviderCredentialsProperties providerCredentialsProperties) {
        this.sendgridEmailService = sendgridEmailService;
        this.providerCredentialsProperties = providerCredentialsProperties;
    }

    @Override
    public ChannelCode channel() {
        return ChannelCode.EMAIL;
    }

    @Override
    public String providerCode() {
        return "SENDGRID";
    }

    @Override
    public ProviderDeliveryResponse send(NotificationProviderRequest request) {
        long start = System.currentTimeMillis();
        try {
            String accountKey = "default";
            if (request.getMetadata() != null && request.getMetadata().get("providerAccountKey") != null) {
                accountKey = String.valueOf(request.getMetadata().get("providerAccountKey"));
            }
            ProviderCredentialsProperties.Account account = providerCredentialsProperties.getSendgrid().getAccounts().get(accountKey);
            String apiKey = account == null ? null : account.getApiKey();
            String fromEmail = account == null ? null : account.getFromEmail();

            // Backward compatibility fallback from route metadata if YAML account not configured.
            if ((apiKey == null || apiKey.isBlank()) && request.getMetadata() != null) {
                apiKey = String.valueOf(request.getMetadata().getOrDefault("providerApiKey", ""));
            }
            if ((fromEmail == null || fromEmail.isBlank()) && request.getMetadata() != null) {
                fromEmail = String.valueOf(request.getMetadata().getOrDefault("fromEmail", ""));
            }
            if (apiKey == null || apiKey.isBlank() || fromEmail == null || fromEmail.isBlank()) {
                return ProviderDeliveryResponse.builder()
                        .success(false).providerCode(providerCode()).httpStatus(400)
                        .errorMessage("Provider configuration missing").retryable(false)
                        .latencyMs(System.currentTimeMillis() - start)
                        .build();
            }
            ResponseEntity<String> response = sendgridEmailService.sendWithResponse(
                    apiKey, fromEmail, request.getRecipient(), request.getSubject(), request.getBody());
            String messageId = response.getHeaders().getFirst("X-Message-Id");
            return ProviderDeliveryResponse.builder()
                    .success(response.getStatusCode().is2xxSuccessful())
                    .providerCode(providerCode())
                    .providerMessageId(messageId)
                    .providerResponse(response.getBody())
                    .httpStatus(response.getStatusCode().value())
                    .latencyMs(System.currentTimeMillis() - start)
                    .retryable(response.getStatusCode().value() == 429 || response.getStatusCode().is5xxServerError())
                    .errorMessage(response.getStatusCode().is2xxSuccessful() ? null : "SendGrid delivery failed")
                    .build();
        } catch (Exception ex) {
            return ProviderDeliveryResponse.builder()
                    .success(false).providerCode(providerCode())
                    .httpStatus(500)
                    .latencyMs(System.currentTimeMillis() - start)
                    .errorMessage("Provider delivery failed")
                    .retryable(true)
                    .build();
        }
    }
}
