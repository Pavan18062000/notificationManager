package com.zaps.communication.routing.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.zaps.communication.common.ApiResponse;
import com.zaps.communication.routing.dto.NotificationRouteRequest;
import com.zaps.communication.routing.dto.NotificationRouteResponse;
import com.zaps.communication.routing.service.NotificationRouteService;
import com.zaps.communication.user.entity.User;
import com.zaps.communication.user.service.AccessScopeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/notification-routes")
public class NotificationRouteController {
    private final NotificationRouteService notificationRouteService;
    private final AccessScopeService accessScopeService;

    public NotificationRouteController(NotificationRouteService notificationRouteService, AccessScopeService accessScopeService) {
        this.notificationRouteService = notificationRouteService;
        this.accessScopeService = accessScopeService;
    }

    @GetMapping
    public ApiResponse<List<NotificationRouteResponse>> list(@RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        User actor = accessScopeService.requireUser(authorizationHeader);
        Long scopedProjectId = accessScopeService.requiredProjectId(actor);
        return ApiResponse.success("Notification routes fetched", notificationRouteService.getAll(scopedProjectId));
    }

    @PostMapping
    public ApiResponse<NotificationRouteResponse> create(@Valid @RequestBody NotificationRouteRequest request, @RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        User actor = accessScopeService.requireUser(authorizationHeader);
        accessScopeService.assertProjectAccess(actor, request.getProjectId());
        return ApiResponse.success("Notification route created", notificationRouteService.create(request));
    }

    @PutMapping("/{id}")
    public ApiResponse<NotificationRouteResponse> update(
            @PathVariable Long id,
            @Valid @RequestBody NotificationRouteRequest request,
            @RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        User actor = accessScopeService.requireUser(authorizationHeader);
        accessScopeService.assertProjectAccess(actor, request.getProjectId());
        return ApiResponse.success("Notification route updated", notificationRouteService.update(id, request));
    }
}
