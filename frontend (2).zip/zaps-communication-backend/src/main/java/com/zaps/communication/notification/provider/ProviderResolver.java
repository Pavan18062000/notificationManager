package com.zaps.communication.notification.provider;

import java.util.List;
import java.util.Locale;

import org.springframework.stereotype.Component;

import com.zaps.communication.common.enums.ChannelCode;

@Component
public class ProviderResolver {
    private final List<NotificationProvider> providers;

    public ProviderResolver(List<NotificationProvider> providers) {
        this.providers = providers;
    }

    public NotificationProvider resolve(ChannelCode channel, String providerCode) {
        if (providerCode == null || providerCode.isBlank()) return null;
        String normalized = providerCode.trim().toUpperCase(Locale.ROOT);
        return providers.stream()
                .filter(p -> p.channel() == channel && normalized.equalsIgnoreCase(p.providerCode()))
                .findFirst()
                .orElse(null);
    }
}

