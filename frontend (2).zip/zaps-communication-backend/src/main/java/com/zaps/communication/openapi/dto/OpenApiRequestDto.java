package com.zaps.communication.openapi.dto;

import java.util.Map;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class OpenApiRequestDto {
    @NotBlank
    private String countryCode;
    @NotBlank
    private String eventCode;
    @NotBlank
    private String channel;
    @NotBlank
    private String recipient;
    private String subject;
    private String body;
    private Map<String, Object> templateData;
}

