package com.zaps.communication.routing.entity;

import com.zaps.communication.channel.entity.Channel;
import com.zaps.communication.common.AuditableEntity;
import com.zaps.communication.country.entity.Country;
import com.zaps.communication.event.entity.EventType;
import com.zaps.communication.project.entity.Project;
import com.zaps.communication.provider.entity.Provider;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "notification_routes", uniqueConstraints = @UniqueConstraint(
        name = "uk_notification_routes", columnNames = {"project_id", "country_id", "channel_id", "event_type_id", "provider_id"}
), indexes = @Index(name = "idx_notification_routes_lookup", columnList = "project_id,country_id,channel_id,event_type_id,enabled,priority"))
@Getter
@Setter
public class NotificationRoute extends AuditableEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(optional = false) @JoinColumn(name = "project_id")
    private Project project;
    @ManyToOne(optional = true) @JoinColumn(name = "country_id")
    private Country country;
    @ManyToOne(optional = false) @JoinColumn(name = "channel_id")
    private Channel channel;
    @ManyToOne(optional = true) @JoinColumn(name = "event_type_id")
    private EventType eventType;
    @ManyToOne(optional = false) @JoinColumn(name = "provider_id")
    private Provider provider;
    @Column(nullable = false)
    private Integer priority = 100;
    @Column(nullable = false)
    private boolean enabled = true;
    @Column(name = "rate_limit_per_minute")
    private Integer rateLimitPerMinute;
    @Column(name = "max_retries")
    private Integer maxRetries;
    @Column(name = "from_email")
    private String fromEmail;
    @Column(name = "sender_id")
    private String senderId;
    @Column(name = "provider_api_key", length = 512)
    private String providerApiKey;
    @Column(name = "provider_account_key", length = 128)
    private String providerAccountKey;
    @Column(name = "config_json", columnDefinition = "TEXT")
    private String configJson;
}
