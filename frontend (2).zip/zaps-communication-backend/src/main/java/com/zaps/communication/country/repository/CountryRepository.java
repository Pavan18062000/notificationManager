package com.zaps.communication.country.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zaps.communication.country.entity.Country;

public interface CountryRepository extends JpaRepository<Country, Long> {
    Optional<Country> findByCountryCode(String countryCode);
    boolean existsByCountryCode(String countryCode);
}
