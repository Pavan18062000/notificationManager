package com.zaps.communication.template.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.zaps.communication.common.ApiResponse;
import com.zaps.communication.template.dto.TemplateRequest;
import com.zaps.communication.template.dto.TemplateResponse;
import com.zaps.communication.template.service.TemplateService;
import com.zaps.communication.user.entity.User;
import com.zaps.communication.user.service.AccessScopeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/templates")
public class TemplateController {
    private final TemplateService service;
    private final AccessScopeService accessScopeService;
    public TemplateController(TemplateService service, AccessScopeService accessScopeService) { this.service = service; this.accessScopeService = accessScopeService; }

    @PostMapping public ApiResponse<TemplateResponse> create(@Valid @RequestBody TemplateRequest request, @RequestHeader(value = "Authorization", required = false) String authorizationHeader){
        User actor = accessScopeService.requireUser(authorizationHeader);
        accessScopeService.assertProjectAccess(actor, request.getProjectId());
        return ApiResponse.success("Template created", service.create(request));
    }
    @GetMapping public ApiResponse<List<TemplateResponse>> getAll(@RequestHeader(value = "Authorization", required = false) String authorizationHeader){
        User actor = accessScopeService.requireUser(authorizationHeader);
        Long scopedProjectId = accessScopeService.requiredProjectId(actor);
        return ApiResponse.success("Templates fetched", scopedProjectId == null ? service.getAll() : service.getAll(scopedProjectId));
    }
    @GetMapping("/search") public ApiResponse<List<TemplateResponse>> search(@RequestParam Long projectId, @RequestParam Long countryId, @RequestParam Long channelId, @RequestParam Long eventTypeId, @RequestHeader(value = "Authorization", required = false) String authorizationHeader){
        User actor = accessScopeService.requireUser(authorizationHeader);
        accessScopeService.assertProjectAccess(actor, projectId);
        return ApiResponse.success("Templates fetched", service.search(projectId, countryId, channelId, eventTypeId));
    }
    @PutMapping("/{id}") public ApiResponse<TemplateResponse> update(@PathVariable Long id, @Valid @RequestBody TemplateRequest request, @RequestHeader(value = "Authorization", required = false) String authorizationHeader){
        User actor = accessScopeService.requireUser(authorizationHeader);
        accessScopeService.assertProjectAccess(actor, request.getProjectId());
        return ApiResponse.success("Template updated", service.update(id, request));
    }
}
