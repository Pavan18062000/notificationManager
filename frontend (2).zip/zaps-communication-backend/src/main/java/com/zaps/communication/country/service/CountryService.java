package com.zaps.communication.country.service;

import java.util.List;

import com.zaps.communication.country.dto.CountryRequest;
import com.zaps.communication.country.dto.CountryResponse;

public interface CountryService {
    CountryResponse create(CountryRequest request);
    List<CountryResponse> getAll();
    CountryResponse getById(Long id);
    CountryResponse update(Long id, CountryRequest request);
    void delete(Long id);
}
