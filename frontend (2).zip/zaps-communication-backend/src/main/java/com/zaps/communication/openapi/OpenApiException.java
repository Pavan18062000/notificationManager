package com.zaps.communication.openapi;

import org.springframework.http.HttpStatus;

import lombok.Getter;

@Getter
public class OpenApiException extends RuntimeException {
    private final HttpStatus status;
    private final OpenApiErrorCode errorCode;

    public OpenApiException(HttpStatus status, OpenApiErrorCode errorCode, String message) {
        super(message);
        this.status = status;
        this.errorCode = errorCode;
    }
}

