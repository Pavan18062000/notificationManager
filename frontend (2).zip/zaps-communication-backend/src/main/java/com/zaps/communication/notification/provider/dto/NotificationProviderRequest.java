package com.zaps.communication.notification.provider.dto;

import java.util.Map;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NotificationProviderRequest {
    private String requestId;
    private Long deliveryId;
    private Long projectId;
    private String projectCode;
    private String countryCode;
    private String eventCode;
    private String channel;
    private String providerCode;
    private String recipient;
    private String subject;
    private String body;
    private Map<String, Object> templateData;
    private Map<String, Object> metadata;
    private String correlationId;
}

