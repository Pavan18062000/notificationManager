package com.zaps.communication.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zaps.communication.user.entity.User;
import com.zaps.communication.user.entity.UserRole;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmailIgnoreCase(String email);
    boolean existsByEmailIgnoreCase(String email);
    List<User> findByProjectId(Long projectId);
    List<User> findByRole(UserRole role);
}

