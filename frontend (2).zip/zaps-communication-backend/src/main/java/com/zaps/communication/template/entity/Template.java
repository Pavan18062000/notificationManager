package com.zaps.communication.template.entity;

import com.zaps.communication.channel.entity.Channel;
import com.zaps.communication.common.AuditableEntity;
import com.zaps.communication.country.entity.Country;
import com.zaps.communication.event.entity.EventType;
import com.zaps.communication.project.entity.Project;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "templates", indexes = @Index(name = "idx_tpl_lookup", columnList = "project_id,country_id,channel_id,event_type_id,active"))
@Getter
@Setter
public class Template extends AuditableEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(optional = false) @JoinColumn(name = "project_id")
    private Project project;
    @ManyToOne(optional = false) @JoinColumn(name = "country_id")
    private Country country;
    @ManyToOne(optional = false) @JoinColumn(name = "channel_id")
    private Channel channel;
    @ManyToOne(optional = false) @JoinColumn(name = "event_type_id")
    private EventType eventType;
    @Column(nullable = false)
    private String templateName;
    private String language;
    private String subject;
    @Column(nullable = false, columnDefinition = "TEXT")
    private String body;
    @Column(nullable = false)
    private boolean active = true;
}
