package com.zaps.communication.template.service;

import java.util.List;

import com.zaps.communication.template.dto.TemplateRequest;
import com.zaps.communication.template.dto.TemplateResponse;

public interface TemplateService {
    TemplateResponse create(TemplateRequest request);
    List<TemplateResponse> getAll();
    List<TemplateResponse> getAll(Long projectId);
    List<TemplateResponse> search(Long projectId, Long countryId, Long channelId, Long eventTypeId);
    TemplateResponse update(Long id, TemplateRequest request);
}
