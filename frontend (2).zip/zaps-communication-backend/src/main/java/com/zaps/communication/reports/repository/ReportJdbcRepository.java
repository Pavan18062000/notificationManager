package com.zaps.communication.reports.repository;

import java.sql.Date;
import java.time.LocalDate;
import java.util.*;

import com.zaps.communication.reports.dto.*;
import com.zaps.communication.reports.mapper.ReportRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class ReportJdbcRepository implements ReportRepository {
    private final NamedParameterJdbcTemplate jdbc;

    public ReportJdbcRepository(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public NotificationSummaryResponse fetchSummary(ReportFilterRequest filter, Long scopedProjectId) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String whereReq = buildWhere(filter, scopedProjectId, params, true);
        String whereLog = buildWhere(filter, scopedProjectId, params, false);

        Map<String, Object> req = jdbc.queryForMap(
                "SELECT COUNT(*) totalRequests, " +
                "SUM(CASE WHEN nr.status='QUEUED' THEN 1 ELSE 0 END) queued, " +
                "SUM(CASE WHEN nr.status='PROCESSING' THEN 1 ELSE 0 END) processing, " +
                "SUM(CASE WHEN nr.status='SENT' THEN 1 ELSE 0 END) sent, " +
                "SUM(CASE WHEN nr.status='FAILED' THEN 1 ELSE 0 END) failed, " +
                "SUM(CASE WHEN nr.status='ACCEPTED' THEN 1 ELSE 0 END) accepted " +
                "FROM notification_requests nr " + whereReq, params);

        Map<String, Object> lg = jdbc.queryForMap(
                "SELECT COALESCE(AVG(nl.latency_ms),0) avgLatencyMs, COALESCE(SUM(nl.retry_count),0) totalRetryAttempts " +
                "FROM notification_logs nl " +
                "JOIN notification_requests nr ON nr.id = nl.request_id " +
                "LEFT JOIN countries co ON co.id = nr.country_id " +
                "LEFT JOIN event_types et ON et.id = nr.event_type_id " +
                "LEFT JOIN channels ch ON ch.id = nl.channel_id " +
                "LEFT JOIN providers pr ON pr.id = nl.provider_id " + whereLog, params);

        long total = ((Number) req.get("totalRequests")).longValue();
        long sent = ((Number) req.get("sent")).longValue();
        return NotificationSummaryResponse.builder()
                .totalRequests(total)
                .queued(((Number) req.get("queued")).longValue())
                .processing(((Number) req.get("processing")).longValue())
                .sent(sent)
                .failed(((Number) req.get("failed")).longValue())
                .accepted(((Number) req.get("accepted")).longValue())
                .successRate(total == 0 ? 0 : (sent * 100.0 / total))
                .avgLatencyMs(((Number) lg.get("avgLatencyMs")).doubleValue())
                .retryAttempts(((Number) lg.get("totalRetryAttempts")).longValue())
                .build();
    }

    @Override
    public List<NotificationTrendResponse> fetchTrend(ReportFilterRequest filter, Long scopedProjectId) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String where = buildWhere(filter, scopedProjectId, params, true);
        return jdbc.query(
                "SELECT DATE(nr.created_at) d, COUNT(*) total, " +
                "SUM(CASE WHEN nr.status='SENT' THEN 1 ELSE 0 END) sent, " +
                "SUM(CASE WHEN nr.status='FAILED' THEN 1 ELSE 0 END) failed " +
                "FROM notification_requests nr " + where + " GROUP BY DATE(nr.created_at) ORDER BY d",
                params,
                (rs, i) -> new NotificationTrendResponse(rs.getDate("d").toString(), rs.getLong("total"), rs.getLong("sent"), rs.getLong("failed"))
        );
    }

    @Override
    public List<StatusDistributionResponse> fetchStatusDistribution(ReportFilterRequest filter, Long scopedProjectId) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String where = buildWhere(filter, scopedProjectId, params, true);
        return jdbc.query("SELECT nr.status status, COUNT(*) cnt FROM notification_requests nr " + where + " GROUP BY nr.status",
                params, (rs, i) -> new StatusDistributionResponse(rs.getString("status"), rs.getLong("cnt")));
    }

    @Override
    public List<ChannelSummaryResponse> fetchChannelSummary(ReportFilterRequest filter, Long scopedProjectId) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String where = buildWhere(filter, scopedProjectId, params, false);
        return jdbc.query("SELECT ch.id channel_id, ch.code channel, COUNT(*) cnt " +
                        "FROM notification_logs nl " +
                        "JOIN notification_requests nr ON nr.id=nl.request_id " +
                        "LEFT JOIN countries co ON co.id = nr.country_id " +
                        "LEFT JOIN event_types et ON et.id = nr.event_type_id " +
                        "LEFT JOIN channels ch ON ch.id = nl.channel_id " +
                        "LEFT JOIN providers pr ON pr.id = nl.provider_id " +
                        where + " GROUP BY ch.id, ch.code",
                params, (rs, i) -> new ChannelSummaryResponse(rs.getLong("channel_id"), rs.getString("channel"), rs.getLong("cnt")));
    }

    @Override
    public List<ProviderSummaryResponse> fetchProviderSummary(ReportFilterRequest filter, Long scopedProjectId) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String where = buildWhere(filter, scopedProjectId, params, false);
        return jdbc.query("SELECT pr.id provider_id, COALESCE(pr.provider_code,nl.provider_code) provider, COUNT(*) cnt, COALESCE(AVG(nl.latency_ms),0) lat " +
                        "FROM notification_logs nl " +
                        "JOIN notification_requests nr ON nr.id=nl.request_id " +
                        "LEFT JOIN countries co ON co.id = nr.country_id " +
                        "LEFT JOIN event_types et ON et.id = nr.event_type_id " +
                        "LEFT JOIN channels ch ON ch.id = nl.channel_id " +
                        "LEFT JOIN providers pr ON pr.id = nl.provider_id " +
                        where + " GROUP BY pr.id, provider",
                params, (rs, i) -> new ProviderSummaryResponse((Long) rs.getObject("provider_id"), rs.getString("provider"), rs.getLong("cnt"), rs.getDouble("lat")));
    }

    @Override
    public List<ProjectSummaryResponse> fetchProjectSummary(ReportFilterRequest filter, Long scopedProjectId) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String where = buildWhere(filter, scopedProjectId, params, true);
        return jdbc.query("SELECT p.id project_id,p.project_code,p.project_name,COUNT(*) cnt " +
                        "FROM notification_requests nr JOIN projects p ON p.id=nr.project_id " + where + " GROUP BY p.id,p.project_code,p.project_name",
                params, (rs, i) -> new ProjectSummaryResponse(rs.getLong("project_id"), rs.getString("project_code"), rs.getString("project_name"), rs.getLong("cnt")));
    }

    @Override
    public List<EventSummaryResponse> fetchEventSummary(ReportFilterRequest filter, Long scopedProjectId) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String where = buildWhere(filter, scopedProjectId, params, true);
        return jdbc.query("SELECT et.id event_type_id,et.event_code,et.event_name,COUNT(*) cnt " +
                        "FROM notification_requests nr JOIN event_types et ON et.id=nr.event_type_id " + where + " GROUP BY et.id,et.event_code,et.event_name",
                params, (rs, i) -> new EventSummaryResponse(rs.getLong("event_type_id"), rs.getString("event_code"), rs.getString("event_name"), rs.getLong("cnt")));
    }

    @Override
    public List<NotificationDetailResponse> fetchNotificationDetails(ReportFilterRequest filter, Long scopedProjectId) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String where = buildWhere(filter, scopedProjectId, params, false);
        int page = filter.getPage() == null ? 0 : Math.max(filter.getPage(), 0);
        int size = filter.getSize() == null ? 20 : Math.max(filter.getSize(), 1);
        params.addValue("limit", size);
        params.addValue("offset", page * size);
        String orderBy = resolveSortColumn(filter.getSortBy(), filter.getSortDirection());
        return jdbc.query(baseDetailSql() + where + " ORDER BY " + orderBy + " LIMIT :limit OFFSET :offset", params, ReportRowMapper.notificationDetailRowMapper());
    }

    @Override
    public long countNotificationDetails(ReportFilterRequest filter, Long scopedProjectId) {
        MapSqlParameterSource params = new MapSqlParameterSource();
        String where = buildWhere(filter, scopedProjectId, params, false);
        return jdbc.queryForObject("SELECT COUNT(*) FROM notification_logs nl " +
                "JOIN notification_requests nr ON nr.id = nl.request_id " +
                "LEFT JOIN projects p ON p.id = nr.project_id " +
                "LEFT JOIN countries co ON co.id = nr.country_id " +
                "LEFT JOIN event_types et ON et.id = nr.event_type_id " +
                "LEFT JOIN channels ch ON ch.id = nl.channel_id " +
                "LEFT JOIN providers pr ON pr.id = nl.provider_id " + where, params, Long.class);
    }

    @Override
    public NotificationDetailResponse fetchNotificationDetailsByRequestId(String requestId, Long scopedProjectId) {
        MapSqlParameterSource params = new MapSqlParameterSource("requestId", requestId);
        String where = " WHERE nr.request_id=:requestId ";
        if (scopedProjectId != null) {
            where += " AND nr.project_id=:scopedProjectId ";
            params.addValue("scopedProjectId", scopedProjectId);
        }
        List<NotificationDetailResponse> rows = jdbc.query(baseDetailSql() + where + " ORDER BY nl.attempt_no ASC, nl.created_at ASC", params, ReportRowMapper.notificationDetailRowMapper());
        if (rows.isEmpty()) return null;
        NotificationDetailResponse top = rows.get(0);
        top.setAttempts(rows);
        return top;
    }

    @Override
    public List<NotificationDetailResponse> fetchAttemptsByRequestId(String requestId, Long scopedProjectId) {
        MapSqlParameterSource params = new MapSqlParameterSource("requestId", requestId);
        String where = " WHERE nr.request_id=:requestId ";
        if (scopedProjectId != null) {
            where += " AND nr.project_id=:scopedProjectId ";
            params.addValue("scopedProjectId", scopedProjectId);
        }
        return jdbc.query(baseDetailSql() + where + " ORDER BY nl.attempt_no ASC, nl.created_at ASC", params, ReportRowMapper.notificationDetailRowMapper());
    }

    @Override
    public List<Map<String, Object>> fetchProjectsForFilter(Long scopedProjectId) {
        if (scopedProjectId != null) {
            return jdbc.queryForList("SELECT id, project_code, project_name FROM projects WHERE id=:pid ORDER BY project_name", Map.of("pid", scopedProjectId));
        }
        return jdbc.queryForList("SELECT id, project_code, project_name FROM projects ORDER BY project_name", Collections.emptyMap());
    }

    @Override
    public List<Map<String, Object>> fetchCountriesForFilter(Long scopedProjectId, Long selectedProjectId) {
        Long effectiveProjectId = scopedProjectId != null ? scopedProjectId : selectedProjectId;
        if (effectiveProjectId != null) {
            return jdbc.queryForList(
                    "SELECT DISTINCT c.id,c.country_code,c.country_name " +
                            "FROM countries c " +
                            "JOIN project_countries pc ON pc.country_id=c.id " +
                            "WHERE pc.project_id=:projectId " +
                            "ORDER BY c.country_name",
                    Map.of("projectId", effectiveProjectId));
        }
        return jdbc.queryForList("SELECT id,country_code,country_name FROM countries ORDER BY country_name", Collections.emptyMap());
    }
    @Override public List<Map<String, Object>> fetchEventTypesForFilter() { return jdbc.queryForList("SELECT id,event_code,event_name FROM event_types ORDER BY event_name", Collections.emptyMap()); }
    @Override public List<Map<String, Object>> fetchChannelsForFilter() { return jdbc.queryForList("SELECT id,code FROM channels ORDER BY code", Collections.emptyMap()); }
    @Override public List<Map<String, Object>> fetchProvidersForFilter() { return jdbc.queryForList("SELECT id,provider_code,provider_name FROM providers ORDER BY provider_name", Collections.emptyMap()); }

    private String baseDetailSql() {
        return "SELECT nr.request_id, nr.request_uuid, nr.project_id, p.project_code, p.project_name, " +
                "nr.country_id, co.country_code, co.country_name, nr.event_type_id, et.event_code, et.event_name, " +
                "nr.status request_status, nr.payload, nr.created_at request_created_at, " +
                "nl.id log_id, ch.code channel_code, COALESCE(pr.provider_code,nl.provider_code) provider_code, " +
                "nl.recipient, nl.status log_status, nl.attempt_no, nl.retry_count, nl.http_status, " +
                "nl.provider_message_id, nl.provider_response, nl.error_message, nl.latency_ms, " +
                "nl.created_at log_created_at, nl.sent_at, nl.failed_at " +
                "FROM notification_logs nl " +
                "JOIN notification_requests nr ON nr.id = nl.request_id " +
                "LEFT JOIN projects p ON p.id = nr.project_id " +
                "LEFT JOIN countries co ON co.id = nr.country_id " +
                "LEFT JOIN event_types et ON et.id = nr.event_type_id " +
                "LEFT JOIN channels ch ON ch.id = nl.channel_id " +
                "LEFT JOIN providers pr ON pr.id = nl.provider_id ";
    }

    private String buildWhere(ReportFilterRequest filter, Long scopedProjectId, MapSqlParameterSource params, boolean requestOnly) {
        LocalDate from = filter.getFromDate() == null ? LocalDate.now() : filter.getFromDate();
        LocalDate to = filter.getToDate() == null ? LocalDate.now() : filter.getToDate();
        params.addValue("fromDate", Date.valueOf(from));
        params.addValue("toDate", Date.valueOf(to.plusDays(1)));
        StringBuilder sb = new StringBuilder(" WHERE ");
        sb.append(requestOnly ? "nr.created_at >= :fromDate AND nr.created_at < :toDate" : "nl.created_at >= :fromDate AND nl.created_at < :toDate");
        if (scopedProjectId != null) {
            sb.append(" AND nr.project_id = :scopedProjectId");
            params.addValue("scopedProjectId", scopedProjectId);
        } else if (filter.getProjectId() != null) {
            sb.append(" AND nr.project_id = :projectId");
            params.addValue("projectId", filter.getProjectId());
        }
        if (filter.getCountryId() != null) { sb.append(" AND nr.country_id = :countryId"); params.addValue("countryId", filter.getCountryId()); }
        if (filter.getEventTypeId() != null) { sb.append(" AND nr.event_type_id = :eventTypeId"); params.addValue("eventTypeId", filter.getEventTypeId()); }
        if (!requestOnly) {
            if (filter.getChannelId() != null) { sb.append(" AND nl.channel_id = :channelId"); params.addValue("channelId", filter.getChannelId()); }
            if (filter.getProviderId() != null) { sb.append(" AND nl.provider_id = :providerId"); params.addValue("providerId", filter.getProviderId()); }
            if (filter.getRecipient() != null && !filter.getRecipient().isBlank()) {
                sb.append(" AND LOWER(nl.recipient) LIKE :recipient");
                params.addValue("recipient", "%" + filter.getRecipient().trim().toLowerCase() + "%");
            }
        }
        if (filter.getStatus() != null && !filter.getStatus().isBlank()) {
            sb.append(requestOnly ? " AND nr.status = :status" : " AND nl.status = :status");
            params.addValue("status", filter.getStatus().trim().toUpperCase());
        }
        if (filter.getRequestId() != null && !filter.getRequestId().isBlank()) {
            sb.append(" AND nr.request_id LIKE :requestId");
            params.addValue("requestId", "%" + filter.getRequestId().trim() + "%");
        }
        return sb.toString();
    }

    private String resolveSortColumn(String sortBy, String sortDirection) {
        Map<String, String> colMap = new HashMap<>();
        colMap.put("createdAt", "nl.created_at");
        colMap.put("sentAt", "nl.sent_at");
        colMap.put("failedAt", "nl.failed_at");
        colMap.put("status", "nl.status");
        colMap.put("retryCount", "nl.retry_count");
        colMap.put("attemptNo", "nl.attempt_no");
        String col = colMap.getOrDefault(sortBy, "nl.created_at");
        String dir = "ASC".equalsIgnoreCase(sortDirection) ? "ASC" : "DESC";
        return col + " " + dir;
    }
}


