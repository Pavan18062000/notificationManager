package com.zaps.communication.project.entity;

import com.zaps.communication.common.AuditableEntity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "projects", uniqueConstraints = @UniqueConstraint(name = "uk_project_code", columnNames = "project_code"),
        indexes = @Index(name = "idx_project_code", columnList = "project_code"))
@Getter
@Setter
public class Project extends AuditableEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "project_code", nullable = false, length = 50)
    private String projectCode;

    @Column(name = "project_name", nullable = false, length = 120)
    private String projectName;

    @Column(name = "description", length = 1000)
    private String description;

    @Column(name = "api_key_hash", nullable = false, length = 128)
    private String apiKeyHash;

    @Column(name = "api_key_value", length = 255)
    private String apiKeyValue;

    @Column(name = "is_active", nullable = false)
    private boolean active = true;
}
