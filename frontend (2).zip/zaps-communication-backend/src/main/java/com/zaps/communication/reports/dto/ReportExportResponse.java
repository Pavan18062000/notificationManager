package com.zaps.communication.reports.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ReportExportResponse {
    private String fileName;
    private byte[] content;
}

