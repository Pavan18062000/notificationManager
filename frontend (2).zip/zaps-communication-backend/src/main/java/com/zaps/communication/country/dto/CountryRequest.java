package com.zaps.communication.country.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CountryRequest {
    @NotBlank private String countryCode;
    @NotBlank private String countryName;
    private Boolean active = true;
}
