package com.zaps.communication.reports.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NotificationSummaryResponse {
    private long totalRequests;
    private long queued;
    private long processing;
    private long sent;
    private long failed;
    private long accepted;
    private double successRate;
    private double avgLatencyMs;
    private long retryAttempts;
}

