package com.zaps.communication.common.enums;

public enum NotificationStatus {
    QUEUED, ACCEPTED, PROCESSING, SENT, FAILED
}
