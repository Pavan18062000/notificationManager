package com.zaps.communication.reports.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EventSummaryResponse {
    private Long eventTypeId;
    private String eventCode;
    private String eventName;
    private long count;
}

