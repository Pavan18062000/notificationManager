package com.zaps.communication.country.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.zaps.communication.common.exception.DuplicateResourceException;
import com.zaps.communication.common.exception.ResourceNotFoundException;
import com.zaps.communication.country.dto.CountryRequest;
import com.zaps.communication.country.dto.CountryResponse;
import com.zaps.communication.country.entity.Country;
import com.zaps.communication.country.repository.CountryRepository;
import com.zaps.communication.country.service.CountryService;

@Service
public class CountryServiceImpl implements CountryService {
    private final CountryRepository repository;
    public CountryServiceImpl(CountryRepository repository) { this.repository = repository; }

    public CountryResponse create(CountryRequest request) {
        if (repository.existsByCountryCode(request.getCountryCode())) throw new DuplicateResourceException("Country code already exists");
        Country c = new Country();
        c.setCountryCode(request.getCountryCode().trim().toUpperCase());
        c.setCountryName(request.getCountryName().trim());
        c.setActive(Boolean.TRUE.equals(request.getActive()));
        return toResponse(repository.save(c));
    }

    public List<CountryResponse> getAll() { return repository.findAll().stream().map(this::toResponse).toList(); }

    public CountryResponse getById(Long id) { return toResponse(find(id)); }

    public CountryResponse update(Long id, CountryRequest request) {
        Country c = find(id);
        c.setCountryCode(request.getCountryCode().trim().toUpperCase());
        c.setCountryName(request.getCountryName().trim());
        c.setActive(Boolean.TRUE.equals(request.getActive()));
        return toResponse(repository.save(c));
    }

    public void delete(Long id) { repository.delete(find(id)); }

    private Country find(Long id){ return repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Country not found")); }

    private CountryResponse toResponse(Country c){ return CountryResponse.builder().id(c.getId()).countryCode(c.getCountryCode()).countryName(c.getCountryName()).active(c.isActive()).build(); }
}
