package com.zaps.communication.notification.provider;

public interface EmailProvider extends NotificationProvider {
}

