package com.zaps.communication.provider.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ProviderRequest {
    @NotBlank private String providerCode;
    @NotBlank private String providerName;
    private Boolean active = true;
}
