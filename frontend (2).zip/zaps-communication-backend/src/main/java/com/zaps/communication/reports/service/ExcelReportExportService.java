package com.zaps.communication.reports.service;

import java.io.ByteArrayOutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import com.zaps.communication.reports.dto.NotificationDetailResponse;
import com.zaps.communication.reports.dto.NotificationSummaryResponse;
import com.zaps.communication.reports.dto.ProjectSummaryResponse;
import com.zaps.communication.reports.dto.ProviderSummaryResponse;
import com.zaps.communication.reports.dto.ReportExportResponse;
import com.zaps.communication.reports.dto.ReportFilterRequest;
import com.zaps.communication.reports.repository.ReportRepository;
import com.zaps.communication.user.entity.User;
import com.zaps.communication.user.service.AccessScopeService;

@Service
public class ExcelReportExportService {
    private final ReportRepository reportRepository;
    private final AccessScopeService accessScopeService;

    public ExcelReportExportService(ReportRepository reportRepository, AccessScopeService accessScopeService) {
        this.reportRepository = reportRepository;
        this.accessScopeService = accessScopeService;
    }

    public ReportExportResponse export(ReportFilterRequest filter, String authorizationHeader) {
        User user = accessScopeService.requireUser(authorizationHeader);
        Long scopedProjectId = accessScopeService.requiredProjectId(user);
        if (scopedProjectId == null && filter.getProjectId() != null) {
            accessScopeService.assertProjectAccess(user, filter.getProjectId());
        }

        NotificationSummaryResponse summary = reportRepository.fetchSummary(filter, scopedProjectId);
        List<NotificationDetailResponse> details = reportRepository.fetchNotificationDetails(filter, scopedProjectId);
        List<ProjectSummaryResponse> projects = reportRepository.fetchProjectSummary(filter, scopedProjectId);
        List<ProviderSummaryResponse> providers = reportRepository.fetchProviderSummary(filter, scopedProjectId);
        List<NotificationDetailResponse> failures = details.stream().filter(x -> "FAILED".equalsIgnoreCase(x.getStatus())).toList();

        String projectCode = "all-projects";
        if (scopedProjectId != null) {
            List<Map<String, Object>> scoped = reportRepository.fetchProjectsForFilter(scopedProjectId);
            if (!scoped.isEmpty() && scoped.get(0).get("project_code") != null) {
                projectCode = String.valueOf(scoped.get(0).get("project_code"));
            }
        } else if (filter.getProjectId() != null) {
            List<Map<String, Object>> selected = reportRepository.fetchProjectsForFilter(null).stream().filter(p -> filter.getProjectId().equals(((Number) p.get("id")).longValue())).toList();
            if (!selected.isEmpty() && selected.get(0).get("project_code") != null) {
                projectCode = String.valueOf(selected.get(0).get("project_code"));
            }
        }

        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
        String fileName = "notification-report-" + projectCode + "-" + timestamp + ".xlsx";

        try (Workbook wb = new XSSFWorkbook(); ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            CellStyle headerStyle = wb.createCellStyle();
            Font bold = wb.createFont();
            bold.setBold(true);
            headerStyle.setFont(bold);

            buildSummarySheet(wb, headerStyle, summary, filter);
            buildDetailSheet(wb, headerStyle, "Detailed Logs", details);
            buildProjectSheet(wb, headerStyle, projects);
            buildProviderSheet(wb, headerStyle, providers);
            buildFailureSheet(wb, headerStyle, failures);

            wb.write(bos);
            return new ReportExportResponse(fileName, bos.toByteArray());
        } catch (Exception ex) {
            throw new RuntimeException("Failed to export report", ex);
        }
    }

    private void buildSummarySheet(Workbook wb, CellStyle headerStyle, NotificationSummaryResponse s, ReportFilterRequest filter) {
        Sheet sh = wb.createSheet("Summary");
        int r = 0;
        Row f1 = sh.createRow(r++);
        f1.createCell(0).setCellValue("Generated At");
        f1.createCell(1).setCellValue(LocalDateTime.now().toString());
        Row f2 = sh.createRow(r++);
        f2.createCell(0).setCellValue("From Date");
        f2.createCell(1).setCellValue(String.valueOf(filter.getFromDate()));
        Row f3 = sh.createRow(r++);
        f3.createCell(0).setCellValue("To Date");
        f3.createCell(1).setCellValue(String.valueOf(filter.getToDate()));
        r++;

        String[][] rows = {
                {"Total Requests", String.valueOf(s.getTotalRequests())},
                {"Queued", String.valueOf(s.getQueued())},
                {"Processing", String.valueOf(s.getProcessing())},
                {"Sent", String.valueOf(s.getSent())},
                {"Failed", String.valueOf(s.getFailed())},
                {"Accepted", String.valueOf(s.getAccepted())},
                {"Success Rate", String.format("%.2f%%", s.getSuccessRate())},
                {"Avg Latency (ms)", String.format("%.2f", s.getAvgLatencyMs())},
                {"Retry Attempts", String.valueOf(s.getRetryAttempts())}
        };

        for (String[] row : rows) {
            Row x = sh.createRow(r++);
            x.createCell(0).setCellValue(row[0]);
            x.createCell(1).setCellValue(row[1]);
        }

        sh.autoSizeColumn(0);
        sh.autoSizeColumn(1);
    }

    private void buildDetailSheet(Workbook wb, CellStyle headerStyle, String name, List<NotificationDetailResponse> details) {
        Sheet sh = wb.createSheet(name);
        String[] headers = {"Request ID", "Project", "Country", "Event", "Channel", "Provider", "Recipient", "Status", "Attempt", "Retry", "HTTP", "Provider Message ID", "Latency(ms)", "Created At", "Sent At", "Failed At"};
        Row hr = sh.createRow(0);
        for (int i = 0; i < headers.length; i++) {
            Cell c = hr.createCell(i);
            c.setCellValue(headers[i]);
            c.setCellStyle(headerStyle);
        }

        int row = 1;
        for (NotificationDetailResponse d : details) {
            Row r = sh.createRow(row++);
            r.createCell(0).setCellValue(nvl(d.getRequestId()));
            r.createCell(1).setCellValue(nvl(d.getProjectCode()));
            r.createCell(2).setCellValue(nvl(d.getCountryCode()));
            r.createCell(3).setCellValue(nvl(d.getEventCode()));
            r.createCell(4).setCellValue(nvl(d.getChannel()));
            r.createCell(5).setCellValue(nvl(d.getProvider()));
            r.createCell(6).setCellValue(nvl(d.getRecipient()));
            r.createCell(7).setCellValue(nvl(d.getStatus()));
            r.createCell(8).setCellValue(d.getAttemptNo() == null ? "" : String.valueOf(d.getAttemptNo()));
            r.createCell(9).setCellValue(d.getRetryCount() == null ? "" : String.valueOf(d.getRetryCount()));
            r.createCell(10).setCellValue(d.getHttpStatus() == null ? "" : String.valueOf(d.getHttpStatus()));
            r.createCell(11).setCellValue(nvl(d.getProviderMessageId()));
            r.createCell(12).setCellValue(d.getLatencyMs() == null ? "" : String.valueOf(d.getLatencyMs()));
            r.createCell(13).setCellValue(d.getCreatedAt() == null ? "" : d.getCreatedAt().toString());
            r.createCell(14).setCellValue(d.getSentAt() == null ? "" : d.getSentAt().toString());
            r.createCell(15).setCellValue(d.getFailedAt() == null ? "" : d.getFailedAt().toString());
        }

        for (int i = 0; i < headers.length; i++) sh.autoSizeColumn(i);
    }

    private void buildProjectSheet(Workbook wb, CellStyle headerStyle, List<ProjectSummaryResponse> rows) {
        Sheet sh = wb.createSheet("Project Summary");
        String[] headers = {"Project Code", "Project Name", "Count"};
        Row hr = sh.createRow(0);
        for (int i = 0; i < headers.length; i++) {
            Cell c = hr.createCell(i);
            c.setCellValue(headers[i]);
            c.setCellStyle(headerStyle);
        }
        int row = 1;
        for (ProjectSummaryResponse d : rows) {
            Row r = sh.createRow(row++);
            r.createCell(0).setCellValue(nvl(d.getProjectCode()));
            r.createCell(1).setCellValue(nvl(d.getProjectName()));
            r.createCell(2).setCellValue(d.getCount());
        }
        for (int i = 0; i < headers.length; i++) sh.autoSizeColumn(i);
    }

    private void buildProviderSheet(Workbook wb, CellStyle headerStyle, List<ProviderSummaryResponse> rows) {
        Sheet sh = wb.createSheet("Provider Summary");
        String[] headers = {"Provider", "Count", "Avg Latency(ms)"};
        Row hr = sh.createRow(0);
        for (int i = 0; i < headers.length; i++) {
            Cell c = hr.createCell(i);
            c.setCellValue(headers[i]);
            c.setCellStyle(headerStyle);
        }
        int row = 1;
        for (ProviderSummaryResponse d : rows) {
            Row r = sh.createRow(row++);
            r.createCell(0).setCellValue(nvl(d.getProvider()));
            r.createCell(1).setCellValue(d.getCount());
            r.createCell(2).setCellValue(d.getAvgLatencyMs());
        }
        for (int i = 0; i < headers.length; i++) sh.autoSizeColumn(i);
    }

    private void buildFailureSheet(Workbook wb, CellStyle headerStyle, List<NotificationDetailResponse> rows) {
        Sheet sh = wb.createSheet("Failure Details");
        String[] headers = {"Request ID", "Provider", "Recipient", "Status", "Error Message", "Provider Response", "Failed At"};
        Row hr = sh.createRow(0);
        for (int i = 0; i < headers.length; i++) {
            Cell c = hr.createCell(i);
            c.setCellValue(headers[i]);
            c.setCellStyle(headerStyle);
        }
        int row = 1;
        for (NotificationDetailResponse d : rows) {
            Row r = sh.createRow(row++);
            r.createCell(0).setCellValue(nvl(d.getRequestId()));
            r.createCell(1).setCellValue(nvl(d.getProvider()));
            r.createCell(2).setCellValue(nvl(d.getRecipient()));
            r.createCell(3).setCellValue(nvl(d.getStatus()));
            r.createCell(4).setCellValue(nvl(d.getErrorMessage()));
            String providerResponse = nvl(d.getProviderResponse());
            if (providerResponse.length() > 500) providerResponse = providerResponse.substring(0, 500) + "...";
            r.createCell(5).setCellValue(providerResponse);
            r.createCell(6).setCellValue(d.getFailedAt() == null ? "" : d.getFailedAt().toString());
        }
        for (int i = 0; i < headers.length; i++) sh.autoSizeColumn(i);
    }

    private String nvl(String x) {
        return x == null ? "" : x;
    }
}
