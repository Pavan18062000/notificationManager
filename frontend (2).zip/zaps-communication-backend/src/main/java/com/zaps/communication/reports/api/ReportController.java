package com.zaps.communication.reports.api;

import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zaps.communication.common.ApiResponse;
import com.zaps.communication.reports.dto.ReportExportResponse;
import com.zaps.communication.reports.dto.ReportFilterRequest;
import com.zaps.communication.reports.service.ExcelReportExportService;
import com.zaps.communication.reports.service.ReportService;

@RestController
@RequestMapping("/api/v1/reports")
public class ReportController {
    private final ReportService reportService;
    private final ExcelReportExportService excelReportExportService;

    public ReportController(ReportService reportService, ExcelReportExportService excelReportExportService) {
        this.reportService = reportService;
        this.excelReportExportService = excelReportExportService;
    }

    @GetMapping("/notification-summary")
    public ApiResponse<Object> notificationSummary(ReportFilterRequest filter,
            @RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        return ApiResponse.success("Notification summary fetched", reportService.getSummary(filter, authorizationHeader));
    }

    @GetMapping("/notification-trend")
    public ApiResponse<Object> notificationTrend(ReportFilterRequest filter,
            @RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        return ApiResponse.success("Notification trend fetched", reportService.getTrend(filter, authorizationHeader));
    }

    @GetMapping("/status-distribution")
    public ApiResponse<Object> statusDistribution(ReportFilterRequest filter,
            @RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        return ApiResponse.success("Status distribution fetched", reportService.getStatusDistribution(filter, authorizationHeader));
    }

    @GetMapping("/channel-summary")
    public ApiResponse<Object> channelSummary(ReportFilterRequest filter,
            @RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        return ApiResponse.success("Channel summary fetched", reportService.getChannelSummary(filter, authorizationHeader));
    }

    @GetMapping("/provider-summary")
    public ApiResponse<Object> providerSummary(ReportFilterRequest filter,
            @RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        return ApiResponse.success("Provider summary fetched", reportService.getProviderSummary(filter, authorizationHeader));
    }

    @GetMapping("/project-summary")
    public ApiResponse<Object> projectSummary(ReportFilterRequest filter,
            @RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        return ApiResponse.success("Project summary fetched", reportService.getProjectSummary(filter, authorizationHeader));
    }

    @GetMapping("/event-summary")
    public ApiResponse<Object> eventSummary(ReportFilterRequest filter,
            @RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        return ApiResponse.success("Event summary fetched", reportService.getEventSummary(filter, authorizationHeader));
    }

    @GetMapping("/notification-details")
    public ApiResponse<Map<String, Object>> notificationDetails(ReportFilterRequest filter,
            @RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        return ApiResponse.success("Notification details fetched", reportService.getNotificationDetails(filter, authorizationHeader));
    }

    @GetMapping("/notification-details/{requestId}")
    public ApiResponse<Object> notificationDetailsByRequestId(@PathVariable String requestId,
            @RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        return ApiResponse.success("Notification detail fetched", reportService.getNotificationDetailsByRequestId(requestId, authorizationHeader));
    }

    @GetMapping("/filters/projects")
    public ApiResponse<Object> filterProjects(@RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        return ApiResponse.success("Projects fetched", reportService.getFilterLookups(authorizationHeader, null).get("projects"));
    }

    @GetMapping("/filters/countries")
    public ApiResponse<Object> filterCountries(
            @RequestParam(value = "projectId", required = false) Long projectId,
            @RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        return ApiResponse.success("Countries fetched", reportService.getFilterLookups(authorizationHeader, projectId).get("countries"));
    }

    @GetMapping("/filters/event-types")
    public ApiResponse<Object> filterEvents(@RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        return ApiResponse.success("Event types fetched", reportService.getFilterLookups(authorizationHeader, null).get("eventTypes"));
    }

    @GetMapping("/filters/channels")
    public ApiResponse<Object> filterChannels(@RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        return ApiResponse.success("Channels fetched", reportService.getFilterLookups(authorizationHeader, null).get("channels"));
    }

    @GetMapping("/filters/providers")
    public ApiResponse<Object> filterProviders(@RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        return ApiResponse.success("Providers fetched", reportService.getFilterLookups(authorizationHeader, null).get("providers"));
    }

    @GetMapping("/filters")
    public ApiResponse<Object> filters(
            @RequestParam(value = "projectId", required = false) Long projectId,
            @RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        return ApiResponse.success("Report filter lookups fetched", reportService.getFilterLookups(authorizationHeader, projectId));
    }

    @GetMapping("/export/excel")
    public ResponseEntity<byte[]> exportExcel(ReportFilterRequest filter,
            @RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        ReportExportResponse export = excelReportExportService.export(filter, authorizationHeader);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + export.getFileName() + "\"")
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(export.getContent());
    }
}
