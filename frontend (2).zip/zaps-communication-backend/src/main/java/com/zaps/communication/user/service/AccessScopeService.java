package com.zaps.communication.user.service;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.zaps.communication.user.entity.User;
import com.zaps.communication.user.entity.UserRole;

@Service
public class AccessScopeService {
    private final AuthService authService;

    public AccessScopeService(AuthService authService) {
        this.authService = authService;
    }

    public User requireUser(String authorizationHeader) {
        return authService.requireUser(authorizationHeader);
    }

    public boolean isSuperAdmin(User user) {
        return user.getRole() == UserRole.SUPER_ADMIN;
    }

    public Long requiredProjectId(User user) {
        if (isSuperAdmin(user)) return null;
        if (user.getProject() == null) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "PROJECT_ADMIN must be assigned to a project");
        }
        return user.getProject().getId();
    }

    public void assertProjectAccess(User user, Long projectId) {
        if (projectId == null) return;
        Long assigned = requiredProjectId(user);
        if (assigned != null && !assigned.equals(projectId)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You are not allowed to access another project");
        }
    }

    public void assertProjectCodeAccess(User user, String projectCode) {
        if (projectCode == null) return;
        Long assigned = requiredProjectId(user);
        if (assigned == null) return;
        String assignedCode = user.getProject() != null ? user.getProject().getProjectCode() : null;
        if (assignedCode == null || !assignedCode.equalsIgnoreCase(projectCode.trim())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You are not allowed to access another project");
        }
    }
}
