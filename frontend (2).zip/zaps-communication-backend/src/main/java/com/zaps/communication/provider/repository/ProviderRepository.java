package com.zaps.communication.provider.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zaps.communication.provider.entity.Provider;

public interface ProviderRepository extends JpaRepository<Provider, Long> {
    boolean existsByProviderCode(String providerCode);
    boolean existsByProviderCodeIgnoreCase(String providerCode);
}
