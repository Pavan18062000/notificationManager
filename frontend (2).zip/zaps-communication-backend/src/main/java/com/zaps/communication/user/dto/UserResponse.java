package com.zaps.communication.user.dto;

import com.zaps.communication.user.entity.UserRole;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserResponse {
    private Long id;
    private String email;
    private UserRole role;
    private Boolean active;
    private Long projectId;
    private String projectCode;
    private String projectName;
}
