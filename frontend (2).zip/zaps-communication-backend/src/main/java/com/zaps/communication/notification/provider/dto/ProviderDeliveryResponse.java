package com.zaps.communication.notification.provider.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ProviderDeliveryResponse {
    private boolean success;
    private String providerCode;
    private String providerMessageId;
    private String providerResponse;
    private Integer httpStatus;
    private Long latencyMs;
    private String errorMessage;
    private boolean retryable;
}

