package com.zaps.communication.routing.service.impl;

import java.util.List;
import java.util.Objects;

import org.springframework.stereotype.Service;

import com.zaps.communication.channel.repository.ChannelRepository;
import com.zaps.communication.common.exception.DuplicateResourceException;
import com.zaps.communication.common.exception.ResourceNotFoundException;
import com.zaps.communication.country.repository.CountryRepository;
import com.zaps.communication.event.repository.EventTypeRepository;
import com.zaps.communication.project.repository.ProjectRepository;
import com.zaps.communication.provider.repository.ProviderRepository;
import com.zaps.communication.routing.dto.NotificationRouteRequest;
import com.zaps.communication.routing.dto.NotificationRouteResponse;
import com.zaps.communication.routing.entity.NotificationRoute;
import com.zaps.communication.routing.repository.NotificationRouteRepository;
import com.zaps.communication.routing.service.NotificationRouteService;

@Service
public class NotificationRouteServiceImpl implements NotificationRouteService {
    private final NotificationRouteRepository notificationRouteRepository;
    private final ProjectRepository projectRepository;
    private final CountryRepository countryRepository;
    private final ChannelRepository channelRepository;
    private final EventTypeRepository eventTypeRepository;
    private final ProviderRepository providerRepository;

    public NotificationRouteServiceImpl(NotificationRouteRepository notificationRouteRepository, ProjectRepository projectRepository, CountryRepository countryRepository, ChannelRepository channelRepository, EventTypeRepository eventTypeRepository, ProviderRepository providerRepository) {
        this.notificationRouteRepository = notificationRouteRepository;
        this.projectRepository = projectRepository;
        this.countryRepository = countryRepository;
        this.channelRepository = channelRepository;
        this.eventTypeRepository = eventTypeRepository;
        this.providerRepository = providerRepository;
    }

    @Override
    public List<NotificationRouteResponse> getAll(Long scopedProjectId) {
        return notificationRouteRepository.findAll().stream()
                .map(r -> safeToResponse(r, scopedProjectId))
                .filter(Objects::nonNull)
                .toList();
    }

    private NotificationRouteResponse safeToResponse(NotificationRoute route, Long scopedProjectId) {
        try {
            NotificationRouteResponse response = toResponse(route);
            if (scopedProjectId != null && !scopedProjectId.equals(response.getProjectId())) {
                return null;
            }
            return response;
        } catch (Exception ex) {
            return null;
        }
    }

    @Override
    public NotificationRouteResponse create(NotificationRouteRequest request) {
        boolean exists = hasDuplicate(null, request);
        if (exists) {
            throw new DuplicateResourceException("Notification route already exists for selected project/country/channel/event/provider");
        }

        NotificationRoute r = new NotificationRoute();
        r.setProject(projectRepository.findById(request.getProjectId()).orElseThrow(() -> new ResourceNotFoundException("Project not found")));
        r.setCountry(request.getCountryId() == null ? null : countryRepository.findById(request.getCountryId()).orElseThrow(() -> new ResourceNotFoundException("Country not found")));
        r.setChannel(channelRepository.findById(request.getChannelId()).orElseThrow(() -> new ResourceNotFoundException("Channel not found")));
        r.setEventType(request.getEventTypeId() == null ? null : eventTypeRepository.findById(request.getEventTypeId()).orElseThrow(() -> new ResourceNotFoundException("Event type not found")));
        r.setProvider(providerRepository.findById(request.getProviderId()).orElseThrow(() -> new ResourceNotFoundException("Provider not found")));
        r.setPriority(request.getPriority());
        r.setEnabled(Boolean.TRUE.equals(request.getEnabled()));
        r.setRateLimitPerMinute(request.getRateLimitPerMinute());
        r.setMaxRetries(request.getMaxRetries());
        r.setFromEmail(trimToNull(request.getFromEmail()));
        r.setSenderId(trimToNull(request.getSenderId()));
        r.setProviderApiKey(trimToNull(request.getProviderApiKey()));
        r.setProviderAccountKey(defaultProviderAccountKey(trimToNull(request.getProviderAccountKey())));
        r.setConfigJson(trimToNull(request.getConfigJson()));
        return toResponse(notificationRouteRepository.save(r));
    }

    @Override
    public NotificationRouteResponse update(Long id, NotificationRouteRequest request) {
        NotificationRoute r = notificationRouteRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notification route not found"));

        boolean exists = hasDuplicate(id, request);
        if (exists) {
            throw new DuplicateResourceException("Notification route already exists for selected project/country/channel/event/provider");
        }

        r.setProject(projectRepository.findById(request.getProjectId()).orElseThrow(() -> new ResourceNotFoundException("Project not found")));
        r.setCountry(request.getCountryId() == null ? null : countryRepository.findById(request.getCountryId()).orElseThrow(() -> new ResourceNotFoundException("Country not found")));
        r.setChannel(channelRepository.findById(request.getChannelId()).orElseThrow(() -> new ResourceNotFoundException("Channel not found")));
        r.setEventType(request.getEventTypeId() == null ? null : eventTypeRepository.findById(request.getEventTypeId()).orElseThrow(() -> new ResourceNotFoundException("Event type not found")));
        r.setProvider(providerRepository.findById(request.getProviderId()).orElseThrow(() -> new ResourceNotFoundException("Provider not found")));
        r.setPriority(request.getPriority());
        r.setEnabled(Boolean.TRUE.equals(request.getEnabled()));
        r.setRateLimitPerMinute(request.getRateLimitPerMinute());
        r.setMaxRetries(request.getMaxRetries());
        r.setFromEmail(trimToNull(request.getFromEmail()));
        r.setSenderId(trimToNull(request.getSenderId()));
        r.setProviderApiKey(trimToNull(request.getProviderApiKey()));
        r.setProviderAccountKey(defaultProviderAccountKey(trimToNull(request.getProviderAccountKey())));
        r.setConfigJson(trimToNull(request.getConfigJson()));
        return toResponse(notificationRouteRepository.save(r));
    }

    private NotificationRouteResponse toResponse(NotificationRoute c) {
        return NotificationRouteResponse.builder()
                .id(c.getId())
                .projectId(c.getProject() == null ? null : c.getProject().getId())
                .countryId(c.getCountry() == null ? null : c.getCountry().getId())
                .channelId(c.getChannel() == null ? null : c.getChannel().getId())
                .eventTypeId(c.getEventType() == null ? null : c.getEventType().getId())
                .providerId(c.getProvider() == null ? null : c.getProvider().getId())
                .priority(c.getPriority())
                .enabled(c.isEnabled())
                .rateLimitPerMinute(c.getRateLimitPerMinute())
                .maxRetries(c.getMaxRetries())
                .fromEmail(c.getFromEmail())
                .senderId(c.getSenderId())
                .providerAccountKey(c.getProviderAccountKey())
                .build();
    }

    private String trimToNull(String value) {
        if (value == null) return null;
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    private boolean sameId(Long a, Long b) {
        return Objects.equals(a, b);
    }

    private String defaultProviderAccountKey(String key) {
        return key == null ? "default" : key;
    }

    private boolean hasDuplicate(Long excludeId, NotificationRouteRequest request) {
        return notificationRouteRepository.findAll().stream()
                .filter(existing -> excludeId == null || !excludeId.equals(existing.getId()))
                .anyMatch(existing ->
                        sameId(existing.getProject() == null ? null : existing.getProject().getId(), request.getProjectId()) &&
                        sameId(existing.getCountry() == null ? null : existing.getCountry().getId(), request.getCountryId()) &&
                        sameId(existing.getChannel() == null ? null : existing.getChannel().getId(), request.getChannelId()) &&
                        sameId(existing.getEventType() == null ? null : existing.getEventType().getId(), request.getEventTypeId()) &&
                        sameId(existing.getProvider() == null ? null : existing.getProvider().getId(), request.getProviderId())
                );
    }
}
