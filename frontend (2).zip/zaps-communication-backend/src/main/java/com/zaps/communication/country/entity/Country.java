package com.zaps.communication.country.entity;

import com.zaps.communication.common.AuditableEntity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "countries", uniqueConstraints = @UniqueConstraint(name = "uk_country_code", columnNames = "countryCode"),
        indexes = @Index(name = "idx_country_code", columnList = "countryCode"))
@Getter
@Setter
public class Country extends AuditableEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 10)
    private String countryCode;
    @Column(nullable = false, length = 100)
    private String countryName;
    @Column(name = "is_active", nullable = false)
    private boolean active = true;
}
