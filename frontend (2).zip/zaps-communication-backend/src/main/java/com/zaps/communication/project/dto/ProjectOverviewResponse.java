package com.zaps.communication.project.dto;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ProjectOverviewResponse {
    private ProjectDetails project;
    private List<CountryItem> countries;
    private List<ChannelItem> channels;
    private List<ProviderConfigItem> providerConfigs;
    private List<TemplateItem> templates;
    private Summary summary;
    private List<ChannelStat> channelStats;
    private List<FailedLogItem> failedLogs;
    private Map<String, QueueStatus> queueStatus;

    @Data
    @Builder
    public static class ProjectDetails {
        private Long id;
        private String projectCode;
        private String projectName;
        private String description;
        private boolean active;
        private LocalDateTime createdAt;
        private boolean apiKeyConfigured;
        private String apiKeyMasked;
        private LocalDateTime apiKeyUpdatedAt;
    }

    @Data
    @Builder
    public static class CountryItem {
        private Long id;
        private String countryCode;
        private String countryName;
        private boolean enabled;
        private boolean defaultCountry;
        private boolean active;
    }

    @Data
    @Builder
    public static class ChannelItem {
        private Long id;
        private String channelCode;
        private Integer rateLimit;
        private Integer retryCount;
        private boolean enabled;
    }

    @Data
    @Builder
    public static class ProviderConfigItem {
        private Long id;
        private String countryName;
        private String channelCode;
        private String providerName;
        private String providerType;
        private Integer priority;
        private String senderId;
        private String fromEmail;
        private boolean active;
    }

    @Data
    @Builder
    public static class TemplateItem {
        private Long id;
        private String templateName;
        private String channelCode;
        private String eventType;
        private String countryName;
        private String subject;
        private boolean active;
    }

    @Data
    @Builder
    public static class Summary {
        private long totalRequests;
        private long sent;
        private long failed;
        private long pending;
        private long processing;
        private long retryableFailed;
    }

    @Data
    @Builder
    public static class ChannelStat {
        private String channelCode;
        private long sent;
        private long failed;
    }

    @Data
    @Builder
    public static class FailedLogItem {
        private Long id;
        private String requestId;
        private String channel;
        private String recipient;
        private String provider;
        private String errorMessage;
        private LocalDateTime createdAt;
        private Integer retryCount;
        private String status;
    }

    @Data
    @Builder
    public static class QueueStatus {
        private int ready;
        private int unacked;
        private int consumers;
    }
}
