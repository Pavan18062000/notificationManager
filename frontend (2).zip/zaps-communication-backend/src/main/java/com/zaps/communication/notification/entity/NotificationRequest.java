package com.zaps.communication.notification.entity;

import com.zaps.communication.common.AuditableEntity;
import com.zaps.communication.common.enums.NotificationStatus;
import com.zaps.communication.country.entity.Country;
import com.zaps.communication.event.entity.EventType;
import com.zaps.communication.project.entity.Project;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "notification_requests", indexes = {
        @Index(name = "idx_nr_request_id", columnList = "requestId", unique = true),
        @Index(name = "idx_nr_lookup", columnList = "project_id,country_id,event_type_id")
})
@Getter
@Setter
public class NotificationRequest extends AuditableEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, unique = true)
    private String requestId;
    @Column(name = "request_uuid", unique = true)
    private String requestUuid;
    @ManyToOne(optional = false) @JoinColumn(name = "project_id")
    private Project project;
    @ManyToOne(optional = false) @JoinColumn(name = "country_id")
    private Country country;
    @ManyToOne(optional = false) @JoinColumn(name = "event_type_id")
    private EventType eventType;
    @Column(columnDefinition = "TEXT")
    private String payload;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private NotificationStatus status;
}
