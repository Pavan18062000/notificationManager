package com.zaps.communication.event.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class EventTypeRequest {
    @NotBlank private String eventCode;
    @NotBlank private String eventName;
}
