package com.zaps.communication.provider.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ProviderResponse {
    private Long id;
    private String providerCode;
    private String providerName;
    private boolean active;
}
