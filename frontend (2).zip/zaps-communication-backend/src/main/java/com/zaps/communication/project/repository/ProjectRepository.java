package com.zaps.communication.project.repository;

import java.util.Optional;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zaps.communication.project.entity.Project;

public interface ProjectRepository extends JpaRepository<Project, Long> {
    Optional<Project> findByProjectCode(String projectCode);
    Optional<Project> findByApiKeyHash(String apiKeyHash);
    Optional<Project> findByApiKeyValue(String apiKeyValue);
    boolean existsByProjectCode(String projectCode);
    List<Project> findByIdIn(List<Long> ids);
}
