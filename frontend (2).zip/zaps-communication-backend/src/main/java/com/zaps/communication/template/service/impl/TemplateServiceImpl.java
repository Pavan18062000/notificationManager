package com.zaps.communication.template.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.zaps.communication.channel.repository.ChannelRepository;
import com.zaps.communication.common.exception.ResourceNotFoundException;
import com.zaps.communication.country.repository.CountryRepository;
import com.zaps.communication.event.repository.EventTypeRepository;
import com.zaps.communication.project.repository.ProjectRepository;
import com.zaps.communication.template.dto.TemplateRequest;
import com.zaps.communication.template.dto.TemplateResponse;
import com.zaps.communication.template.entity.Template;
import com.zaps.communication.template.repository.TemplateRepository;
import com.zaps.communication.template.service.TemplateService;

@Service
public class TemplateServiceImpl implements TemplateService {
    private final TemplateRepository repository;
    private final ProjectRepository projectRepository;
    private final CountryRepository countryRepository;
    private final ChannelRepository channelRepository;
    private final EventTypeRepository eventTypeRepository;

    public TemplateServiceImpl(TemplateRepository repository, ProjectRepository projectRepository, CountryRepository countryRepository,
                               ChannelRepository channelRepository, EventTypeRepository eventTypeRepository) {
        this.repository = repository;
        this.projectRepository = projectRepository;
        this.countryRepository = countryRepository;
        this.channelRepository = channelRepository;
        this.eventTypeRepository = eventTypeRepository;
    }

    public TemplateResponse create(TemplateRequest request) {
        return toResponse(repository.save(build(new Template(), request)));
    }

    public List<TemplateResponse> getAll() { return repository.findAll().stream().map(this::toResponse).toList(); }
    public List<TemplateResponse> getAll(Long projectId) { return repository.findByProjectId(projectId).stream().map(this::toResponse).toList(); }

    public List<TemplateResponse> search(Long projectId, Long countryId, Long channelId, Long eventTypeId) {
        return repository.findByProjectIdAndCountryIdAndChannelIdAndEventTypeId(projectId, countryId, channelId, eventTypeId).stream().map(this::toResponse).toList();
    }

    public TemplateResponse update(Long id, TemplateRequest request) {
        Template t = repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Template not found"));
        return toResponse(repository.save(build(t, request)));
    }

    private Template build(Template t, TemplateRequest request) {
        t.setProject(projectRepository.findById(request.getProjectId()).orElseThrow(() -> new ResourceNotFoundException("Project not found")));
        t.setCountry(countryRepository.findById(request.getCountryId()).orElseThrow(() -> new ResourceNotFoundException("Country not found")));
        t.setChannel(channelRepository.findById(request.getChannelId()).orElseThrow(() -> new ResourceNotFoundException("Channel not found")));
        t.setEventType(eventTypeRepository.findById(request.getEventTypeId()).orElseThrow(() -> new ResourceNotFoundException("Event type not found")));
        t.setTemplateName(request.getTemplateName());
        t.setLanguage(request.getLanguage());
        t.setSubject(request.getSubject());
        t.setBody(request.getBody());
        t.setActive(Boolean.TRUE.equals(request.getActive()));
        return t;
    }

    private TemplateResponse toResponse(Template t) {
        return TemplateResponse.builder().id(t.getId()).projectId(t.getProject().getId()).countryId(t.getCountry().getId())
                .channelId(t.getChannel().getId()).eventTypeId(t.getEventType().getId()).templateName(t.getTemplateName())
                .language(t.getLanguage()).subject(t.getSubject()).body(t.getBody()).active(t.isActive()).build();
    }
}
