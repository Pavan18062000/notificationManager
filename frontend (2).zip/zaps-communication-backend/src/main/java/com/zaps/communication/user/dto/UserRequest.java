package com.zaps.communication.user.dto;

import com.zaps.communication.user.entity.UserRole;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class UserRequest {
    @Email
    @NotBlank
    private String email;

    private String password;

    private Long projectId;

    @NotNull
    private UserRole role;

    @NotNull
    private Boolean active;
}

