package com.zaps.communication.notification.provider;

public interface SmsProvider extends NotificationProvider {
}

