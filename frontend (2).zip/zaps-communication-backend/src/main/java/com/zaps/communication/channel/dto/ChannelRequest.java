package com.zaps.communication.channel.dto;

import com.zaps.communication.common.enums.ChannelCode;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ChannelRequest {
    @NotNull private ChannelCode code;
    private Boolean active = true;
}
