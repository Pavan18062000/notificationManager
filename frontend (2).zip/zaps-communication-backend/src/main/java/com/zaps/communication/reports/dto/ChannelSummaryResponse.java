package com.zaps.communication.reports.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ChannelSummaryResponse {
    private Long channelId;
    private String channel;
    private long count;
}

