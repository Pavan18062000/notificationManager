package com.zaps.communication.notification.dto;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NotificationSendResponse {
    private String requestId;
    private String status;
    private List<ChannelResult> results;

    @Data
    @Builder
    public static class ChannelResult {
        private String channel;
        private String provider;
        private String recipient;
        private String status;
    }
}
