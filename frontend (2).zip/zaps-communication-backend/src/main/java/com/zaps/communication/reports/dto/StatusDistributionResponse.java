package com.zaps.communication.reports.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class StatusDistributionResponse {
    private String status;
    private long count;
}

