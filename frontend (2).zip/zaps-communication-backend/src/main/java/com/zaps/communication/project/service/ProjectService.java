package com.zaps.communication.project.service;

import java.util.List;

import com.zaps.communication.project.dto.ProjectApiKeyResponse;
import com.zaps.communication.project.dto.ProjectRequest;
import com.zaps.communication.project.dto.ProjectResponse;

public interface ProjectService {
    ProjectResponse create(ProjectRequest request);
    List<ProjectResponse> getAll();
    List<ProjectResponse> getAllByIds(List<Long> ids);
    ProjectResponse getById(Long id);
    ProjectResponse update(Long id, ProjectRequest request);
    ProjectApiKeyResponse getApiKey(Long id);
    ProjectApiKeyResponse regenerateApiKey(Long id);
    void delete(Long id);
}
