package com.zaps.communication.notification.dto;

import java.time.LocalDateTime;
import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NotificationTimelineResponse {
    private String requestId;
    private String requestUuid;
    private String projectCode;
    private String countryCode;
    private String eventCode;
    private String status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private List<AttemptItem> attempts;

    @Data
    @Builder
    public static class AttemptItem {
        private Long deliveryId;
        private Integer attemptNo;
        private Integer retryCount;
        private String channel;
        private String providerCode;
        private String recipient;
        private String status;
        private Integer httpStatus;
        private String providerMessageId;
        private String errorMessage;
        private Long latencyMs;
        private LocalDateTime sentAt;
        private LocalDateTime failedAt;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
    }
}

