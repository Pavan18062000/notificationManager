package com.zaps.communication.provider.service;

import java.util.List;

import com.zaps.communication.provider.dto.ProviderRequest;
import com.zaps.communication.provider.dto.ProviderResponse;

public interface ProviderService {
    ProviderResponse create(ProviderRequest request);
    List<ProviderResponse> getAll();
    ProviderResponse update(Long id, ProviderRequest request);
}
