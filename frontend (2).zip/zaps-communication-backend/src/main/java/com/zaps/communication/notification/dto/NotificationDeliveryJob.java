package com.zaps.communication.notification.dto;

import java.io.Serializable;
import java.util.Map;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NotificationDeliveryJob implements Serializable {
    private static final long serialVersionUID = 1L;
    private String requestId;
    private Long deliveryId;
    private Long projectId;
    private String projectCode;
    private String countryCode;
    private String eventCode;
    private String channel;
    private String providerCode;
    private String recipient;
    private String subject;
    private String body;
    private Map<String, Object> templateData;
    private Map<String, Object> metadata;
    private String correlationId;
    private Long createdAt;
    private String providerApiKey;
    private String fromEmail;
}
