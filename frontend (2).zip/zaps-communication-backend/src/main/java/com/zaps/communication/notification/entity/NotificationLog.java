package com.zaps.communication.notification.entity;

import com.zaps.communication.channel.entity.Channel;
import com.zaps.communication.common.AuditableEntity;
import com.zaps.communication.common.enums.NotificationStatus;
import com.zaps.communication.country.entity.Country;
import com.zaps.communication.project.entity.Project;
import com.zaps.communication.provider.entity.Provider;
import com.zaps.communication.template.entity.Template;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "notification_logs", indexes = @Index(name = "idx_nl_req", columnList = "request_id"))
@Getter
@Setter
public class NotificationLog extends AuditableEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(optional = false) @JoinColumn(name = "request_id")
    private NotificationRequest request;
    @ManyToOne(optional = false) @JoinColumn(name = "project_id")
    private Project project;
    @ManyToOne(optional = false) @JoinColumn(name = "country_id")
    private Country country;
    @ManyToOne(optional = false) @JoinColumn(name = "channel_id")
    private Channel channel;
    @ManyToOne @JoinColumn(name = "provider_id")
    private Provider provider;
    @ManyToOne @JoinColumn(name = "template_id")
    private Template template;
    private String recipient;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private NotificationStatus status;
    @Column(nullable = false)
    private Integer retryCount = 0;
    @Column(name = "attempt_no")
    private Integer attemptNo = 1;
    @Column(name = "provider_code", length = 64)
    private String providerCode;
    @Column(name = "http_status")
    private Integer httpStatus;
    @Column(name = "provider_message_id", length = 255)
    private String providerMessageId;
    @Column(name = "provider_response", columnDefinition = "TEXT")
    private String providerResponse;
    @Column(name = "error_message", columnDefinition = "TEXT")
    private String errorMessage;
    @Column(name = "latency_ms")
    private Long latencyMs;
    @Column(name = "sent_at")
    private java.time.LocalDateTime sentAt;
    @Column(name = "failed_at")
    private java.time.LocalDateTime failedAt;
}
