package com.zaps.communication.reports.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.zaps.communication.reports.dto.NotificationDetailResponse;
import org.springframework.jdbc.core.RowMapper;

public final class ReportRowMapper {
    private ReportRowMapper() {}

    public static RowMapper<NotificationDetailResponse> notificationDetailRowMapper() {
        return new RowMapper<>() {
            @Override
            public NotificationDetailResponse mapRow(ResultSet rs, int rowNum) throws SQLException {
                NotificationDetailResponse d = new NotificationDetailResponse();
                d.setRequestId(rs.getString("request_id"));
                d.setRequestUuid(rs.getString("request_uuid"));
                d.setProjectId(rs.getLong("project_id"));
                d.setProjectCode(rs.getString("project_code"));
                d.setProjectName(rs.getString("project_name"));
                d.setCountryId(rs.getLong("country_id"));
                d.setCountryCode(rs.getString("country_code"));
                d.setCountryName(rs.getString("country_name"));
                d.setEventTypeId(rs.getLong("event_type_id"));
                d.setEventCode(rs.getString("event_code"));
                d.setEventName(rs.getString("event_name"));
                d.setRequestStatus(rs.getString("request_status"));
                d.setPayload(rs.getString("payload"));
                d.setRequestCreatedAt(rs.getTimestamp("request_created_at") == null ? null : rs.getTimestamp("request_created_at").toLocalDateTime());
                d.setLogId(rs.getLong("log_id"));
                d.setChannel(rs.getString("channel_code"));
                d.setProvider(rs.getString("provider_code"));
                d.setRecipient(rs.getString("recipient"));
                d.setStatus(rs.getString("log_status"));
                d.setAttemptNo((Integer) rs.getObject("attempt_no"));
                d.setRetryCount((Integer) rs.getObject("retry_count"));
                d.setHttpStatus((Integer) rs.getObject("http_status"));
                d.setProviderMessageId(rs.getString("provider_message_id"));
                d.setProviderResponse(rs.getString("provider_response"));
                d.setErrorMessage(rs.getString("error_message"));
                d.setLatencyMs((Long) rs.getObject("latency_ms"));
                d.setCreatedAt(rs.getTimestamp("log_created_at") == null ? null : rs.getTimestamp("log_created_at").toLocalDateTime());
                d.setSentAt(rs.getTimestamp("sent_at") == null ? null : rs.getTimestamp("sent_at").toLocalDateTime());
                d.setFailedAt(rs.getTimestamp("failed_at") == null ? null : rs.getTimestamp("failed_at").toLocalDateTime());
                return d;
            }
        };
    }
}

