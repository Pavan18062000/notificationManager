package com.zaps.communication.notification.service;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class SendgridEmailService {
    private static final String SENDGRID_URL = "https://api.sendgrid.com/v3/mail/send";
    private final RestTemplate restTemplate = new RestTemplate();

    public void send(String apiKey, String fromEmail, String toEmail, String subject, String body) {
        ResponseEntity<String> response = sendWithResponse(apiKey, fromEmail, toEmail, subject, body);
        if (!response.getStatusCode().is2xxSuccessful()) {
            throw new IllegalStateException("SendGrid send failed with status " + response.getStatusCode().value());
        }
    }

    public ResponseEntity<String> sendWithResponse(String apiKey, String fromEmail, String toEmail, String subject, String body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(apiKey);

        Map<String, Object> payload = Map.of(
                "personalizations", List.of(Map.of("to", List.of(Map.of("email", toEmail)))),
                "from", Map.of("email", fromEmail),
                "subject", subject,
                "content", List.of(Map.of("type", "text/html", "value", body))
        );

        return restTemplate.postForEntity(SENDGRID_URL, new HttpEntity<>(payload, headers), String.class);
    }
}
