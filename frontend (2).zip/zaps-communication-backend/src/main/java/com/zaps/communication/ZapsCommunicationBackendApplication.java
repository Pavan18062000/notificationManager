package com.zaps.communication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class ZapsCommunicationBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZapsCommunicationBackendApplication.class, args);
	}

}
