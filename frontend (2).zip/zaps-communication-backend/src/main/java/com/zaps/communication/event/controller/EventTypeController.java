package com.zaps.communication.event.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.zaps.communication.common.ApiResponse;
import com.zaps.communication.event.dto.EventTypeRequest;
import com.zaps.communication.event.dto.EventTypeResponse;
import com.zaps.communication.event.service.EventTypeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/event-types")
public class EventTypeController {
    private final EventTypeService service;
    public EventTypeController(EventTypeService service) { this.service = service; }

    @PostMapping public ApiResponse<EventTypeResponse> create(@Valid @RequestBody EventTypeRequest request){ return ApiResponse.success("Event type created", service.create(request)); }
    @GetMapping public ApiResponse<List<EventTypeResponse>> getAll(){ return ApiResponse.success("Event types fetched", service.getAll()); }
}
