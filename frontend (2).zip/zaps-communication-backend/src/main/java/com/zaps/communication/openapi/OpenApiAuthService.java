package com.zaps.communication.openapi;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zaps.communication.project.entity.Project;
import com.zaps.communication.project.repository.ProjectRepository;

@Service
public class OpenApiAuthService {
    private static final Logger log = LoggerFactory.getLogger(OpenApiAuthService.class);
    private final ProjectRepository projectRepository;

    public OpenApiAuthService(ProjectRepository projectRepository) {
        this.projectRepository = projectRepository;
    }

    @Transactional
    public Project requireProjectFromApiKey(String apiKey) {
        if (apiKey == null || apiKey.isBlank()) {
            log.warn("Open API auth failed: missing x-api-key header");
            throw new OpenApiException(HttpStatus.UNAUTHORIZED, OpenApiErrorCode.MISSING_API_KEY, "Missing API key");
        }
        String raw = apiKey.trim();
        String hash = sha256(raw);
        String masked = mask(raw);

        // Primary check: exact key value match from DB (as requested flow).
        Project project = projectRepository.findByApiKeyValue(raw).orElse(null);

        // Compatibility check: older rows that only have hash.
        if (project == null) {
            project = projectRepository.findByApiKeyHash(hash).orElse(null);
        }

        // Self-heal hash if key value matched but hash is stale/missing.
        if (project != null && (project.getApiKeyHash() == null || !hash.equals(project.getApiKeyHash()))) {
            project.setApiKeyHash(hash);
            projectRepository.save(project);
        }

        if (project == null) {
            log.warn("Open API auth failed: invalid key {}", masked);
            throw new OpenApiException(HttpStatus.UNAUTHORIZED, OpenApiErrorCode.INVALID_API_KEY, "Invalid API key");
        }
        if (!project.isActive()) {
            log.warn("Open API auth failed: inactive project {} for key {}", project.getProjectCode(), masked);
            throw new OpenApiException(HttpStatus.FORBIDDEN, OpenApiErrorCode.PROJECT_INACTIVE, "Project inactive");
        }
        log.info("Open API auth success: project={} key={}", project.getProjectCode(), masked);
        return project;
    }

    private String mask(String raw) {
        if (raw == null || raw.length() < 6) return "***";
        return raw.substring(0, 6) + "..." + raw.substring(raw.length() - 4);
    }

    public String sha256(String raw) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(raw.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(bytes.length * 2);
            for (byte b : bytes) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }
}
