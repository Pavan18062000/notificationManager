package com.zaps.communication.reports.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ProjectSummaryResponse {
    private Long projectId;
    private String projectCode;
    private String projectName;
    private long count;
}

