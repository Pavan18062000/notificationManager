package com.zaps.communication.project.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.zaps.communication.common.ApiResponse;
import com.zaps.communication.project.dto.ProjectRequest;
import com.zaps.communication.project.dto.ProjectApiKeyResponse;
import com.zaps.communication.project.dto.ProjectOverviewResponse;
import com.zaps.communication.project.dto.ProjectResponse;
import com.zaps.communication.project.service.ProjectOverviewService;
import com.zaps.communication.project.service.ProjectService;
import com.zaps.communication.user.entity.User;
import com.zaps.communication.user.service.AccessScopeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/projects")
public class ProjectController {
    private final ProjectService service;
    private final ProjectOverviewService projectOverviewService;
    private final AccessScopeService accessScopeService;
    public ProjectController(ProjectService service, ProjectOverviewService projectOverviewService, AccessScopeService accessScopeService) { this.service = service; this.projectOverviewService = projectOverviewService; this.accessScopeService = accessScopeService; }

    @PostMapping public ApiResponse<ProjectResponse> create(@Valid @RequestBody ProjectRequest request, @RequestHeader(value = "Authorization", required = false) String authorizationHeader){
        User actor = accessScopeService.requireUser(authorizationHeader);
        if (!accessScopeService.isSuperAdmin(actor)) {
            throw new org.springframework.web.server.ResponseStatusException(org.springframework.http.HttpStatus.FORBIDDEN, "Only SUPER_ADMIN can create projects");
        }
        return ApiResponse.success("Project created", service.create(request));
    }
    @GetMapping public ApiResponse<List<ProjectResponse>> getAll(@RequestHeader(value = "Authorization", required = false) String authorizationHeader){
        User actor = accessScopeService.requireUser(authorizationHeader);
        Long assignedProjectId = accessScopeService.requiredProjectId(actor);
        if (assignedProjectId == null) return ApiResponse.success("Projects fetched", service.getAll());
        return ApiResponse.success("Projects fetched", service.getAllByIds(List.of(assignedProjectId)));
    }
    @GetMapping("/{id}") public ApiResponse<ProjectResponse> getById(@PathVariable Long id, @RequestHeader(value = "Authorization", required = false) String authorizationHeader){
        User actor = accessScopeService.requireUser(authorizationHeader);
        accessScopeService.assertProjectAccess(actor, id);
        return ApiResponse.success("Project fetched", service.getById(id));
    }
    @GetMapping("/{id}/overview") public ApiResponse<ProjectOverviewResponse> overview(@PathVariable Long id, @RequestHeader(value = "Authorization", required = false) String authorizationHeader){
        User actor = accessScopeService.requireUser(authorizationHeader);
        accessScopeService.assertProjectAccess(actor, id);
        return ApiResponse.success("Project overview fetched", projectOverviewService.getOverview(id));
    }
    @PutMapping("/{id}") public ApiResponse<ProjectResponse> update(@PathVariable Long id, @Valid @RequestBody ProjectRequest request, @RequestHeader(value = "Authorization", required = false) String authorizationHeader){
        User actor = accessScopeService.requireUser(authorizationHeader);
        if (!accessScopeService.isSuperAdmin(actor)) {
            throw new org.springframework.web.server.ResponseStatusException(org.springframework.http.HttpStatus.FORBIDDEN, "Only SUPER_ADMIN can update projects");
        }
        return ApiResponse.success("Project updated", service.update(id, request));
    }
    @GetMapping("/{id}/api-key") public ApiResponse<ProjectApiKeyResponse> getApiKey(@PathVariable Long id, @RequestHeader(value = "Authorization", required = false) String authorizationHeader){
        User actor = accessScopeService.requireUser(authorizationHeader);
        accessScopeService.assertProjectAccess(actor, id);
        return ApiResponse.success("API key fetched", service.getApiKey(id));
    }
    @PostMapping("/{id}/api-key/regenerate") public ApiResponse<ProjectApiKeyResponse> regenerateApiKey(@PathVariable Long id, @RequestHeader(value = "Authorization", required = false) String authorizationHeader){
        User actor = accessScopeService.requireUser(authorizationHeader);
        accessScopeService.assertProjectAccess(actor, id);
        return ApiResponse.success("API key regenerated", service.regenerateApiKey(id));
    }
    @DeleteMapping("/{id}") public ApiResponse<Void> delete(@PathVariable Long id, @RequestHeader(value = "Authorization", required = false) String authorizationHeader){
        User actor = accessScopeService.requireUser(authorizationHeader);
        if (!accessScopeService.isSuperAdmin(actor)) {
            throw new org.springframework.web.server.ResponseStatusException(org.springframework.http.HttpStatus.FORBIDDEN, "Only SUPER_ADMIN can delete projects");
        }
        service.delete(id); return ApiResponse.success("Project deleted", null);
    }
}
