package com.zaps.communication.notification.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zaps.communication.common.ApiResponse;
import com.zaps.communication.common.exception.ResourceNotFoundException;
import com.zaps.communication.notification.dto.NotificationTimelineResponse;
import com.zaps.communication.notification.repository.NotificationRequestRepository;
import com.zaps.communication.notification.service.NotificationAuditService;
import com.zaps.communication.user.entity.User;
import com.zaps.communication.user.service.AccessScopeService;

@RestController
@RequestMapping("/api/notifications")
public class NotificationAuditController {
    private final NotificationAuditService notificationAuditService;
    private final NotificationRequestRepository notificationRequestRepository;
    private final AccessScopeService accessScopeService;

    public NotificationAuditController(
            NotificationAuditService notificationAuditService,
            NotificationRequestRepository notificationRequestRepository,
            AccessScopeService accessScopeService) {
        this.notificationAuditService = notificationAuditService;
        this.notificationRequestRepository = notificationRequestRepository;
        this.accessScopeService = accessScopeService;
    }

    @GetMapping("/timeline/{requestId}")
    public ApiResponse<NotificationTimelineResponse> timeline(
            @PathVariable String requestId,
            @RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        User actor = accessScopeService.requireUser(authorizationHeader);
        Long projectId = notificationRequestRepository.findByRequestId(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("Notification request not found"))
                .getProject().getId();
        accessScopeService.assertProjectAccess(actor, projectId);
        return ApiResponse.success("Notification timeline fetched", notificationAuditService.getTimeline(requestId));
    }
}

