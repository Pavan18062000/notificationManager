package com.zaps.communication.notification.service;

import com.zaps.communication.common.enums.NotificationStatus;
import com.zaps.communication.notification.entity.NotificationLog;
import com.zaps.communication.notification.entity.NotificationRequest;
import com.zaps.communication.notification.repository.NotificationLogRepository;
import com.zaps.communication.notification.repository.NotificationRequestRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class NotificationQueueReconciliationService {
    private static final Logger log = LoggerFactory.getLogger(NotificationQueueReconciliationService.class);

    private final NotificationRequestRepository requestRepository;
    private final NotificationLogRepository logRepository;

    @Value("${app.notification.queue-timeout-minutes:10}")
    private int queueTimeoutMinutes;

    public NotificationQueueReconciliationService(
            NotificationRequestRepository requestRepository,
            NotificationLogRepository logRepository) {
        this.requestRepository = requestRepository;
        this.logRepository = logRepository;
    }

    @Scheduled(fixedDelayString = "${app.notification.reconcile-interval-ms:60000}")
    @Transactional
    public void reconcileStaleQueuedRequests() {
        LocalDateTime threshold = LocalDateTime.now().minusMinutes(Math.max(queueTimeoutMinutes, 1));
        List<NotificationRequest> staleRequests = requestRepository.findByStatusAndCreatedAtBefore(NotificationStatus.QUEUED, threshold);
        if (staleRequests.isEmpty()) return;

        for (NotificationRequest request : staleRequests) {
            List<NotificationLog> queuedLogs = logRepository.findByRequest_IdAndStatus(request.getId(), NotificationStatus.QUEUED);
            if (queuedLogs.isEmpty()) {
                request.setStatus(NotificationStatus.FAILED);
                requestRepository.save(request);
                continue;
            }
            for (NotificationLog nl : queuedLogs) {
                if (nl.getStatus() != NotificationStatus.SENT) {
                    nl.setStatus(NotificationStatus.FAILED);
                    nl.setFailedAt(LocalDateTime.now());
                    nl.setErrorMessage("Auto-reconciled: stuck in QUEUED beyond timeout");
                    logRepository.save(nl);
                }
            }
            request.setStatus(NotificationStatus.FAILED);
            requestRepository.save(request);
            log.warn("Auto-reconciled stale queued requestId={} to FAILED", request.getRequestId());
        }
    }
}

