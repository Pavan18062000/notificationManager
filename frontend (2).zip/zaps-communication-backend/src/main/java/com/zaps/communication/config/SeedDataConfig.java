package com.zaps.communication.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.zaps.communication.channel.entity.Channel;
import com.zaps.communication.channel.repository.ChannelRepository;
import com.zaps.communication.common.enums.ChannelCode;
import com.zaps.communication.country.entity.Country;
import com.zaps.communication.country.repository.CountryRepository;
import com.zaps.communication.event.entity.EventType;
import com.zaps.communication.event.repository.EventTypeRepository;
import com.zaps.communication.user.entity.User;
import com.zaps.communication.user.entity.UserRole;
import com.zaps.communication.user.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class SeedDataConfig {

    @Bean
    CommandLineRunner seedData(ChannelRepository channelRepository,
                               CountryRepository countryRepository,
                               EventTypeRepository eventTypeRepository,
                               UserRepository userRepository,
                               PasswordEncoder passwordEncoder) {
        return args -> {
            try {
                for (ChannelCode code : ChannelCode.values()) {
                    if (channelRepository.findByCode(code).isEmpty()) {
                        Channel channel = new Channel();
                        channel.setCode(code);
                        channel.setActive(true);
                        channelRepository.save(channel);
                    }
                }
            } catch (Exception ignored) {
            }

            try {
                if (countryRepository.findByCountryCode("IN").isEmpty()) {
                    Country in = new Country();
                    in.setCountryCode("IN");
                    in.setCountryName("India");
                    in.setActive(true);
                    countryRepository.save(in);
                }
            } catch (Exception ignored) {
            }
            try {
                if (eventTypeRepository.findByEventCode("OTP_LOGIN").isEmpty()) {
                    EventType e = new EventType();
                    e.setEventCode("OTP_LOGIN");
                    e.setEventName("OTP Login");
                    eventTypeRepository.save(e);
                }
            } catch (Exception ignored) {
            }
            try {
                if (userRepository.findByEmailIgnoreCase("admin@zaps.com").isEmpty()) {
                    User admin = new User();
                    admin.setEmail("admin@zaps.com");
                    admin.setRole(UserRole.SUPER_ADMIN);
                    admin.setActive(true);
                    admin.setPasswordHash(passwordEncoder.encode("Admin@123"));
                    userRepository.save(admin);
                }
            } catch (Exception ignored) {
            }
        };
    }
}
