package com.zaps.communication.provider.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.zaps.communication.common.ApiResponse;
import com.zaps.communication.provider.dto.ProviderRequest;
import com.zaps.communication.provider.dto.ProviderResponse;
import com.zaps.communication.provider.service.ProviderService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/providers")
public class ProviderController {
    private final ProviderService service;
    public ProviderController(ProviderService service) { this.service = service; }

    @PostMapping public ApiResponse<ProviderResponse> create(@Valid @RequestBody ProviderRequest request){ return ApiResponse.success("Provider created", service.create(request)); }
    @GetMapping public ApiResponse<List<ProviderResponse>> getAll(){ return ApiResponse.success("Providers fetched", service.getAll()); }
    @PutMapping("/{id}") public ApiResponse<ProviderResponse> update(@PathVariable Long id, @Valid @RequestBody ProviderRequest request){ return ApiResponse.success("Provider updated", service.update(id, request)); }
}
