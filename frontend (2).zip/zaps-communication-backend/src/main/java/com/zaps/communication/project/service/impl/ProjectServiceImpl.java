package com.zaps.communication.project.service.impl;

import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.zaps.communication.common.exception.DuplicateResourceException;
import com.zaps.communication.common.exception.ResourceNotFoundException;
import com.zaps.communication.openapi.OpenApiAuthService;
import com.zaps.communication.project.dto.ProjectApiKeyResponse;
import com.zaps.communication.project.dto.ProjectRequest;
import com.zaps.communication.project.dto.ProjectResponse;
import com.zaps.communication.project.entity.Project;
import com.zaps.communication.project.repository.ProjectRepository;
import com.zaps.communication.project.service.ProjectService;

@Service
public class ProjectServiceImpl implements ProjectService {
    private final ProjectRepository repository;
    private final OpenApiAuthService openApiAuthService;
    public ProjectServiceImpl(ProjectRepository repository, OpenApiAuthService openApiAuthService) {
        this.repository = repository;
        this.openApiAuthService = openApiAuthService;
    }

    public ProjectResponse create(ProjectRequest request) {
        if (repository.existsByProjectCode(request.getProjectCode())) throw new DuplicateResourceException("Project code already exists");
        Project p = new Project();
        p.setProjectCode(request.getProjectCode().trim().toUpperCase());
        p.setProjectName(request.getProjectName().trim());
        String rawApiKey = generateApiKey();
        p.setApiKeyHash(openApiAuthService.sha256(rawApiKey));
        p.setApiKeyValue(rawApiKey);
        p.setActive(Boolean.TRUE.equals(request.getActive()));
        return toResponse(repository.save(p));
    }

    public List<ProjectResponse> getAll(){ return repository.findAll().stream().map(this::toResponse).toList(); }
    public List<ProjectResponse> getAllByIds(List<Long> ids){ return repository.findByIdIn(ids).stream().map(this::toResponse).toList(); }
    public ProjectResponse getById(Long id){ return toResponse(find(id)); }
    public ProjectResponse update(Long id, ProjectRequest request){
        Project p = find(id);
        p.setProjectCode(request.getProjectCode().trim().toUpperCase());
        p.setProjectName(request.getProjectName().trim());
        p.setActive(Boolean.TRUE.equals(request.getActive()));
        return toResponse(repository.save(p));
    }
    public ProjectApiKeyResponse getApiKey(Long id) {
        Project p = find(id);
        return ProjectApiKeyResponse.builder()
                .projectId(p.getId())
                .projectCode(p.getProjectCode())
                .apiKey(p.getApiKeyValue())
                .message("API key fetched from project configuration.")
                .build();
    }
    public ProjectApiKeyResponse regenerateApiKey(Long id) {
        Project p = find(id);
        String rawApiKey = generateApiKey();
        p.setApiKeyHash(openApiAuthService.sha256(rawApiKey));
        p.setApiKeyValue(rawApiKey);
        repository.save(p);
        return ProjectApiKeyResponse.builder()
                .projectId(p.getId())
                .projectCode(p.getProjectCode())
                .apiKey(rawApiKey)
                .message("API key is shown only once. Store it securely.")
                .build();
    }
    public void delete(Long id){ repository.delete(find(id)); }

    private Project find(Long id){ return repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Project not found")); }
    private ProjectResponse toResponse(Project p){ return ProjectResponse.builder().id(p.getId()).projectCode(p.getProjectCode()).projectName(p.getProjectName()).active(p.isActive()).build(); }
    private String generateApiKey() { return "pk_" + UUID.randomUUID().toString().replace("-", "") + UUID.randomUUID().toString().substring(0, 8); }
}
