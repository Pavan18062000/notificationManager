package com.zaps.communication.project.service;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaps.communication.project.dto.ProjectOverviewResponse;

@Service
public class RabbitMqQueueMetricsService {
    private final HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2)).build();
    private final ObjectMapper objectMapper;

    @Value("${app.rabbitmq.management.host:${RABBITMQ_HOST:localhost}}")
    private String host;

    @Value("${app.rabbitmq.management.port:${RABBITMQ_MANAGEMENT_PORT:15672}}")
    private int port;

    @Value("${app.rabbitmq.management.username:${RABBITMQ_USERNAME:guest}}")
    private String username;

    @Value("${app.rabbitmq.management.password:${RABBITMQ_PASSWORD:guest}}")
    private String password;

    @Value("${app.rabbitmq.management.vhost:/}")
    private String vhost;

    public RabbitMqQueueMetricsService(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public Map<String, ProjectOverviewResponse.QueueStatus> loadQueueStatus() {
        return Map.of(
                "SMS", fetchQueue("notification.sms.queue"),
                "EMAIL", fetchQueue("notification.email.queue"),
                "WHATSAPP", fetchQueue("notification.whatsapp.queue"),
                "PUSH", fetchQueue("notification.push.queue")
        );
    }

    private ProjectOverviewResponse.QueueStatus fetchQueue(String queueName) {
        try {
            String encodedVhost = URLEncoder.encode(vhost, StandardCharsets.UTF_8);
            String encodedQueue = URLEncoder.encode(queueName, StandardCharsets.UTF_8);
            String url = "http://" + host + ":" + port + "/api/queues/" + encodedVhost + "/" + encodedQueue;
            String basic = java.util.Base64.getEncoder()
                    .encodeToString((username + ":" + password).getBytes(StandardCharsets.UTF_8));

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .timeout(Duration.ofSeconds(3))
                    .header("Authorization", "Basic " + basic)
                    .header("Accept", "application/json")
                    .GET()
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                return ProjectOverviewResponse.QueueStatus.builder().ready(0).unacked(0).consumers(0).build();
            }

            JsonNode node = objectMapper.readTree(response.body());
            int ready = node.path("messages_ready").asInt(0);
            int unacked = node.path("messages_unacknowledged").asInt(0);
            int consumers = node.path("consumers").asInt(0);
            return ProjectOverviewResponse.QueueStatus.builder().ready(ready).unacked(unacked).consumers(consumers).build();
        } catch (Exception ex) {
            return ProjectOverviewResponse.QueueStatus.builder().ready(0).unacked(0).consumers(0).build();
        }
    }
}

