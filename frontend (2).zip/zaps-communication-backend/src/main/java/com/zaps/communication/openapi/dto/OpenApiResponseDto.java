package com.zaps.communication.openapi.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OpenApiResponseDto {
    private boolean success;
    private String requestId;
    private String status;
    private String message;
    private String errorCode;
}

