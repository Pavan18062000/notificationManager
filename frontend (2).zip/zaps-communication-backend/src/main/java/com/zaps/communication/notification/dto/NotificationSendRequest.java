package com.zaps.communication.notification.dto;

import java.util.List;
import java.util.Map;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class NotificationSendRequest {
    @NotBlank private String projectCode;
    @NotBlank private String countryCode;
    @NotBlank private String eventCode;
    @NotEmpty private List<String> channels;
    @NotNull private Recipient recipient;
    @NotNull private Map<String, Object> payload;

    @Data
    public static class Recipient {
        private String phone;
        private String email;
        private String whatsapp;
        private String deviceToken;
    }
}
