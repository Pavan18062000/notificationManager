package com.zaps.communication.channel.dto;

import com.zaps.communication.common.enums.ChannelCode;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ChannelResponse {
    private Long id;
    private ChannelCode code;
    private boolean active;
}
