package com.zaps.communication.reports.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class NotificationTrendResponse {
    private String date;
    private long total;
    private long sent;
    private long failed;
}

