package com.zaps.communication.reports.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.zaps.communication.reports.dto.NotificationDetailResponse;
import com.zaps.communication.reports.dto.ReportFilterRequest;
import com.zaps.communication.reports.repository.ReportRepository;
import com.zaps.communication.user.entity.User;
import com.zaps.communication.user.service.AccessScopeService;

@Service
public class ReportServiceImpl implements ReportService {
    private final ReportRepository reportRepository;
    private final AccessScopeService accessScopeService;

    public ReportServiceImpl(ReportRepository reportRepository, AccessScopeService accessScopeService) {
        this.reportRepository = reportRepository;
        this.accessScopeService = accessScopeService;
    }

    @Override
    public Object getSummary(ReportFilterRequest filter, String authorizationHeader) {
        Long scopedProjectId = resolveScopedProjectId(authorizationHeader, filter);
        return reportRepository.fetchSummary(withDefaults(filter), scopedProjectId);
    }

    @Override
    public Object getTrend(ReportFilterRequest filter, String authorizationHeader) {
        Long scopedProjectId = resolveScopedProjectId(authorizationHeader, filter);
        return reportRepository.fetchTrend(withDefaults(filter), scopedProjectId);
    }

    @Override
    public Object getStatusDistribution(ReportFilterRequest filter, String authorizationHeader) {
        Long scopedProjectId = resolveScopedProjectId(authorizationHeader, filter);
        return reportRepository.fetchStatusDistribution(withDefaults(filter), scopedProjectId);
    }

    @Override
    public Object getChannelSummary(ReportFilterRequest filter, String authorizationHeader) {
        Long scopedProjectId = resolveScopedProjectId(authorizationHeader, filter);
        return reportRepository.fetchChannelSummary(withDefaults(filter), scopedProjectId);
    }

    @Override
    public Object getProviderSummary(ReportFilterRequest filter, String authorizationHeader) {
        Long scopedProjectId = resolveScopedProjectId(authorizationHeader, filter);
        return reportRepository.fetchProviderSummary(withDefaults(filter), scopedProjectId);
    }

    @Override
    public Object getProjectSummary(ReportFilterRequest filter, String authorizationHeader) {
        Long scopedProjectId = resolveScopedProjectId(authorizationHeader, filter);
        return reportRepository.fetchProjectSummary(withDefaults(filter), scopedProjectId);
    }

    @Override
    public Object getEventSummary(ReportFilterRequest filter, String authorizationHeader) {
        Long scopedProjectId = resolveScopedProjectId(authorizationHeader, filter);
        return reportRepository.fetchEventSummary(withDefaults(filter), scopedProjectId);
    }

    @Override
    public Map<String, Object> getNotificationDetails(ReportFilterRequest filter, String authorizationHeader) {
        Long scopedProjectId = resolveScopedProjectId(authorizationHeader, filter);
        ReportFilterRequest effectiveFilter = withDefaults(filter);
        List<NotificationDetailResponse> items = reportRepository.fetchNotificationDetails(effectiveFilter, scopedProjectId);
        long total = reportRepository.countNotificationDetails(effectiveFilter, scopedProjectId);

        Map<String, Object> page = new HashMap<>();
        int pageNo = effectiveFilter.getPage() == null ? 0 : effectiveFilter.getPage();
        int size = effectiveFilter.getSize() == null ? 20 : effectiveFilter.getSize();

        page.put("items", items);
        page.put("page", pageNo);
        page.put("size", size);
        page.put("totalElements", total);
        page.put("totalPages", size <= 0 ? 0 : (int) Math.ceil((double) total / (double) size));
        return page;
    }

    @Override
    public Object getNotificationDetailsByRequestId(String requestId, String authorizationHeader) {
        Long scopedProjectId = resolveScopedProjectId(authorizationHeader, null);
        return reportRepository.fetchNotificationDetailsByRequestId(requestId, scopedProjectId);
    }

    @Override
    public Map<String, Object> getFilterLookups(String authorizationHeader, Long projectId) {
        Long scopedProjectId = resolveScopedProjectId(authorizationHeader, null);
        Map<String, Object> data = new HashMap<>();
        data.put("projects", reportRepository.fetchProjectsForFilter(scopedProjectId));
        data.put("countries", reportRepository.fetchCountriesForFilter(scopedProjectId, projectId));
        data.put("eventTypes", reportRepository.fetchEventTypesForFilter());
        data.put("channels", reportRepository.fetchChannelsForFilter());
        data.put("providers", reportRepository.fetchProvidersForFilter());
        return data;
    }

    private ReportFilterRequest withDefaults(ReportFilterRequest filter) {
        ReportFilterRequest f = filter == null ? new ReportFilterRequest() : filter;
        if (f.getPage() == null) f.setPage(0);
        if (f.getSize() == null || f.getSize() <= 0) f.setSize(20);
        if (f.getSortBy() == null || f.getSortBy().isBlank()) f.setSortBy("createdAt");
        if (f.getSortDirection() == null || f.getSortDirection().isBlank()) f.setSortDirection("DESC");
        return f;
    }

    private Long resolveScopedProjectId(String authorizationHeader, ReportFilterRequest filter) {
        User user = accessScopeService.requireUser(authorizationHeader);
        Long scopedProjectId = accessScopeService.requiredProjectId(user);
        if (scopedProjectId == null) {
            if (filter != null && filter.getProjectId() != null) {
                accessScopeService.assertProjectAccess(user, filter.getProjectId());
            }
            return null;
        }
        return scopedProjectId;
    }
}
