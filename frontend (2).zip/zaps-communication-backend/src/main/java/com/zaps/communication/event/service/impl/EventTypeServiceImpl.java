package com.zaps.communication.event.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.zaps.communication.event.dto.EventTypeRequest;
import com.zaps.communication.event.dto.EventTypeResponse;
import com.zaps.communication.event.entity.EventType;
import com.zaps.communication.event.repository.EventTypeRepository;
import com.zaps.communication.event.service.EventTypeService;

@Service
public class EventTypeServiceImpl implements EventTypeService {
    private final EventTypeRepository repository;
    public EventTypeServiceImpl(EventTypeRepository repository) { this.repository = repository; }
    public EventTypeResponse create(EventTypeRequest request){
        EventType e = new EventType();
        e.setEventCode(request.getEventCode().trim().toUpperCase());
        e.setEventName(request.getEventName().trim());
        e = repository.save(e);
        return EventTypeResponse.builder().id(e.getId()).eventCode(e.getEventCode()).eventName(e.getEventName()).build();
    }
    public List<EventTypeResponse> getAll(){ return repository.findAll().stream().map(e -> EventTypeResponse.builder().id(e.getId()).eventCode(e.getEventCode()).eventName(e.getEventName()).build()).toList(); }
}
