package com.zaps.communication.channel.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.zaps.communication.channel.dto.ChannelRequest;
import com.zaps.communication.channel.dto.ChannelResponse;
import com.zaps.communication.channel.service.ChannelService;
import com.zaps.communication.common.ApiResponse;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/channels")
public class ChannelController {
    private final ChannelService service;
    public ChannelController(ChannelService service) { this.service = service; }

    @PostMapping public ApiResponse<ChannelResponse> create(@Valid @RequestBody ChannelRequest request){ return ApiResponse.success("Channel created", service.create(request)); }
    @GetMapping public ApiResponse<List<ChannelResponse>> getAll(){ return ApiResponse.success("Channels fetched", service.getAll()); }
    @PutMapping("/{id}") public ApiResponse<ChannelResponse> update(@PathVariable Long id, @Valid @RequestBody ChannelRequest request){ return ApiResponse.success("Channel updated", service.update(id, request)); }
}
