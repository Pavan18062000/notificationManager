package com.zaps.communication.notification.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.zaps.communication.common.enums.NotificationStatus;
import java.util.List;
import java.time.LocalDateTime;
import java.util.Optional;

import com.zaps.communication.notification.entity.NotificationRequest;

public interface NotificationRequestRepository extends JpaRepository<NotificationRequest, Long> {
    long countByProjectId(Long projectId);
    long countByProjectIdAndStatus(Long projectId, NotificationStatus status);
    List<NotificationRequest> findByProjectId(Long projectId);
    Optional<NotificationRequest> findByRequestId(String requestId);
    List<NotificationRequest> findByStatusAndCreatedAtBefore(NotificationStatus status, LocalDateTime before);
}
