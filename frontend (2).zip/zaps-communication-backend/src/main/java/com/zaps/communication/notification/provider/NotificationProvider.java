package com.zaps.communication.notification.provider;

import com.zaps.communication.common.enums.ChannelCode;
import com.zaps.communication.notification.provider.dto.NotificationProviderRequest;
import com.zaps.communication.notification.provider.dto.ProviderDeliveryResponse;

public interface NotificationProvider {
    ChannelCode channel();
    String providerCode();
    ProviderDeliveryResponse send(NotificationProviderRequest request);
}

