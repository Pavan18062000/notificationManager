package com.zaps.communication.reports.dto;

import java.time.LocalDate;

import lombok.Data;

@Data
public class ReportFilterRequest {
    private LocalDate fromDate;
    private LocalDate toDate;
    private Long projectId;
    private Long countryId;
    private Long channelId;
    private Long eventTypeId;
    private Long providerId;
    private String status;
    private String recipient;
    private String requestId;
    private Integer page = 0;
    private Integer size = 20;
    private String sortBy = "createdAt";
    private String sortDirection = "DESC";
}

