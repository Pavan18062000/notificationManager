package com.zaps.communication.notification.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.zaps.communication.common.exception.ResourceNotFoundException;
import com.zaps.communication.notification.dto.NotificationTimelineResponse;
import com.zaps.communication.notification.entity.NotificationLog;
import com.zaps.communication.notification.entity.NotificationRequest;
import com.zaps.communication.notification.repository.NotificationLogRepository;
import com.zaps.communication.notification.repository.NotificationRequestRepository;

@Service
public class NotificationAuditService {
    private final NotificationRequestRepository requestRepository;
    private final NotificationLogRepository logRepository;

    public NotificationAuditService(NotificationRequestRepository requestRepository, NotificationLogRepository logRepository) {
        this.requestRepository = requestRepository;
        this.logRepository = logRepository;
    }

    public NotificationTimelineResponse getTimeline(String requestId) {
        NotificationRequest request = requestRepository.findByRequestId(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("Notification request not found"));
        List<NotificationLog> logs = logRepository.findByRequest_RequestIdOrderByAttemptNoAscCreatedAtAsc(requestId);

        return NotificationTimelineResponse.builder()
                .requestId(request.getRequestId())
                .requestUuid(request.getRequestUuid())
                .projectCode(request.getProject().getProjectCode())
                .countryCode(request.getCountry().getCountryCode())
                .eventCode(request.getEventType().getEventCode())
                .status(request.getStatus().name())
                .createdAt(request.getCreatedAt())
                .updatedAt(request.getUpdatedAt())
                .attempts(logs.stream().map(l -> NotificationTimelineResponse.AttemptItem.builder()
                        .deliveryId(l.getId())
                        .attemptNo(l.getAttemptNo())
                        .retryCount(l.getRetryCount())
                        .channel(l.getChannel().getCode().name())
                        .providerCode(l.getProviderCode())
                        .recipient(l.getRecipient())
                        .status(l.getStatus().name())
                        .httpStatus(l.getHttpStatus())
                        .providerMessageId(l.getProviderMessageId())
                        .errorMessage(l.getErrorMessage())
                        .latencyMs(l.getLatencyMs())
                        .sentAt(l.getSentAt())
                        .failedAt(l.getFailedAt())
                        .createdAt(l.getCreatedAt())
                        .updatedAt(l.getUpdatedAt())
                        .build()).toList())
                .build();
    }
}

