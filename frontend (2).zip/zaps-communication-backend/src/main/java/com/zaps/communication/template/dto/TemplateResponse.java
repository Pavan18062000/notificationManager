package com.zaps.communication.template.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TemplateResponse {
    private Long id;
    private Long projectId;
    private Long countryId;
    private Long channelId;
    private Long eventTypeId;
    private String templateName;
    private String language;
    private String subject;
    private String body;
    private boolean active;
}
