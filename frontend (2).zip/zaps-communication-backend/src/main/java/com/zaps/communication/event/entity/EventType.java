package com.zaps.communication.event.entity;

import com.zaps.communication.common.AuditableEntity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "event_types", uniqueConstraints = @UniqueConstraint(name = "uk_event_code", columnNames = "eventCode"))
@Getter
@Setter
public class EventType extends AuditableEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 80)
    private String eventCode;
    @Column(nullable = false, length = 120)
    private String eventName;
}
