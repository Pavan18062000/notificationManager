package com.zaps.communication.project.service;

import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;

import org.springframework.stereotype.Service;

import com.zaps.communication.channel.entity.Channel;
import com.zaps.communication.common.enums.ChannelCode;
import com.zaps.communication.common.enums.NotificationStatus;
import com.zaps.communication.common.exception.ResourceNotFoundException;
import com.zaps.communication.notification.entity.NotificationLog;
import com.zaps.communication.notification.repository.NotificationLogRepository;
import com.zaps.communication.notification.repository.NotificationRequestRepository;
import com.zaps.communication.project.dto.ProjectOverviewResponse;
import com.zaps.communication.project.entity.Project;
import com.zaps.communication.project.repository.ProjectRepository;
import com.zaps.communication.routing.entity.NotificationRoute;
import com.zaps.communication.routing.repository.NotificationRouteRepository;
import com.zaps.communication.template.entity.Template;
import com.zaps.communication.template.repository.TemplateRepository;

@Service
public class ProjectOverviewService {
    private final ProjectRepository projectRepository;
    private final NotificationRouteRepository notificationRouteRepository;
    private final TemplateRepository templateRepository;
    private final NotificationRequestRepository notificationRequestRepository;
    private final NotificationLogRepository notificationLogRepository;
    private final RabbitMqQueueMetricsService rabbitMqQueueMetricsService;

    public ProjectOverviewService(
            ProjectRepository projectRepository,
            NotificationRouteRepository notificationRouteRepository,
            TemplateRepository templateRepository,
            NotificationRequestRepository notificationRequestRepository,
            NotificationLogRepository notificationLogRepository,
            RabbitMqQueueMetricsService rabbitMqQueueMetricsService
    ) {
        this.projectRepository = projectRepository;
        this.notificationRouteRepository = notificationRouteRepository;
        this.templateRepository = templateRepository;
        this.notificationRequestRepository = notificationRequestRepository;
        this.notificationLogRepository = notificationLogRepository;
        this.rabbitMqQueueMetricsService = rabbitMqQueueMetricsService;
    }

    public ProjectOverviewResponse getOverview(Long projectId) {
        Project project = projectRepository.findById(projectId).orElseThrow(() -> new ResourceNotFoundException("Project not found"));

        List<NotificationRoute> routes = notificationRouteRepository.findAll().stream()
                .filter(r -> r.getProject() != null && projectId.equals(r.getProject().getId()))
                .toList();
        List<Template> templates = templateRepository.findByProjectId(projectId);
        List<NotificationLog> failedLogs = notificationLogRepository.findByProjectIdAndStatus(projectId, NotificationStatus.FAILED);

        long totalRequests = notificationRequestRepository.countByProjectId(projectId);
        long sent = notificationRequestRepository.countByProjectIdAndStatus(projectId, NotificationStatus.SENT);
        long failed = notificationRequestRepository.countByProjectIdAndStatus(projectId, NotificationStatus.FAILED);
        long processing = notificationRequestRepository.countByProjectIdAndStatus(projectId, NotificationStatus.PROCESSING);
        long accepted = notificationRequestRepository.countByProjectIdAndStatus(projectId, NotificationStatus.ACCEPTED);
        long queued = notificationRequestRepository.countByProjectIdAndStatus(projectId, NotificationStatus.QUEUED);

        Map<String, ProjectOverviewResponse.QueueStatus> queueStatus = new LinkedHashMap<>();
        queueStatus.putAll(rabbitMqQueueMetricsService.loadQueueStatus());
        for (ChannelCode channelCode : ChannelCode.values()) {
            queueStatus.putIfAbsent(channelCode.name(), ProjectOverviewResponse.QueueStatus.builder().ready(0).unacked(0).consumers(0).build());
        }

        List<ProjectOverviewResponse.ChannelStat> channelStats = routes.stream()
                .map(NotificationRoute::getChannel)
                .distinct()
                .map(Channel::getCode)
                .map(code -> ProjectOverviewResponse.ChannelStat.builder()
                        .channelCode(code.name())
                        .sent(notificationLogRepository.countByProjectIdAndChannelCodeAndStatus(projectId, code, NotificationStatus.SENT))
                        .failed(notificationLogRepository.countByProjectIdAndChannelCodeAndStatus(projectId, code, NotificationStatus.FAILED))
                        .build())
                .toList();

        return ProjectOverviewResponse.builder()
                .project(ProjectOverviewResponse.ProjectDetails.builder()
                        .id(project.getId())
                        .projectCode(project.getProjectCode())
                        .projectName(project.getProjectName())
                        .description(project.getDescription())
                        .active(project.isActive())
                        .createdAt(project.getCreatedAt())
                        .apiKeyConfigured(project.getApiKeyValue() != null && !project.getApiKeyValue().isBlank())
                        .apiKeyMasked(mask(project.getApiKeyValue()))
                        .apiKeyUpdatedAt(project.getUpdatedAt())
                        .build())
                .countries(routes.stream()
                        .filter(r -> r.getCountry() != null)
                        .map(r -> r.getCountry())
                        .distinct()
                        .map(c -> ProjectOverviewResponse.CountryItem.builder()
                        .id(c.getId())
                        .countryCode(c.getCountryCode())
                        .countryName(c.getCountryName())
                        .enabled(true)
                        .defaultCountry(false)
                        .active(c.isActive())
                        .build()).toList())
                .channels(routes.stream()
                        .map(NotificationRoute::getChannel)
                        .filter(c -> c != null)
                        .distinct()
                        .map(c -> ProjectOverviewResponse.ChannelItem.builder()
                        .id(c.getId())
                        .channelCode(c.getCode().name())
                        .rateLimit(null)
                        .retryCount(null)
                        .enabled(true)
                        .build()).toList())
                .providerConfigs(routes.stream().map(c -> ProjectOverviewResponse.ProviderConfigItem.builder()
                        .id(c.getId())
                        .countryName(c.getCountry() == null ? "GLOBAL" : c.getCountry().getCountryName())
                        .channelCode(c.getChannel().getCode().name())
                        .providerName(c.getProvider().getProviderName())
                        .providerType(c.getProvider().getProviderCode())
                        .priority(c.getPriority())
                        .senderId(c.getSenderId())
                        .fromEmail(c.getFromEmail())
                        .active(c.isEnabled())
                        .build()).toList())
                .templates(templates.stream().map(t -> ProjectOverviewResponse.TemplateItem.builder()
                        .id(t.getId())
                        .templateName(t.getTemplateName())
                        .channelCode(t.getChannel().getCode().name())
                        .eventType(t.getEventType().getEventCode())
                        .countryName(t.getCountry().getCountryName())
                        .subject(t.getSubject())
                        .active(t.isActive())
                        .build()).toList())
                .summary(ProjectOverviewResponse.Summary.builder()
                        .totalRequests(totalRequests)
                        .sent(sent)
                        .failed(failed)
                        .pending(accepted + queued)
                        .processing(processing)
                        .retryableFailed(0)
                        .build())
                .channelStats(channelStats)
                .failedLogs(failedLogs.stream().map(l -> ProjectOverviewResponse.FailedLogItem.builder()
                        .id(l.getId())
                        .requestId(l.getRequest().getRequestId())
                        .channel(l.getChannel().getCode().name())
                        .recipient(l.getRecipient())
                        .provider(l.getProvider() != null ? l.getProvider().getProviderName() : null)
                        .errorMessage(null)
                        .createdAt(l.getCreatedAt())
                        .retryCount(l.getRetryCount())
                        .status(l.getStatus().name())
                        .build()).toList())
                .queueStatus(queueStatus)
                .build();
    }

    private String mask(String key) {
        if (key == null || key.isBlank()) return "-";
        if (key.length() < 8) return "****";
        return key.substring(0, 6) + "..." + key.substring(key.length() - 4);
    }
}
