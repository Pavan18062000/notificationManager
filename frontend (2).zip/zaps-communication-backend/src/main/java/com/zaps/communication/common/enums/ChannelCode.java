package com.zaps.communication.common.enums;

public enum ChannelCode {
    SMS, EMAIL, PUSH, WHATSAPP
}
