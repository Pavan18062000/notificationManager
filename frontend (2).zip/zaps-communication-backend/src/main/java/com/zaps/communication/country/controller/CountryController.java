package com.zaps.communication.country.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.zaps.communication.common.ApiResponse;
import com.zaps.communication.country.dto.CountryRequest;
import com.zaps.communication.country.dto.CountryResponse;
import com.zaps.communication.country.service.CountryService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/countries")
public class CountryController {
    private final CountryService service;
    public CountryController(CountryService service) { this.service = service; }

    @PostMapping public ApiResponse<CountryResponse> create(@Valid @RequestBody CountryRequest request){ return ApiResponse.success("Country created", service.create(request)); }
    @GetMapping public ApiResponse<List<CountryResponse>> getAll(){ return ApiResponse.success("Countries fetched", service.getAll()); }
    @GetMapping("/{id}") public ApiResponse<CountryResponse> getById(@PathVariable Long id){ return ApiResponse.success("Country fetched", service.getById(id)); }
    @PutMapping("/{id}") public ApiResponse<CountryResponse> update(@PathVariable Long id, @Valid @RequestBody CountryRequest request){ return ApiResponse.success("Country updated", service.update(id, request)); }
    @DeleteMapping("/{id}") public ApiResponse<Void> delete(@PathVariable Long id){ service.delete(id); return ApiResponse.success("Country deleted", null); }
}
