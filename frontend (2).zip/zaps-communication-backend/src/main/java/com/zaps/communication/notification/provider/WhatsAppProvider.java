package com.zaps.communication.notification.provider;

public interface WhatsAppProvider extends NotificationProvider {
}

