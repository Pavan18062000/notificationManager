package com.zaps.communication.user.service;

import java.util.List;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.zaps.communication.common.exception.BadRequestException;
import com.zaps.communication.common.exception.DuplicateResourceException;
import com.zaps.communication.common.exception.ResourceNotFoundException;
import com.zaps.communication.project.entity.Project;
import com.zaps.communication.project.repository.ProjectRepository;
import com.zaps.communication.user.dto.UserRequest;
import com.zaps.communication.user.dto.UserResponse;
import com.zaps.communication.user.entity.User;
import com.zaps.communication.user.entity.UserRole;
import com.zaps.communication.user.repository.UserRepository;

@Service
public class UserService {
    private final UserRepository userRepository;
    private final ProjectRepository projectRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthService authService;

    public UserService(UserRepository userRepository, ProjectRepository projectRepository, PasswordEncoder passwordEncoder, AuthService authService) {
        this.userRepository = userRepository;
        this.projectRepository = projectRepository;
        this.passwordEncoder = passwordEncoder;
        this.authService = authService;
    }

    public List<UserResponse> list(User actingUser) {
        if (actingUser.getRole() == UserRole.SUPER_ADMIN) {
            return userRepository.findAll().stream().map(authService::toUserResponse).toList();
        }
        if (actingUser.getProject() == null) return List.of();
        return userRepository.findByProjectId(actingUser.getProject().getId()).stream().map(authService::toUserResponse).toList();
    }

    public UserResponse create(UserRequest request, User actingUser) {
        requireSuperAdmin(actingUser);
        validateRequest(request, true);
        String normalizedEmail = normalizeEmail(request.getEmail());
        if (userRepository.existsByEmailIgnoreCase(normalizedEmail)) {
            throw new DuplicateResourceException("Email already exists");
        }
        User user = new User();
        user.setEmail(normalizedEmail);
        user.setRole(request.getRole());
        user.setActive(Boolean.TRUE.equals(request.getActive()));
        user.setPasswordHash(passwordEncoder.encode(request.getPassword().trim()));
        user.setProject(resolveProject(request));
        return authService.toUserResponse(userRepository.save(user));
    }

    public UserResponse update(Long id, UserRequest request, User actingUser) {
        requireSuperAdmin(actingUser);
        validateRequest(request, false);
        User user = userRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("User not found"));
        String normalizedEmail = normalizeEmail(request.getEmail());
        if (!user.getEmail().equalsIgnoreCase(normalizedEmail) && userRepository.existsByEmailIgnoreCase(normalizedEmail)) {
            throw new DuplicateResourceException("Email already exists");
        }
        user.setEmail(normalizedEmail);
        user.setRole(request.getRole());
        user.setActive(Boolean.TRUE.equals(request.getActive()));
        if (request.getPassword() != null && !request.getPassword().isBlank()) {
            user.setPasswordHash(passwordEncoder.encode(request.getPassword().trim()));
        }
        user.setProject(resolveProject(request));
        return authService.toUserResponse(userRepository.save(user));
    }

    private void requireSuperAdmin(User actingUser) {
        if (actingUser.getRole() != UserRole.SUPER_ADMIN) {
            throw new BadRequestException("Only SUPER_ADMIN can manage users");
        }
    }

    private void validateRequest(UserRequest request, boolean isCreate) {
        if (request.getRole() == UserRole.PROJECT_ADMIN && request.getProjectId() == null) {
            throw new BadRequestException("Project is required for PROJECT_ADMIN");
        }
        if (request.getRole() == UserRole.SUPER_ADMIN) {
            request.setProjectId(null);
        }
        if (isCreate && (request.getPassword() == null || request.getPassword().isBlank())) {
            throw new BadRequestException("Password is required");
        }
    }

    private Project resolveProject(UserRequest request) {
        if (request.getProjectId() == null) return null;
        return projectRepository.findById(request.getProjectId()).orElseThrow(() -> new ResourceNotFoundException("Project not found"));
    }

    private String normalizeEmail(String email) {
        if (email == null) return "";
        return email.trim().toLowerCase();
    }
}
