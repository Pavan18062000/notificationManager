package com.zaps.communication.routing.service;

import java.util.List;

import com.zaps.communication.routing.dto.NotificationRouteRequest;
import com.zaps.communication.routing.dto.NotificationRouteResponse;

public interface NotificationRouteService {
    List<NotificationRouteResponse> getAll(Long scopedProjectId);
    NotificationRouteResponse create(NotificationRouteRequest request);
    NotificationRouteResponse update(Long id, NotificationRouteRequest request);
}
