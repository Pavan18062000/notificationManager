package com.zaps.communication.user.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.zaps.communication.common.ApiResponse;
import com.zaps.communication.user.dto.UserRequest;
import com.zaps.communication.user.dto.UserResponse;
import com.zaps.communication.user.entity.User;
import com.zaps.communication.user.service.AuthService;
import com.zaps.communication.user.service.UserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/users")
public class UserController {
    private final UserService userService;
    private final AuthService authService;

    public UserController(UserService userService, AuthService authService) {
        this.userService = userService;
        this.authService = authService;
    }

    @GetMapping
    public ApiResponse<List<UserResponse>> list(@RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        User actor = authService.requireUser(authorizationHeader);
        return ApiResponse.success("Users fetched", userService.list(actor));
    }

    @PostMapping
    public ApiResponse<UserResponse> create(@Valid @RequestBody UserRequest request,
                                            @RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        User actor = authService.requireUser(authorizationHeader);
        return ApiResponse.success("User created", userService.create(request, actor));
    }

    @PutMapping("/{id}")
    public ApiResponse<UserResponse> update(@PathVariable Long id,
                                            @Valid @RequestBody UserRequest request,
                                            @RequestHeader(value = "Authorization", required = false) String authorizationHeader) {
        User actor = authService.requireUser(authorizationHeader);
        return ApiResponse.success("User updated", userService.update(id, request, actor));
    }
}

