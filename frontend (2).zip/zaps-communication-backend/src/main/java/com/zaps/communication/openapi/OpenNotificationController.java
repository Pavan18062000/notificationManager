package com.zaps.communication.openapi;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.zaps.communication.openapi.dto.OpenApiRequestDto;
import com.zaps.communication.openapi.dto.OpenApiResponseDto;
import com.zaps.communication.project.entity.Project;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/open-api/v1/notifications")
public class OpenNotificationController {
    private static final Logger log = LoggerFactory.getLogger(OpenNotificationController.class);
    private final OpenApiAuthService openApiAuthService;
    private final OpenNotificationService openNotificationService;

    public OpenNotificationController(OpenApiAuthService openApiAuthService, OpenNotificationService openNotificationService) {
        this.openApiAuthService = openApiAuthService;
        this.openNotificationService = openNotificationService;
    }

    @PostMapping("/send")
    public ResponseEntity<OpenApiResponseDto> send(
            @RequestHeader(value = "x-api-key", required = false) String apiKey,
            @RequestHeader(value = "Idempotency-Key", required = false) String idempotencyKey,
            @Valid @RequestBody OpenApiRequestDto request) {
        Project project = openApiAuthService.requireProjectFromApiKey(apiKey);
        OpenNotificationService.OpenApiProcessResult result = openNotificationService.process(project, request, idempotencyKey);
        return ResponseEntity.accepted().body(OpenApiResponseDto.builder()
                .success(true)
                .requestId(result.requestId())
                .status(result.status())
                .message("Notification queued successfully")
                .build());
    }

    @PostMapping("/send-direct")
    public ResponseEntity<OpenApiResponseDto> sendDirect(
            @RequestHeader(value = "x-api-key", required = false) String apiKey,
            @RequestHeader(value = "Idempotency-Key", required = false) String idempotencyKey,
            @Valid @RequestBody OpenApiRequestDto request) {
        Project project = openApiAuthService.requireProjectFromApiKey(apiKey);
        OpenNotificationService.OpenApiProcessResult result = openNotificationService.processDirect(project, request, idempotencyKey);
        return ResponseEntity.accepted().body(OpenApiResponseDto.builder()
                .success(true)
                .requestId(result.requestId())
                .status(result.status())
                .message("Notification queued successfully")
                .build());
    }

    @ExceptionHandler(OpenApiException.class)
    public ResponseEntity<OpenApiResponseDto> handleOpenApiException(OpenApiException ex) {
        return ResponseEntity.status(ex.getStatus()).body(OpenApiResponseDto.builder()
                .success(false)
                .status("FAILED")
                .errorCode(ex.getErrorCode().name())
                .message(ex.getMessage())
                .build());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<OpenApiResponseDto> handleException(Exception ex) {
        log.error("Open API send failed with unexpected error", ex);
        return ResponseEntity.internalServerError().body(OpenApiResponseDto.builder()
                .success(false)
                .status("FAILED")
                .errorCode(OpenApiErrorCode.INTERNAL_ERROR.name())
                .message("Internal server error")
                .build());
    }
}
