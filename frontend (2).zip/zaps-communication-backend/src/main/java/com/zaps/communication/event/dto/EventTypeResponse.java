package com.zaps.communication.event.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EventTypeResponse {
    private Long id;
    private String eventCode;
    private String eventName;
}
