package com.zaps.communication.channel.entity;

import com.zaps.communication.common.AuditableEntity;
import com.zaps.communication.common.enums.ChannelCode;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "channels", uniqueConstraints = @UniqueConstraint(name = "uk_channel_code", columnNames = "code"))
@Getter
@Setter
public class Channel extends AuditableEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ChannelCode code;
    @Column(nullable = false)
    private boolean active = true;
}
