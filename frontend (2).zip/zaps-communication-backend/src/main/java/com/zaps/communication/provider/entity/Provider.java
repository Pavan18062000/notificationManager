package com.zaps.communication.provider.entity;

import com.zaps.communication.common.AuditableEntity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "providers", uniqueConstraints = @UniqueConstraint(name = "uk_provider_code", columnNames = "provider_code"))
@Getter
@Setter
public class Provider extends AuditableEntity {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 60)
    private String providerCode;
    @Column(nullable = false, length = 120)
    private String providerName;
    @Column(nullable = false)
    private boolean active = true;
}
