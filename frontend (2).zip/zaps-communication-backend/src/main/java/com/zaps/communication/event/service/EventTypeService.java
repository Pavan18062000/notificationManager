package com.zaps.communication.event.service;

import java.util.List;

import com.zaps.communication.event.dto.EventTypeRequest;
import com.zaps.communication.event.dto.EventTypeResponse;

public interface EventTypeService {
    EventTypeResponse create(EventTypeRequest request);
    List<EventTypeResponse> getAll();
}
