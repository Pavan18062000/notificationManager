package com.zaps.communication.routing.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NotificationRouteResponse {
    private Long id;
    private Long projectId;
    private Long countryId;
    private Long channelId;
    private Long eventTypeId;
    private Long providerId;
    private Integer priority;
    private boolean enabled;
    private Integer rateLimitPerMinute;
    private Integer maxRetries;
    private String fromEmail;
    private String senderId;
    private String providerAccountKey;
}
