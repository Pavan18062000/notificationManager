package com.zaps.communication.provider.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.zaps.communication.common.exception.DuplicateResourceException;
import com.zaps.communication.common.exception.ResourceNotFoundException;
import com.zaps.communication.provider.dto.ProviderRequest;
import com.zaps.communication.provider.dto.ProviderResponse;
import com.zaps.communication.provider.entity.Provider;
import com.zaps.communication.provider.repository.ProviderRepository;
import com.zaps.communication.provider.service.ProviderService;

@Service
public class ProviderServiceImpl implements ProviderService {
    private final ProviderRepository repository;
    public ProviderServiceImpl(ProviderRepository repository) { this.repository = repository; }
    public ProviderResponse create(ProviderRequest request){
        String providerCode = request.getProviderCode().trim().toUpperCase();
        if (repository.existsByProviderCodeIgnoreCase(providerCode)) throw new DuplicateResourceException("Provider code already exists");
        Provider p = new Provider();
        p.setProviderCode(providerCode);
        p.setProviderName(request.getProviderName().trim());
        p.setActive(Boolean.TRUE.equals(request.getActive()));
        return toResponse(repository.save(p));
    }
    public List<ProviderResponse> getAll(){ return repository.findAll().stream().map(this::toResponse).toList(); }
    public ProviderResponse update(Long id, ProviderRequest request){
        Provider p = repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Provider not found"));
        String providerCode = request.getProviderCode().trim().toUpperCase();
        if (!providerCode.equalsIgnoreCase(p.getProviderCode()) && repository.existsByProviderCodeIgnoreCase(providerCode)) {
            throw new DuplicateResourceException("Provider code already exists");
        }
        p.setProviderCode(providerCode);
        p.setProviderName(request.getProviderName().trim());
        p.setActive(Boolean.TRUE.equals(request.getActive()));
        return toResponse(repository.save(p));
    }
    private ProviderResponse toResponse(Provider p){ return ProviderResponse.builder().id(p.getId()).providerCode(p.getProviderCode()).providerName(p.getProviderName()).active(p.isActive()).build(); }
}
