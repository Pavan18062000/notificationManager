package com.zaps.communication.user.entity;

public enum UserRole {
    SUPER_ADMIN,
    PROJECT_ADMIN
}

