CREATE TABLE IF NOT EXISTS message_templates (
  id BIGINT NOT NULL AUTO_INCREMENT,
  channel ENUM('EMAIL','SMS','PUSH','WHATSAPP') NOT NULL,
  project_code VARCHAR(255) NOT NULL,
  template_code VARCHAR(255) NOT NULL,
  title VARCHAR(255),
  payload LONGTEXT NOT NULL,
  is_active BIT NOT NULL,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_message_templates_channel_project_template (channel, project_code, template_code)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS message_logs (
  id BIGINT NOT NULL AUTO_INCREMENT,
  channel ENUM('EMAIL','SMS','PUSH','WHATSAPP') NOT NULL,
  project_code VARCHAR(255) NOT NULL,
  template_code VARCHAR(255),
  destination VARCHAR(255) NOT NULL,
  title VARCHAR(255),
  payload LONGTEXT NOT NULL,
  status ENUM('PENDING','PROCESSING','SENT','FAILED','FAILED_RETRYABLE') NOT NULL,
  error_message VARCHAR(4000),
  kafka_topic VARCHAR(255),
  request_payload LONGTEXT,
  created_at DATETIME(6) NOT NULL,
  sent_at DATETIME(6),
  PRIMARY KEY (id),
  INDEX idx_message_logs_channel_project_status (channel, project_code, status)
) ENGINE=InnoDB;

SET @providers_has_legacy_cols := (
  SELECT COUNT(*)
  FROM information_schema.columns
  WHERE table_schema = DATABASE()
    AND table_name = 'providers'
    AND column_name IN ('channel', 'provider_type', 'is_active')
);

SET @sql := IF(
  @providers_has_legacy_cols = 3,
  "INSERT INTO providers (channel, provider_type, country_code, priority, is_active, encrypted_credentials, created_at, updated_at)
   SELECT 'PUSH', 'LOG', NULL, 999, true, NULL, NOW(6), NOW(6)
   WHERE NOT EXISTS (SELECT 1 FROM providers WHERE channel = 'PUSH' AND provider_type = 'LOG')",
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
  @providers_has_legacy_cols = 3,
  "INSERT INTO providers (channel, provider_type, country_code, priority, is_active, encrypted_credentials, created_at, updated_at)
   SELECT 'WHATSAPP', 'LOG', NULL, 999, true, NULL, NOW(6), NOW(6)
   WHERE NOT EXISTS (SELECT 1 FROM providers WHERE channel = 'WHATSAPP' AND provider_type = 'LOG')",
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
