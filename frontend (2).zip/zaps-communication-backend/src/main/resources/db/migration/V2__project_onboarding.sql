CREATE TABLE IF NOT EXISTS services (
  id BIGINT NOT NULL AUTO_INCREMENT,
  service_code VARCHAR(255) NOT NULL,
  service_name VARCHAR(255) NOT NULL,
  description VARCHAR(1000),
  is_active BIT NOT NULL,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_services_service_code (service_code)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS projects (
  id BIGINT NOT NULL AUTO_INCREMENT,
  project_code VARCHAR(255) NOT NULL,
  project_name VARCHAR(255) NOT NULL,
  description VARCHAR(1000),
  api_key_hash VARCHAR(128) NOT NULL,
  is_active BIT NOT NULL,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_projects_project_code (project_code)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS countries (
  id BIGINT NOT NULL AUTO_INCREMENT,
  country_code VARCHAR(2) NOT NULL,
  country_name VARCHAR(255) NOT NULL,
  is_active BIT NOT NULL,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_countries_country_code (country_code)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS project_services (
  id BIGINT NOT NULL AUTO_INCREMENT,
  project_id BIGINT NOT NULL,
  service_id BIGINT NOT NULL,
  is_enabled BIT NOT NULL,
  direct_payload_enabled BIT NOT NULL,
  template_payload_enabled BIT NOT NULL,
  description VARCHAR(1000),
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_project_services_project_service (project_id, service_id),
  CONSTRAINT fk_project_services_project FOREIGN KEY (project_id) REFERENCES projects (id),
  CONSTRAINT fk_project_services_service FOREIGN KEY (service_id) REFERENCES services (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS project_countries (
  id BIGINT NOT NULL AUTO_INCREMENT,
  project_id BIGINT NOT NULL,
  country_id BIGINT NOT NULL,
  is_enabled BIT NOT NULL,
  is_default_country BIT NOT NULL,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_project_countries_project_country (project_id, country_id),
  CONSTRAINT fk_project_countries_project FOREIGN KEY (project_id) REFERENCES projects (id),
  CONSTRAINT fk_project_countries_country FOREIGN KEY (country_id) REFERENCES countries (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT NOT NULL AUTO_INCREMENT,
  project_id BIGINT,
  email VARCHAR(255) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('SUPER_ADMIN','PROJECT_ADMIN') NOT NULL,
  is_active BIT NOT NULL,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_users_email (email),
  CONSTRAINT fk_users_project FOREIGN KEY (project_id) REFERENCES projects (id)
) ENGINE=InnoDB;
