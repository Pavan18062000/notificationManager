ALTER TABLE notification_requests
    ADD COLUMN request_uuid VARCHAR(128) NULL;

ALTER TABLE notification_logs
    ADD COLUMN attempt_no INT NULL,
    ADD COLUMN provider_code VARCHAR(64) NULL,
    ADD COLUMN http_status INT NULL,
    ADD COLUMN provider_message_id VARCHAR(255) NULL,
    ADD COLUMN provider_response TEXT NULL,
    ADD COLUMN error_message TEXT NULL,
    ADD COLUMN latency_ms BIGINT NULL,
    ADD COLUMN sent_at DATETIME NULL,
    ADD COLUMN failed_at DATETIME NULL;

