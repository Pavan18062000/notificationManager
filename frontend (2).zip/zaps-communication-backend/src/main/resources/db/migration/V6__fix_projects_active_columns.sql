-- Normalize projects active columns for environments with legacy schema.
SET @has_active := (
  SELECT COUNT(*)
  FROM information_schema.columns
  WHERE table_schema = DATABASE()
    AND table_name = 'projects'
    AND column_name = 'active'
);

SET @has_is_active := (
  SELECT COUNT(*)
  FROM information_schema.columns
  WHERE table_schema = DATABASE()
    AND table_name = 'projects'
    AND column_name = 'is_active'
);

SET @sql := IF(
  @has_active = 1 AND @has_is_active = 1,
  'UPDATE projects SET is_active = COALESCE(is_active, active)',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
  @has_active = 1 AND @has_is_active = 1,
  'ALTER TABLE projects DROP COLUMN active',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
  @has_active = 1 AND @has_is_active = 0,
  'ALTER TABLE projects CHANGE COLUMN active is_active BIT NOT NULL',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
