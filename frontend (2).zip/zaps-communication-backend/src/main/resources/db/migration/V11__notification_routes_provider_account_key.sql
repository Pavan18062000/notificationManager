ALTER TABLE notification_routes
    ADD COLUMN provider_account_key VARCHAR(128) NULL;

UPDATE notification_routes
SET provider_account_key = 'default'
WHERE provider_account_key IS NULL OR provider_account_key = '';

