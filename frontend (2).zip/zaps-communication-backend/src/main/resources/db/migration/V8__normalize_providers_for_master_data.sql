-- Allow provider master-data rows without legacy channel/provider_type payload.
SET @sql := IF(
  EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = DATABASE() AND table_name = 'providers' AND column_name = 'channel'
  ),
  "ALTER TABLE providers MODIFY COLUMN channel ENUM('EMAIL','SMS','PUSH','WHATSAPP') NULL",
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
  EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = DATABASE() AND table_name = 'providers' AND column_name = 'provider_type'
  ),
  "ALTER TABLE providers MODIFY COLUMN provider_type ENUM('SENDGRID','SMTP','INFOBIP','AWS_SES','TWILIO','MSG91','AWS_SNS','LOG') NULL",
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
  EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = DATABASE() AND table_name = 'providers' AND column_name = 'priority'
  ),
  "ALTER TABLE providers MODIFY COLUMN priority INT NOT NULL DEFAULT 1",
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
  EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = DATABASE() AND table_name = 'providers' AND column_name = 'is_active'
  ),
  "ALTER TABLE providers MODIFY COLUMN is_active BIT NOT NULL DEFAULT b'1'",
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
  EXISTS (
    SELECT 1 FROM information_schema.statistics
    WHERE table_schema = DATABASE() AND table_name = 'providers' AND index_name = 'uk_providers_channel_type_country'
  ),
  'DROP INDEX uk_providers_channel_type_country ON providers',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
