CREATE TABLE IF NOT EXISTS providers (
  id BIGINT NOT NULL AUTO_INCREMENT,
  channel ENUM('EMAIL','SMS','PUSH','WHATSAPP') NOT NULL,
  provider_type ENUM('SENDGRID','SMTP','INFOBIP','AWS_SES','TWILIO','MSG91','AWS_SNS','LOG') NOT NULL,
  country_code VARCHAR(2),
  priority INT NOT NULL,
  is_active BIT NOT NULL,
  encrypted_credentials LONGTEXT,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_providers_channel_type_country (channel, provider_type, country_code)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS provider_attempts (
  id BIGINT NOT NULL AUTO_INCREMENT,
  channel ENUM('EMAIL','SMS','PUSH','WHATSAPP') NOT NULL,
  log_id BIGINT NOT NULL,
  provider_type ENUM('SENDGRID','SMTP','INFOBIP','AWS_SES','TWILIO','MSG91','AWS_SNS','LOG') NOT NULL,
  priority INT NOT NULL,
  http_status INT NOT NULL,
  result_status ENUM('SENT','FAILED','FAILED_RETRYABLE') NOT NULL,
  error_message VARCHAR(1000),
  created_at DATETIME(6) NOT NULL,
  PRIMARY KEY (id),
  INDEX idx_provider_attempts_channel_log (channel, log_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sms_templates (
  id BIGINT NOT NULL AUTO_INCREMENT,
  project_code VARCHAR(255) NOT NULL,
  template_code VARCHAR(255) NOT NULL,
  message LONGTEXT NOT NULL,
  is_active BIT NOT NULL,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_sms_templates_project_template (project_code, template_code)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sms_logs (
  id BIGINT NOT NULL AUTO_INCREMENT,
  project_code VARCHAR(255) NOT NULL,
  template_code VARCHAR(255),
  recipient_phone VARCHAR(255) NOT NULL,
  message LONGTEXT NOT NULL,
  status ENUM('PENDING','PROCESSING','SENT','FAILED','FAILED_RETRYABLE') NOT NULL,
  error_message VARCHAR(4000),
  kafka_topic VARCHAR(255),
  request_payload LONGTEXT,
  created_at DATETIME(6) NOT NULL,
  sent_at DATETIME(6),
  PRIMARY KEY (id),
  INDEX idx_sms_logs_project_status (project_code, status)
) ENGINE=InnoDB;

SET @providers_has_legacy_cols := (
  SELECT COUNT(*)
  FROM information_schema.columns
  WHERE table_schema = DATABASE()
    AND table_name = 'providers'
    AND column_name IN ('channel', 'provider_type', 'is_active')
);

SET @sql := IF(
  @providers_has_legacy_cols = 3,
  "INSERT INTO providers (channel, provider_type, country_code, priority, is_active, encrypted_credentials, created_at, updated_at)
   SELECT 'EMAIL', 'LOG', NULL, 999, true, NULL, NOW(6), NOW(6)
   WHERE NOT EXISTS (SELECT 1 FROM providers WHERE channel = 'EMAIL' AND provider_type = 'LOG')",
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
  @providers_has_legacy_cols = 3,
  "INSERT INTO providers (channel, provider_type, country_code, priority, is_active, encrypted_credentials, created_at, updated_at)
   SELECT 'SMS', 'LOG', NULL, 999, true, NULL, NOW(6), NOW(6)
   WHERE NOT EXISTS (SELECT 1 FROM providers WHERE channel = 'SMS' AND provider_type = 'LOG')",
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
