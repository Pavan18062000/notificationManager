-- Normalize countries active columns for environments that previously had JPA-generated schema.
-- Some databases have both `active` and `is_active`; seed inserts now target `is_active`.

SET @has_active := (
  SELECT COUNT(*)
  FROM information_schema.columns
  WHERE table_schema = DATABASE()
    AND table_name = 'countries'
    AND column_name = 'active'
);

SET @has_is_active := (
  SELECT COUNT(*)
  FROM information_schema.columns
  WHERE table_schema = DATABASE()
    AND table_name = 'countries'
    AND column_name = 'is_active'
);

-- If both exist, backfill and drop legacy `active`.
SET @sql := IF(
  @has_active = 1 AND @has_is_active = 1,
  'UPDATE countries SET is_active = COALESCE(is_active, active)',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
  @has_active = 1 AND @has_is_active = 1,
  'ALTER TABLE countries DROP COLUMN active',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- If only legacy `active` exists, rename it to `is_active`.
SET @sql := IF(
  @has_active = 1 AND @has_is_active = 0,
  'ALTER TABLE countries CHANGE COLUMN active is_active BIT NOT NULL',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

