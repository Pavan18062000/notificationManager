package com.zaps.communication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZapsCommunicationBackendApplicationTests {

    @Test
    void contextLoads() {
    }
}
