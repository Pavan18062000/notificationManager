import type { Config } from "tailwindcss";

export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#ebfbf7",
          500: "#0f8f80",
          700: "#0b6d62"
        }
      }
    }
  },
  plugins: []
} satisfies Config;
