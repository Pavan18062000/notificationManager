import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      "/api": {
        target: "http://localhost:5000",
        changeOrigin: true
      },
      "/open-api": {
        target: "http://localhost:5000",
        changeOrigin: true
      }
    }
  },
  resolve: {
    alias: {
      modules: "/src/modules",
      shared: "/src/shared",
      services: "/src/services",
      hooks: "/src/hooks",
      layouts: "/src/layouts",
      routes: "/src/routes",
      utils: "/src/utils"
    }
  }
});
