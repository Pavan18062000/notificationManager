import { create } from "zustand";

type Toast = { id: number; message: string; type: "success" | "error" };

type AppStore = {
  toasts: Toast[];
  pushToast: (message: string, type: "success" | "error") => void;
  removeToast: (id: number) => void;
};

export const useAppStore = create<AppStore>((set) => ({
  toasts: [],
  pushToast: (message, type) =>
    set((s) => ({ toasts: [...s.toasts, { id: Date.now(), message, type }] })),
  removeToast: (id) => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) }))
}));
