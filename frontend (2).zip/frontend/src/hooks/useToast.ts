import { useAppStore } from "../hooks/useAppStore";

export function useToast() {
  const pushToast = useAppStore((s) => s.pushToast);
  return {
    success: (m: string) => pushToast(m, "success"),
    error: (m: string) => pushToast(m, "error")
  };
}
