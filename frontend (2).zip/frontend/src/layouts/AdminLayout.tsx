import { Outlet } from "react-router-dom";
import { Bell, Building2, ChartBar, Globe, Layers, MessageSquareText, Send, WalletCards, Link2 } from "lucide-react";
import { NavLink } from "react-router-dom";

const groups = [
  {
    title: "Overview",
    items: [["/dashboard", "Dashboard", ChartBar]]
  },
  {
    title: "Master Data",
    items: [
      ["/projects", "Projects", Building2],
      ["/countries", "Countries", Globe],
      ["/channels", "Channels", Layers],
      ["/providers", "Providers", WalletCards],
      ["/event-types", "Event Types", Bell],
      ["/templates", "Templates", MessageSquareText]
    ]
  },
  {
    title: "Mappings",
    items: [
      ["/notification-routes", "Notification Routes", Link2]
    ]
  },
  {
    title: "Communication",
    items: [["/notifications", "Send Notification", Send]]
  }
] as const;

export function AdminLayout() {
  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[270px_1fr]">
      <aside className="border-r bg-white p-4">
        <h1 className="mb-4 text-xl font-bold">Centralized Notification</h1>
        <nav className="space-y-4">
          {groups.map((group) => (
            <div key={group.title}>
              <p className="mb-1 px-2 text-xs font-semibold uppercase tracking-wide text-slate-500">{group.title}</p>
              <div className="space-y-1">
                {group.items.map(([to, label, Icon]) => (
                  <NavLink key={to} to={to} className={({ isActive }) => `flex items-center gap-2 rounded-md px-3 py-2 text-sm ${isActive ? "bg-brand-50 text-brand-700" : "hover:bg-slate-100"}`}>
                    <Icon size={16} /> {label}
                  </NavLink>
                ))}
              </div>
            </div>
          ))}
        </nav>
      </aside>
      <main className="p-6"><Outlet /></main>
    </div>
  );
}
