export type AppRole = "SUPER_ADMIN" | "PROJECT_ADMIN";

export type AuthUser = {
  id: number;
  email: string;
  role: AppRole;
  active: boolean;
  projectId?: number | null;
  projectCode?: string | null;
  projectName?: string | null;
};

export type AuthSession = {
  token: string;
  user: AuthUser;
};

const KEY = "auth_session";

export function getAuthSession(): AuthSession | null {
  const raw = localStorage.getItem(KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as AuthSession;
  } catch {
    return null;
  }
}

export function setAuthSession(session: AuthSession) {
  localStorage.setItem(KEY, JSON.stringify(session));
}

export function clearAuthSession() {
  localStorage.removeItem(KEY);
}

export function isProjectAdmin(): boolean {
  return getAuthSession()?.user?.role === "PROJECT_ADMIN";
}
