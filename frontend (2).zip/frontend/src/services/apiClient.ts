import axios from "axios";
import { clearAuthSession, getAuthSession } from "./authStorage";

export const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "http://localhost:5000"
});

apiClient.interceptors.request.use((config) => {
  const session = getAuthSession();
  if (session?.token) {
    config.headers.Authorization = `Bearer ${session.token}`;
  }
  return config;
});

apiClient.interceptors.response.use(
  (res) => res,
  (err) => {
    const requestUrl = String(err?.config?.url ?? "");
    const isOpenApiRequest = requestUrl.includes("/open-api/");
    if (!isOpenApiRequest && (err?.response?.status === 401 || err?.response?.status === 403)) {
      clearAuthSession();
      if (!window.location.pathname.startsWith("/login")) {
        window.location.href = "/login";
      }
    }
    const payload = err?.response?.data;
    const firstError = Array.isArray(payload?.errors) && payload.errors.length ? payload.errors[0] : null;
    return Promise.reject(firstError || payload?.message || "Request failed");
  }
);
