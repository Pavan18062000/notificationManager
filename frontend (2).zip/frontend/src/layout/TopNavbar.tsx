import { useEffect, useRef, useState } from "react";
import { Bell, ChevronDown, Menu, Moon, Search, Sun } from "lucide-react";
import { useLocation } from "react-router-dom";

type TopNavbarProps = {
  onToggleSidebar: () => void;
  isDark: boolean;
  onToggleTheme: () => void;
  onLogout: () => void;
  userLabel?: string;
  className?: string;
};

export function TopNavbar({ onToggleSidebar, isDark, onToggleTheme, onLogout, userLabel, className }: TopNavbarProps) {
  const [profileOpen, setProfileOpen] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);
  useLocation();

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setProfileOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <header className={`z-40 h-16 border-b border-[var(--border-color)] bg-[var(--card-bg)] ${className ?? ""}`}>
      <div className="flex h-full items-center justify-between gap-3 px-4 md:px-6">
        <div className="flex h-full items-center gap-3">
          <button className="rounded-md p-2 hover:bg-slate-100 dark:hover:bg-slate-800" onClick={onToggleSidebar} aria-label="Toggle sidebar">
            <Menu size={18} />
          </button>
        </div>

        <div className="flex h-full items-center gap-2">
          <label className="hidden h-10 items-center gap-2 rounded-md border border-[var(--border-color)] bg-[var(--bg-secondary)] px-2 text-sm text-[var(--text-secondary)] md:flex">
            <Search size={14} />
            <input className="w-44 bg-transparent text-[var(--text-primary)] outline-none placeholder:text-[var(--text-secondary)]" placeholder="Search..." />
          </label>
          <button className="rounded-md p-2 outline-none transition-colors hover:bg-slate-100 focus-visible:ring-2 focus-visible:ring-brand-500/40 dark:hover:bg-slate-800" onClick={onToggleTheme} aria-label="Toggle theme">
            {isDark ? <Sun size={18} /> : <Moon size={18} />}
          </button>
          <button className="rounded-md p-2 outline-none transition-colors hover:bg-slate-100 focus-visible:ring-2 focus-visible:ring-brand-500/40 dark:hover:bg-slate-800" aria-label="Notifications">
            <Bell size={18} />
          </button>
          <div className="relative" ref={profileRef}>
            <button
              className="flex h-10 items-center gap-[10px] rounded-[10px] bg-transparent px-3 py-2 outline-none transition-colors hover:bg-black/5 dark:hover:bg-white/5 focus-visible:ring-2 focus-visible:ring-brand-500/40"
              onClick={() => setProfileOpen((v) => !v)}
            >
              <div className="h-9 w-9 rounded-full bg-brand-500" />
              <span className="hidden max-w-[180px] truncate text-sm font-medium md:block">{userLabel ?? "Admin"}</span>
              <ChevronDown size={14} className="shrink-0" />
            </button>
            {profileOpen && (
              <div className="absolute right-0 mt-2 w-44 rounded-md border border-[var(--border-color)] bg-[var(--card-bg)] p-1 shadow-lg">
                <button className="w-full rounded px-3 py-2 text-left text-sm hover:bg-slate-100 dark:hover:bg-slate-800">Profile</button>
                <button className="w-full rounded px-3 py-2 text-left text-sm hover:bg-slate-100 dark:hover:bg-slate-800" onClick={onLogout}>Logout</button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
