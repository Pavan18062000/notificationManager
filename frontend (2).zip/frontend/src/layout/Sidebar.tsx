import { useEffect, useMemo, useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import { ChevronDown, Search, PanelLeftClose, PanelLeftOpen, X } from "lucide-react";
import { sidebarConfig, type Role } from "./sidebarConfig";

type SidebarProps = {
  role: Role;
  isCollapsed: boolean;
  onToggleCollapsed: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
};

export function Sidebar({ role, isCollapsed, onToggleCollapsed, mobileOpen, onCloseMobile }: SidebarProps) {
  const { pathname } = useLocation();
  const [query, setQuery] = useState("");
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({});

  const filtered = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return sidebarConfig
      .map((group) => ({
        ...group,
        modules: group.modules.filter((module) => {
          if (module.roles && !module.roles.includes(role)) return false;
          if (!normalized) return true;
          return `${group.label} ${module.label}`.toLowerCase().includes(normalized);
        })
      }))
      .filter((group) => group.modules.length > 0);
  }, [query, role]);

  useEffect(() => {
    const next: Record<string, boolean> = {};
    filtered.forEach((group) => {
      if (group.modules.some((m) => pathname.startsWith(m.path))) next[group.id] = true;
    });
    setOpenGroups((prev) => ({ ...prev, ...next }));
  }, [pathname, filtered]);

  return (
    <>
      {mobileOpen && <button className="fixed inset-0 z-40 bg-black/40 lg:hidden" onClick={onCloseMobile} aria-label="Close sidebar overlay" />}

      <aside
        className={`fixed left-0 top-0 z-50 h-screen border-r border-[var(--border-color)] bg-[var(--card-bg)] text-[var(--text-primary)] shadow-sm transition-all duration-300 lg:translate-x-0 ${
          mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        } ${isCollapsed ? "w-[88px]" : "w-[290px]"}`}
      >
        <div className="flex h-full flex-col">
          <div className="flex items-center justify-between border-b border-[var(--border-color)] px-4 py-4">
            {!isCollapsed && <h1 className="truncate text-xl font-semibold">Centralized Notification</h1>}
            <div className="flex items-center gap-1">
              <button className="rounded-md p-2 hover:bg-slate-100 dark:hover:bg-slate-800" onClick={onToggleCollapsed} aria-label="Toggle sidebar">
                {isCollapsed ? <PanelLeftOpen size={16} /> : <PanelLeftClose size={16} />}
              </button>
              <button className="rounded-md p-2 hover:bg-slate-100 dark:hover:bg-slate-800 lg:hidden" onClick={onCloseMobile} aria-label="Close menu">
                <X size={16} />
              </button>
            </div>
          </div>

          {!isCollapsed && (
            <div className="border-b border-[var(--border-color)] px-4 py-3">
              <label className="flex items-center gap-2 rounded-md border border-[var(--border-color)] bg-[var(--bg-secondary)] px-3 py-3 text-base text-[var(--text-secondary)]">
                <Search size={15} />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search modules"
                  className="w-full bg-transparent outline-none"
                />
              </label>
            </div>
          )}

          <nav className="flex-1 space-y-5 overflow-y-auto overflow-x-hidden px-2 pr-2 py-4">
            {filtered.map((group) => (
              <section key={group.id}>
                {!isCollapsed && (
                  <button
                    className="mb-2 flex w-full items-center justify-between rounded-md px-3 py-2 text-sm font-bold uppercase tracking-wide text-[var(--text-secondary)] hover:bg-slate-100 dark:hover:bg-slate-800"
                    onClick={() => setOpenGroups((prev) => ({ ...prev, [group.id]: !prev[group.id] }))}
                  >
                    {group.label}
                    <ChevronDown size={16} className={`ml-auto shrink-0 transition-transform ${openGroups[group.id] ? "rotate-180" : ""}`} />
                  </button>
                )}
                <div className={`space-y-1 overflow-hidden transition-all duration-300 ${isCollapsed || openGroups[group.id] ? "max-h-[600px]" : "max-h-0"}`}>
                  {group.modules.map((module) => {
                    const isActive = pathname.startsWith(module.path);
                    return (
                      <NavLink
                        key={module.id}
                        to={module.path}
                        onClick={onCloseMobile}
                        className={`group relative box-border flex h-12 w-full max-w-full items-center gap-3 overflow-hidden rounded-xl border border-transparent px-4 py-3 text-[15px] font-medium transition ${
                          isActive
                            ? "border-slate-900/10 bg-[#F4FBF8] text-[var(--text-primary)] dark:border-white/10 dark:bg-emerald-500/10"
                            : "text-[var(--text-primary)] hover:bg-slate-900/5 dark:hover:bg-white/5"
                        }`}
                        title={isCollapsed ? module.label : undefined}
                      >
                        {isActive && <span className="absolute left-0 top-1/2 h-7 w-1 -translate-y-1/2 rounded-r bg-brand-500" />}
                        <module.icon size={18} className={`shrink-0 self-center ${isActive ? "text-inherit" : ""}`} />
                        {!isCollapsed && <span>{module.label}</span>}
                        {isCollapsed && (
                          <span className="pointer-events-none absolute left-full z-20 ml-2 hidden whitespace-nowrap rounded bg-slate-900 px-2 py-1 text-xs text-white group-hover:block">
                            {module.label}
                          </span>
                        )}
                      </NavLink>
                    );
                  })}
                </div>
              </section>
            ))}
          </nav>
        </div>
      </aside>
    </>
  );
}
