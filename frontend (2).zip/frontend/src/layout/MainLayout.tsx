import { Component, ReactNode, useState } from "react";
import { Outlet } from "react-router-dom";
import { Sidebar } from "./Sidebar";
import type { Role } from "./sidebarConfig";
import { TopNavbar } from "./TopNavbar";
import { clearAuthSession, getAuthSession } from "services/authStorage";
import { apiClient } from "services/apiClient";

class RouteErrorBoundary extends Component<{ children: ReactNode }, { hasError: boolean; message: string }> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false, message: "" };
  }

  static getDerivedStateFromError(error: unknown) {
    return { hasError: true, message: String(error) };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700">
          <p className="font-semibold">Page rendering error</p>
          <p className="mt-1">{this.state.message}</p>
        </div>
      );
    }
    return this.props.children;
  }
}

function getCurrentRole(): Role {
  const session = getAuthSession();
  return session?.user?.role === "PROJECT_ADMIN" ? "PROJECT_ADMIN" : "SUPER_ADMIN";
}

export function MainLayout() {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [isDark, setIsDark] = useState(() => localStorage.getItem("theme") === "dark");
  const role = getCurrentRole();
  const session = getAuthSession();

  if (isDark) document.documentElement.classList.add("dark");
  else document.documentElement.classList.remove("dark");

  return (
    <div className="h-screen overflow-hidden bg-[var(--bg-primary)] text-[var(--text-primary)]">
      <Sidebar
        role={role}
        isCollapsed={isCollapsed}
        onToggleCollapsed={() => setIsCollapsed((v) => !v)}
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
      />

      <div className={`h-screen w-full bg-[var(--bg-secondary)] transition-all duration-300 ${isCollapsed ? "lg:ml-[88px] lg:w-[calc(100%-88px)]" : "lg:ml-[290px] lg:w-[calc(100%-290px)]"}`}>
        <TopNavbar
          className={`fixed top-0 right-0 ${isCollapsed ? "lg:left-[88px]" : "lg:left-[290px]"} left-0`}
          onToggleSidebar={() => (window.innerWidth < 1024 ? setMobileOpen((v) => !v) : setIsCollapsed((v) => !v))}
          isDark={isDark}
          userLabel={session?.user?.email ?? "Admin"}
          onLogout={() => {
            apiClient.post("/api/auth/logout").catch(() => undefined).finally(() => {
              clearAuthSession();
              window.location.href = "/login";
            });
          }}
          onToggleTheme={() => {
            setIsDark((v) => {
              const next = !v;
              localStorage.setItem("theme", next ? "dark" : "light");
              return next;
            });
          }}
        />
        <main className="h-screen overflow-y-auto bg-[var(--bg-secondary)] px-4 pb-4 pt-16 md:px-6 md:pb-6 md:pt-16">
          <RouteErrorBoundary>
            <Outlet />
          </RouteErrorBoundary>
        </main>
      </div>
    </div>
  );
}
