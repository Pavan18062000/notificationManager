import type { LucideIcon } from "lucide-react";
import { LayoutDashboard, Database, Link2, Send, BarChart3, Settings, FolderKanban, Globe, Cable, Building2, Bell, FileText, ShieldCheck, Users, PanelsTopLeft, Code2, KeyRound, ClipboardList, Activity } from "lucide-react";

export type Role = "SUPER_ADMIN" | "PROJECT_ADMIN";

export type SidebarModule = {
  id: string;
  label: string;
  path: string;
  icon: LucideIcon;
  roles?: Role[];
};

export type SidebarGroup = {
  id: string;
  label: string;
  icon: LucideIcon;
  modules: SidebarModule[];
};

export const sidebarConfig: SidebarGroup[] = [
  {
    id: "dashboard",
    label: "Dashboard",
    icon: LayoutDashboard,
    modules: [
      { id: "dashboard", label: "Dashboard", path: "/dashboard", icon: LayoutDashboard },
      { id: "project-overview", label: "Project Overview", path: "/project-overview", icon: PanelsTopLeft }
    ]
  },
  {
    id: "master-data",
    label: "Master Data",
    icon: Database,
    modules: [
      { id: "projects", label: "Projects", path: "/projects", icon: FolderKanban, roles: ["SUPER_ADMIN"] },
      { id: "countries", label: "Countries", path: "/countries", icon: Globe, roles: ["SUPER_ADMIN"] },
      { id: "channels", label: "Channels", path: "/channels", icon: Cable, roles: ["SUPER_ADMIN"] },
      { id: "providers", label: "Providers", path: "/providers", icon: Building2, roles: ["SUPER_ADMIN"] },
      { id: "event-types", label: "Event Types", path: "/event-types", icon: Bell, roles: ["SUPER_ADMIN"] },
      { id: "templates", label: "Templates", path: "/templates", icon: FileText }
    ]
  },
  {
    id: "mappings",
    label: "Mappings",
    icon: Link2,
    modules: [
      { id: "notification-routes", label: "Notification Routes", path: "/notification-routes", icon: ShieldCheck }
    ]
  },
  {
    id: "communication",
    label: "Communication",
    icon: Send,
    modules: [{ id: "notification", label: "Notifications", path: "/notifications", icon: Send }]
  },
  {
    id: "developer-open-api",
    label: "Developer / Open API",
    icon: Code2,
    modules: [
      { id: "open-api-credentials", label: "API Credentials", path: "/developer/open-api/credentials", icon: KeyRound },
      { id: "open-api-docs", label: "Open API Docs", path: "/developer/open-api/docs", icon: FileText },
      { id: "open-api-logs", label: "Open API Logs", path: "/developer/open-api/logs", icon: ClipboardList },
      { id: "open-api-queue", label: "Queue Status", path: "/developer/open-api/queue-status", icon: Activity }
    ]
  },
  {
    id: "reports",
    label: "Reports",
    icon: BarChart3,
    modules: [{ id: "reports", label: "Reports", path: "/reports", icon: BarChart3, roles: ["SUPER_ADMIN", "PROJECT_ADMIN"] }]
  },
  {
    id: "settings",
    label: "Settings",
    icon: Settings,
    modules: [
      { id: "users", label: "Users", path: "/users", icon: Users, roles: ["SUPER_ADMIN"] },
      { id: "settings", label: "Settings", path: "/settings", icon: Settings, roles: ["SUPER_ADMIN"] }
    ]
  }
];
