import { createBrowserRouter, Navigate } from "react-router-dom";
import { MainLayout } from "../layout/MainLayout";
import { ToastContainer } from "../shared/ToastContainer";
import { ProtectedRoute } from "./ProtectedRoute";

import DashboardPage from "../modules/dashboard/pages/DashboardList";
import ProjectList from "../modules/project/pages/ProjectList";
import CountryList from "../modules/country/pages/CountryList";
import ChannelList from "../modules/channel/pages/ChannelList";
import ProviderList from "../modules/provider/pages/ProviderList";
import NotificationRouteList from "../modules/notificationroute/pages/NotificationRouteList";
import EventtypeList from "../modules/eventtype/pages/EventtypeList";
import TemplateList from "../modules/template/pages/TemplateList";
import NotificationList from "../modules/notification/pages/NotificationList";
import LoginPage from "../modules/auth/pages/LoginPage";
import UserList from "../modules/user/pages/UserList";
import ProjectOverviewPage from "../modules/projectoverview/pages/ProjectOverviewPage";
import OpenApiCredentialsPage from "../modules/openapi/pages/OpenApiCredentialsPage";
import OpenApiDocsPage from "../modules/openapi/pages/OpenApiDocsPage";
import OpenApiLogsPage from "../modules/openapi/pages/OpenApiLogsPage";
import OpenApiQueueStatusPage from "../modules/openapi/pages/OpenApiQueueStatusPage";
import ReportsPage from "../modules/reports/pages/ReportsPage";

function LayoutWithToasts() {
  return (
    <>
      <MainLayout />
      <ToastContainer />
    </>
  );
}

export const router = createBrowserRouter([
  { path: "/login", element: <LoginPage /> },
  { path: "/", element: <Navigate to="/dashboard" replace /> },
  {
    path: "/",
    children: [
      {
        element: <ProtectedRoute />,
        children: [
          {
            path: "/",
            element: <LayoutWithToasts />,
            children: [
              { path: "dashboard", element: <DashboardPage /> },
              { path: "project-overview", element: <ProjectOverviewPage /> },
              { path: "projects", element: <ProjectList /> },
              { path: "countries", element: <CountryList /> },
              { path: "channels", element: <ChannelList /> },
              { path: "providers", element: <ProviderList /> },
              { path: "notification-routes", element: <NotificationRouteList /> },
              { path: "event-types", element: <EventtypeList /> },
              { path: "templates", element: <TemplateList /> },
              { path: "notifications", element: <NotificationList /> },
              { path: "users", element: <UserList /> },
              { path: "developer/open-api/credentials", element: <OpenApiCredentialsPage /> },
              { path: "developer/open-api/docs", element: <OpenApiDocsPage /> },
              { path: "developer/open-api/logs", element: <OpenApiLogsPage /> },
              { path: "developer/open-api/queue-status", element: <OpenApiQueueStatusPage /> },
              { path: "reports", element: <ReportsPage /> },
              { path: "settings", element: <div className="rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-4 text-sm text-[var(--text-secondary)]">Settings module</div> },
              { path: "*", element: <Navigate to="/dashboard" replace /> }
            ]
          }
        ]
      }
    ]
  }
]);
