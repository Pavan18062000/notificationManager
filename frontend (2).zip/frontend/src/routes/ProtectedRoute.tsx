import { Navigate, Outlet, useLocation } from "react-router-dom";
import { getAuthSession } from "services/authStorage";

export function ProtectedRoute() {
  const location = useLocation();
  const session = getAuthSession();
  if (!session?.token) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }
  return <Outlet />;
}

