export type ApiResponse<T> = {
  success: boolean;
  message: string;
  data: T;
  errors?: string[];
};

export function unwrap<T>(res: ApiResponse<T> | T): T {
  if ((res as ApiResponse<T>).success !== undefined) {
    const typed = res as ApiResponse<T>;
    if (!typed.success) throw new Error(typed.message || typed.errors?.[0] || "Request failed");
    return typed.data;
  }
  return res as T;
}
