export function buildOptionLabel(parts: Array<string | number | null | undefined>, fallback: string) {
  const clean = parts
    .map((v) => (v == null ? "" : String(v).trim()))
    .filter((v) => v.length > 0);
  return clean.length ? clean.join(" - ") : fallback;
}

