import { useAppStore } from "../hooks/useAppStore";

export function ToastContainer() {
  const toasts = useAppStore((s) => s.toasts);
  const removeToast = useAppStore((s) => s.removeToast);
  return (
    <div className="fixed right-4 top-4 space-y-2">
      {toasts.map((t) => (
        <button key={t.id} onClick={() => removeToast(t.id)} className={`rounded-md px-3 py-2 text-white ${t.type === "success" ? "bg-emerald-600" : "bg-red-600"}`}>{t.message}</button>
      ))}
    </div>
  );
}
