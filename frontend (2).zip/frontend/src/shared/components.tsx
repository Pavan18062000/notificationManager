import clsx from "clsx";
import { ReactNode } from "react";

export function Button({ children, className, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return <button className={clsx("rounded-md bg-brand-500 px-4 py-2 text-white hover:bg-brand-700 disabled:opacity-60", className)} {...props}>{children}</button>;
}

export function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input className="w-full rounded-md border border-[var(--border-color)] bg-[var(--card-bg)] px-3 py-2 text-[var(--text-primary)] outline-none focus:border-brand-500 placeholder:text-[var(--text-secondary)]" {...props} />;
}

export function Select({ children, ...props }: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select className="w-full appearance-none rounded-md border border-[var(--border-color)] bg-[var(--card-bg)] px-3 py-2 text-[var(--text-primary)] outline-none focus:border-brand-500 disabled:cursor-not-allowed disabled:opacity-60" {...props}>{children}</select>;
}

export function PageHeader({ title, description, action }: { title: string; description?: string; action?: ReactNode }) {
  return (
    <div className="sticky top-0 z-10 mb-4 border-b border-[var(--border-color)] bg-[var(--bg-secondary)] py-3 backdrop-blur">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">{title}</h1>
          {description ? <p className="mt-1 text-sm text-[var(--text-secondary)]">{description}</p> : null}
        </div>
        {action}
      </div>
    </div>
  );
}

export function LoadingSpinner() { return <div className="animate-pulse text-slate-500">Loading...</div>; }

export function EmptyState({ text, hint, action }: { text: string; hint?: string; action?: ReactNode }) {
  return (
    <div className="rounded-lg border border-dashed border-[var(--border-color)] bg-[var(--card-bg)] p-8 text-center text-[var(--text-primary)]">
      <div className="mx-auto mb-2 h-10 w-10 rounded-full bg-[var(--bg-secondary)]" />
      <p className="font-medium">{text}</p>
      {hint ? <p className="mt-1 text-sm text-[var(--text-secondary)]">{hint}</p> : null}
      {action ? <div className="mt-4">{action}</div> : null}
    </div>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const tone = status.includes("FAIL") ? "bg-red-100 text-red-700" : status.includes("ACTIVE") || status.includes("SENT") ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700";
  return <span className={`rounded-full px-2 py-1 text-xs font-medium ${tone}`}>{status}</span>;
}

export function DataTable({ headers, rows }: { headers: string[]; rows: ReactNode[][] }) {
  return (
    <div className="overflow-auto rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] shadow-sm">
      <table className="w-full min-w-[640px] text-sm lg:min-w-[900px]">
        <thead className="bg-[var(--bg-secondary)]"><tr>{headers.map((h) => <th key={h} className="px-4 py-3 text-left text-base font-semibold">{h}</th>)}</tr></thead>
        <tbody>{rows.map((r, i) => <tr key={i} className="border-t border-[var(--border-color)]">{r.map((c, j) => <td key={j} className="px-4 py-3 text-[15px]">{c}</td>)}</tr>)}</tbody>
      </table>
    </div>
  );
}

export function ListToolbar({ query, onQueryChange, pageSize, onPageSizeChange }: { query: string; onQueryChange: (v: string) => void; pageSize: number; onPageSizeChange: (v: number) => void }) {
  void pageSize;
  void onPageSizeChange;
  return (
    <div className="mb-3 flex flex-wrap items-center gap-2">
      <input className="w-full max-w-xs rounded-md border border-[var(--border-color)] bg-[var(--card-bg)] px-3 py-2 text-sm text-[var(--text-primary)] outline-none focus:border-brand-500 placeholder:text-[var(--text-secondary)]" placeholder="Search..." value={query} onChange={(e) => onQueryChange(e.target.value)} />
    </div>
  );
}

export function PaginationControls({ page, totalPages, onPageChange }: { page: number; totalPages: number; onPageChange: (page: number) => void }) {
  return (
    <div className="mt-4 flex items-center justify-center gap-2 text-sm">
      <button className="h-10 w-10 rounded-md border border-[var(--border-color)] bg-[var(--card-bg)] text-[var(--text-secondary)] disabled:opacity-50" disabled={page <= 1} onClick={() => onPageChange(page - 1)}>&lt;</button>
      <span className="flex h-10 min-w-10 items-center justify-center rounded-md bg-fuchsia-900 px-4 font-semibold text-white">{page}</span>
      <button className="h-10 w-10 rounded-md border border-[var(--border-color)] bg-[var(--card-bg)] text-[var(--text-secondary)] disabled:opacity-50" disabled={page >= totalPages} onClick={() => onPageChange(page + 1)}>&gt;</button>
    </div>
  );
}

export function Modal({ open, title, children }: { open: boolean; title: string; children: ReactNode }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="max-h-[90vh] w-[90%] max-w-[600px] overflow-y-auto rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-4 shadow-xl">
        <h3 className="mb-3 text-lg font-semibold">{title}</h3>
        {children}
      </div>
    </div>
  );
}

export function ConfirmDialog({ open, title, onConfirm, onCancel }: { open: boolean; title: string; onConfirm: () => void; onCancel: () => void }) {
  return <Modal open={open} title={title}><div className="flex gap-2"><Button onClick={onConfirm}>Confirm</Button><Button className="bg-slate-500 hover:bg-slate-600" onClick={onCancel}>Cancel</Button></div></Modal>;
}

export function JsonEditor({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return <textarea rows={6} className="w-full rounded-md border border-[var(--border-color)] bg-[var(--card-bg)] px-3 py-2 font-mono text-xs text-[var(--text-primary)] outline-none focus:border-brand-500" value={value} onChange={(e) => onChange(e.target.value)} />;
}
