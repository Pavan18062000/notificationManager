import { PageHeader } from "shared/components";

export default function OpenApiDocsPage() {
  const curlTemplate = `curl -X POST 'http://localhost:5000/open-api/v1/notifications/send' \\
  -H 'Content-Type: application/json' \\
  -H 'x-api-key: <PROJECT_API_KEY>' \\
  -H 'Idempotency-Key: req-123' \\
  -d '{"countryCode":"IN","eventCode":"OTP_LOGIN","channel":"SMS","recipient":"9876543210","body":"Your OTP is {{otp}}","templateData":{"otp":"123456"}}'`;

  const curlDirect = `curl -X POST 'http://localhost:5000/open-api/v1/notifications/send-direct' \\
  -H 'Content-Type: application/json' \\
  -H 'x-api-key: <PROJECT_API_KEY>' \\
  -H 'Idempotency-Key: req-124' \\
  -d '{"countryCode":"IN","eventCode":"OTP_LOGIN","channel":"EMAIL","recipient":"test@example.com","subject":"OTP Verification","body":"Hi Pavan, your OTP is 123456"}'`;

  return (
    <div className="space-y-4">
      <PageHeader title="Developer / Open API - Documentation" description="Public endpoint reference for external project notification triggers." />
      <div className="rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-4 text-sm">
        <p><strong>Template Endpoint:</strong> <code>POST /open-api/v1/notifications/send</code></p>
        <p className="mt-2"><strong>Headers:</strong> <code>x-api-key</code>, optional <code>Idempotency-Key</code></p>
        <p className="mt-2 text-xs text-[var(--text-secondary)]">Use this endpoint when body/subject contains placeholders like <code>{'{{otp}}'}</code> with <code>templateData</code>.</p>
        <pre className="mt-3 overflow-auto rounded border border-[var(--border-color)] bg-[var(--bg-secondary)] p-3 text-xs">{curlTemplate}</pre>
      </div>

      <div className="rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-4 text-sm">
        <p><strong>Direct Endpoint (No templateData):</strong> <code>POST /open-api/v1/notifications/send-direct</code></p>
        <p className="mt-2"><strong>Headers:</strong> <code>x-api-key</code>, optional <code>Idempotency-Key</code></p>
        <p className="mt-2 text-xs text-[var(--text-secondary)]">Use this endpoint when subject/body are already final text and no variable rendering is required.</p>
        <pre className="mt-3 overflow-auto rounded border border-[var(--border-color)] bg-[var(--bg-secondary)] p-3 text-xs">{curlDirect}</pre>
      </div>
    </div>
  );
}
