import { PageHeader } from "shared/components";

export default function OpenApiLogsPage() {
  return (
    <div className="space-y-4">
      <PageHeader title="Developer / Open API - Logs" description="Track requestId, channel, provider and delivery states for external API calls." />
      <div className="rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-4 text-sm text-[var(--text-secondary)]">
        Open API monitoring table can be backed by <code>notification_requests</code> and <code>notification_logs</code>.
      </div>
    </div>
  );
}

