import { PageHeader } from "shared/components";

export default function OpenApiQueueStatusPage() {
  return (
    <div className="space-y-4">
      <PageHeader title="Developer / Open API - RabbitMQ Queue Status" description="Queue health snapshot for notification processing pipelines." />
      <div className="rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-4 text-sm text-[var(--text-secondary)]">
        Queue status API can expose: ready, unacked, consumers, publish rate, ack rate for SMS/EMAIL/WHATSAPP/PUSH queues.
      </div>
    </div>
  );
}

