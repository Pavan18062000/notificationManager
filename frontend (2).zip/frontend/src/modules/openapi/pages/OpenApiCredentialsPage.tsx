import { useMemo, useState } from "react";
import { useProjectList } from "modules/project/hooks/useProject";
import { Button, PageHeader, Select } from "shared/components";
import { getAuthSession, isProjectAdmin } from "services/authStorage";
import { openApiApi } from "../api/openApiApi";
import { useToast } from "hooks/useToast";

export default function OpenApiCredentialsPage() {
  const OPEN_API_KEY_CACHE = "open_api_keys_by_project";
  const toast = useToast();
  const { data } = useProjectList();
  const session = getAuthSession();
  const projectAdmin = isProjectAdmin();
  const projects = useMemo(() => (data?.data ?? data ?? []), [data]);
  const allowed = projectAdmin ? projects.filter((p: any) => p.id === session?.user?.projectId) : projects;
  const [projectId, setProjectId] = useState<number>(Number(session?.user?.projectId ?? allowed[0]?.id ?? 0));
  const [apiKey, setApiKey] = useState("");

  return (
    <div className="space-y-4">
      <PageHeader title="Developer / Open API - API Credentials" description="Generate and rotate project API keys for Open API access." />
      <div className="rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-4">
        <div className="grid gap-3 md:grid-cols-[1fr_auto]">
          <Select value={projectId || ""} onChange={(e) => setProjectId(Number(e.target.value))} disabled={projectAdmin}>
            {allowed.length ? allowed.map((p: any) => <option key={p.id} value={p.id}>{p.projectCode} - {p.projectName}</option>) : <option value="">No project available</option>}
          </Select>
          <Button
            type="button"
            disabled={!projectId}
            onClick={() => openApiApi.regenerateApiKey(projectId)
              .then((res: any) => {
                const payload = res?.data ?? res;
                const rawKey = String(payload?.apiKey ?? "");
                setApiKey(rawKey);
                const selected = allowed.find((p: any) => p.id === projectId);
                if (selected?.projectCode && rawKey) {
                  const current = JSON.parse(localStorage.getItem(OPEN_API_KEY_CACHE) || "{}");
                  current[selected.projectCode] = rawKey;
                  localStorage.setItem(OPEN_API_KEY_CACHE, JSON.stringify(current));
                }
                toast.success("API key regenerated");
              })
              .catch((e) => toast.error(String(e)))}
          >
            Regenerate API Key
          </Button>
        </div>
        <p className="mt-3 text-sm text-amber-700 dark:text-amber-300">API key is shown only once. Store it securely.</p>
        <div className="mt-3 rounded-md border border-[var(--border-color)] bg-[var(--bg-secondary)] p-3 font-mono text-sm">
          {apiKey || "No key generated in this session"}
        </div>
      </div>
    </div>
  );
}
