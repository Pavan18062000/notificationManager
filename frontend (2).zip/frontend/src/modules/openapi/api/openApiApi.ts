import { apiClient } from "services/apiClient";

export const openApiApi = {
  getApiKey: async (projectId: number) => (await apiClient.get(`/api/projects/${projectId}/api-key`)).data,
  regenerateApiKey: async (projectId: number) => (await apiClient.post(`/api/projects/${projectId}/api-key/regenerate`)).data,
};
