import { useEffect, useMemo, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { useProjectList } from "modules/project/hooks/useProject";
import { getAuthSession, isProjectAdmin } from "services/authStorage";
import { projectOverviewApi } from "../api/projectOverviewApi";
import { PageHeader, Select, DataTable, EmptyState, StatusBadge, LoadingSpinner, PaginationControls } from "shared/components";
import { buildOptionLabel } from "utils/optionLabel";

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="space-y-2 rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-4">
      <h3 className="text-base font-semibold">{title}</h3>
      {children}
    </section>
  );
}

export default function ProjectOverviewPage() {
  const session = getAuthSession();
  const projectAdmin = isProjectAdmin();
  const assignedProjectId = session?.user?.projectId ?? null;
  const { data: projectsData, isLoading: projectsLoading } = useProjectList();
  const projects = useMemo(
    () => (projectsData?.data ?? projectsData ?? []).map((x: any) => ({
      id: x.id as number,
      label: buildOptionLabel([x.projectCode, x.projectName], `Project #${x.id}`)
    })),
    [projectsData]
  );
  const [selectedProjectId, setSelectedProjectId] = useState<number | null>(assignedProjectId ?? null);
  const [logPage, setLogPage] = useState(1);
  const logPageSize = 10;

  useEffect(() => {
    if (selectedProjectId) return;
    if (!projects.length) return;
    setSelectedProjectId(projects[0].id);
  }, [projects, selectedProjectId]);

  const overviewQuery = useQuery({
    queryKey: ["project-overview", selectedProjectId],
    queryFn: () => projectOverviewApi.get(Number(selectedProjectId)),
    enabled: !!selectedProjectId
  });

  const overview = overviewQuery.data?.data ?? overviewQuery.data;
  const failedLogs = overview?.failedLogs ?? [];
  const logTotalPages = Math.max(1, Math.ceil(failedLogs.length / logPageSize));
  const pagedLogs = failedLogs.slice((logPage - 1) * logPageSize, logPage * logPageSize);

  return (
    <div className="space-y-4">
      <PageHeader title="Project Overview" description="360° view of project configurations, templates, and notifications" />
      <div className="rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-4">
        <label className="mb-2 block text-sm text-[var(--text-secondary)]">Project</label>
        <Select
          value={selectedProjectId ?? ""}
          onChange={(e) => {
            const value = e.target.value ? Number(e.target.value) : null;
            setSelectedProjectId(value);
            setLogPage(1);
          }}
          disabled={projectAdmin || projectsLoading || !projects.length}
        >
          {projects.length ? projects.map((p: any) => <option key={p.id} value={p.id}>{p.label}</option>) : <option value="">No projects found</option>}
        </Select>
      </div>

      {overviewQuery.isLoading ? <LoadingSpinner /> : null}
      {overviewQuery.isError ? <EmptyState text="Failed to load project overview" hint={String(overviewQuery.error)} /> : null}
      {!overviewQuery.isLoading && !overviewQuery.isError && !overview ? <EmptyState text="Data not found" hint="Select a project to view details." /> : null}

      {overview ? (
        <div className="space-y-4">
          <Section title="Project Details">
            <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
              <div><p className="text-xs text-[var(--text-secondary)]">Project Code</p><p>{overview.project?.projectCode ?? "-"}</p></div>
              <div><p className="text-xs text-[var(--text-secondary)]">Project Name</p><p>{overview.project?.projectName ?? "-"}</p></div>
              <div><p className="text-xs text-[var(--text-secondary)]">Status</p><StatusBadge status={overview.project?.active ? "ACTIVE" : "INACTIVE"} /></div>
              <div><p className="text-xs text-[var(--text-secondary)]">Description</p><p>{overview.project?.description ?? "-"}</p></div>
              <div><p className="text-xs text-[var(--text-secondary)]">Created At</p><p>{overview.project?.createdAt ? new Date(overview.project.createdAt).toLocaleString() : "-"}</p></div>
              <div><p className="text-xs text-[var(--text-secondary)]">API Key Configured</p><p>{overview.project?.apiKeyConfigured ? "Yes" : "No"}</p></div>
              <div><p className="text-xs text-[var(--text-secondary)]">API Key (Masked)</p><p className="font-mono">{overview.project?.apiKeyMasked ?? "-"}</p></div>
              <div><p className="text-xs text-[var(--text-secondary)]">API Key Updated</p><p>{overview.project?.apiKeyUpdatedAt ? new Date(overview.project.apiKeyUpdatedAt).toLocaleString() : "-"}</p></div>
            </div>
          </Section>

          <Section title="Notification Summary">
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {[
                ["Total Requests", overview.summary?.totalRequests ?? 0],
                ["Sent", overview.summary?.sent ?? 0],
                ["Failed", overview.summary?.failed ?? 0],
                ["Pending", overview.summary?.pending ?? 0],
                ["Processing", overview.summary?.processing ?? 0],
                ["Retryable Failed", overview.summary?.retryableFailed ?? 0]
              ].map(([label, value]) => (
                <div key={String(label)} className="rounded-md border border-[var(--border-color)] bg-[var(--bg-secondary)] p-3">
                  <p className="text-xs text-[var(--text-secondary)]">{label}</p>
                  <p className="text-xl font-semibold">{String(value)}</p>
                </div>
              ))}
            </div>
          </Section>

          <Section title="Mapped Countries">
            {(overview.countries ?? []).length ? (
              <DataTable
                headers={["Country Code", "Country Name", "Enabled", "Default", "Active"]}
                rows={(overview.countries ?? []).map((c: any) => [c.countryCode, c.countryName, c.enabled ? "Yes" : "No", c.defaultCountry ? "Yes" : "No", <StatusBadge status={c.active ? "ACTIVE" : "INACTIVE"} />])}
              />
            ) : <EmptyState text="No mapped countries" />}
          </Section>

          <Section title="Enabled Channels">
            {(overview.channels ?? []).length ? (
              <DataTable
                headers={["Channel", "Rate Limit", "Retry Count", "Enabled"]}
                rows={(overview.channels ?? []).map((c: any) => [c.channelCode, c.rateLimit ?? "-", c.retryCount ?? "-", c.enabled ? "Yes" : "No"])}
              />
            ) : <EmptyState text="No enabled channels" />}
          </Section>

          <Section title="Provider Config">
            <DataTable
              headers={["Country", "Channel", "Provider", "Provider Type", "Priority", "Sender ID", "From Email", "Status"]}
              rows={(overview.providerConfigs ?? []).map((c: any) => [c.countryName, c.channelCode, c.providerName, c.providerType ?? "-", c.priority, c.senderId ?? "-", c.fromEmail ?? "-", <StatusBadge status={c.active ? "ACTIVE" : "INACTIVE"} />])}
            />
          </Section>

          <Section title="Templates">
            <DataTable
              headers={["Template", "Channel", "Event", "Country", "Subject", "Status"]}
              rows={(overview.templates ?? []).map((t: any) => [t.templateName, t.channelCode, t.eventType, t.countryName, t.subject ?? "-", <StatusBadge status={t.active ? "ACTIVE" : "INACTIVE"} />])}
            />
          </Section>

          <Section title="Channel-wise Report">
            <DataTable
              headers={["Channel", "Sent", "Failed"]}
              rows={(overview.channelStats ?? []).map((s: any) => [s.channelCode, s.sent, s.failed])}
            />
          </Section>

          <Section title="Failed Logs">
            <DataTable
              headers={["Request ID", "Channel", "Recipient", "Provider", "Error", "Created At", "Retry", "Status"]}
              rows={pagedLogs.map((l: any) => [l.requestId, l.channel, l.recipient ?? "-", l.provider ?? "-", l.errorMessage ?? "-", l.createdAt ? new Date(l.createdAt).toLocaleString() : "-", l.retryCount ?? 0, l.status])}
            />
            {failedLogs.length > 0 ? <PaginationControls page={logPage} totalPages={logTotalPages} onPageChange={setLogPage} /> : null}
          </Section>

          <Section title="RabbitMQ Queue Status">
            <DataTable
              headers={["Queue", "Ready", "Unacked", "Consumers"]}
              rows={Object.entries(overview.queueStatus ?? {}).map(([queue, status]: any) => [queue, status.ready ?? 0, status.unacked ?? 0, status.consumers ?? 0])}
            />
          </Section>
        </div>
      ) : null}
    </div>
  );
}
