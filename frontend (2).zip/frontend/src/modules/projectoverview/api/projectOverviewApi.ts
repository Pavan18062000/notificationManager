import { apiClient } from "services/apiClient";

export const projectOverviewApi = {
  get: async (projectId: number) => (await apiClient.get(`/api/projects/${projectId}/overview`)).data
};

