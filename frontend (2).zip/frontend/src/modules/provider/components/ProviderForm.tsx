import { useState } from "react";
import { Button, Input } from "shared/components";

type ProviderPayload = { providerCode: string; providerName: string; active: boolean };

export function ProviderForm({ initialValues, submitLabel, onSubmit, onCancel, loading }: { initialValues?: ProviderPayload; submitLabel?: string; onSubmit: (v: ProviderPayload) => void; onCancel?: () => void; loading?: boolean; }) {
  const [values, setValues] = useState<ProviderPayload>(initialValues ?? { providerCode: "", providerName: "", active: true });
  return (
    <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); onSubmit(values); }}>
      <Input placeholder="Provider Code" value={values.providerCode} onChange={(e) => setValues((s) => ({ ...s, providerCode: e.target.value }))} required />
      <Input placeholder="Provider Name" value={values.providerName} onChange={(e) => setValues((s) => ({ ...s, providerName: e.target.value }))} required />
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={values.active} onChange={(e) => setValues((s) => ({ ...s, active: e.target.checked }))} /> Active</label>
      <div className="flex gap-2">
        <Button type="submit" disabled={loading}>{loading ? "Saving..." : submitLabel ?? "Save"}</Button>
        {onCancel && <Button type="button" className="bg-slate-500 hover:bg-slate-600" onClick={onCancel}>Cancel</Button>}
      </div>
    </form>
  );
}
