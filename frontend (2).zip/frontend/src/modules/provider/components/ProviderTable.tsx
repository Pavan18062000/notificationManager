import { DataTable, StatusBadge } from "shared/components";

type ProviderRow = { id: number; providerCode?: string; providerName?: string; active?: boolean };

export function ProviderTable({ rows }: { rows: ProviderRow[] }) {
  return <DataTable headers={["Id", "Code", "Name", "Status"]} rows={rows.map((r) => [r.id, r.providerCode ?? "-", r.providerName ?? "-", <StatusBadge status={r.active ? "ACTIVE" : "INACTIVE"} />])} />;
}
