import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { providerApi } from "../api/providerApi";

export function useProviderList() {
  return useQuery({ queryKey: ["provider"], queryFn: () => providerApi.list() });
}

export function useCreateProvider() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (payload: unknown) => providerApi.create(payload), onSuccess: () => qc.invalidateQueries({ queryKey: ["provider"] }) });
}

export function useUpdateProvider() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: ({ id, payload }: { id: string | number; payload: unknown }) => providerApi.update(id, payload), onSuccess: () => qc.invalidateQueries({ queryKey: ["provider"] }) });
}
