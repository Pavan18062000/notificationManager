import { apiClient } from "services/apiClient";

export const providerApi = {
  list: async () => (await apiClient.get("/api/providers")).data,
  create: async (payload: unknown) => (await apiClient.post("/api/providers", payload)).data,
  update: async (id: string | number, payload: unknown) => (await apiClient.put(`/api/providers/${id}`, payload)).data
};

