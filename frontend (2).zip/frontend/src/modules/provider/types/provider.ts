export type ProviderItem = {
  id: number;
  name: string;
  active?: boolean;
};

