export const providerConstants = {
  module: "provider"
};

