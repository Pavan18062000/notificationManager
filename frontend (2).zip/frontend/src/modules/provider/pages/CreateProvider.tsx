import { useNavigate } from "react-router-dom";
import { PageHeader } from "shared/components";
import { ProviderForm } from "../components/ProviderForm";
import { useCreateProvider } from "../hooks/useProvider";
import { useToast } from "hooks/useToast";

export default function CreateProvider() {
  const navigate = useNavigate();
  const mutation = useCreateProvider();
  const toast = useToast();
  return (
    <div>
      <PageHeader title="Create Provider" />
      <ProviderForm submitLabel="Save" loading={mutation.isPending} onCancel={() => navigate(-1)} onSubmit={(v) => mutation.mutate(v, { onSuccess: () => { toast.success("Created"); navigate(-1); }, onError: (e) => toast.error(String(e)) })} />
    </div>
  );
}
