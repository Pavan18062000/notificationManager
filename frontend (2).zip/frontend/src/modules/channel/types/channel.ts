export type ChannelItem = {
  id: number;
  name: string;
  active?: boolean;
};

