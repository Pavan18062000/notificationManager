import { DataTable, StatusBadge } from "shared/components";

type ChannelRow = { id: number; code?: string; active?: boolean };

export function ChannelTable({ rows }: { rows: ChannelRow[] }) {
  return <DataTable headers={["Id", "Code", "Status"]} rows={rows.map((r) => [r.id, r.code ?? "-", <StatusBadge status={r.active ? "ACTIVE" : "INACTIVE"} />])} />;
}
