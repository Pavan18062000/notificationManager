import { useState } from "react";
import { Button, Select } from "shared/components";

type ChannelPayload = { code: "EMAIL" | "SMS" | "PUSH" | "WHATSAPP"; active: boolean };

export function ChannelForm({ initialValues, submitLabel, onSubmit, onCancel, loading }: { initialValues?: ChannelPayload; submitLabel?: string; onSubmit: (v: ChannelPayload) => void; onCancel?: () => void; loading?: boolean; }) {
  const [values, setValues] = useState<ChannelPayload>(initialValues ?? { code: "EMAIL", active: true });
  return (
    <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); onSubmit(values); }}>
      <Select value={values.code} onChange={(e) => setValues((s) => ({ ...s, code: e.target.value as ChannelPayload["code"] }))} required>
        <option value="EMAIL">EMAIL</option>
        <option value="SMS">SMS</option>
        <option value="PUSH">PUSH</option>
        <option value="WHATSAPP">WHATSAPP</option>
      </Select>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={values.active} onChange={(e) => setValues((s) => ({ ...s, active: e.target.checked }))} /> Active</label>
      <div className="flex gap-2">
        <Button type="submit" disabled={loading}>{loading ? "Saving..." : submitLabel ?? "Save"}</Button>
        {onCancel && <Button type="button" className="bg-slate-500 hover:bg-slate-600" onClick={onCancel}>Cancel</Button>}
      </div>
    </form>
  );
}
