import { useParams } from "react-router-dom";
import { PageHeader } from "shared/components";

export default function ChannelDetails() {
  const { id } = useParams();
  return <div><PageHeader title="Channel Details" /><p className="text-sm text-slate-600">ID: {id}</p></div>;
}

