import { useState } from "react";
import { Button, DataTable, EmptyState, ListToolbar, LoadingSpinner, Modal, PageHeader, PaginationControls, StatusBadge } from "shared/components";
import { useToast } from "hooks/useToast";
import { ChannelForm } from "../components/ChannelForm";
import { useChannelList, useCreateChannel, useUpdateChannel } from "../hooks/useChannel";

export default function ChannelList() {
  const toast = useToast();
  const { data, isLoading } = useChannelList();
  const createMutation = useCreateChannel();
  const updateMutation = useUpdateChannel();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const list = data?.data ?? data ?? [];
  const filtered = list.filter((x: any) => `${String(x.code)}`.toLowerCase().includes(query.toLowerCase()));
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);

  return (
    <div>
      <PageHeader title="Channels" description="Manage communication channels" action={<Button onClick={() => { setEditing(null); setOpen(true); }}>+ Add Channel</Button>} />
      <ListToolbar query={query} onQueryChange={(v) => { setQuery(v); setPage(1); }} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(1); }} />
      {isLoading ? <LoadingSpinner /> : !filtered.length ? <EmptyState text="Data not found" hint="Click Add button to create first record." action={<Button onClick={() => { setEditing(null); setOpen(true); }}>+ Add Channel</Button>} /> : (
        <DataTable headers={["Id", "Code", "Status", "Actions"]} rows={paged.map((r: any) => [r.id, String(r.code), <StatusBadge status={r.active ? "ACTIVE" : "INACTIVE"} />, <Button className="px-2 py-1 text-xs" onClick={() => { setEditing(r); setOpen(true); }}>Edit</Button>])} />
      )}
      {!isLoading && filtered.length > 0 && <PaginationControls page={page} totalPages={totalPages} onPageChange={setPage} />}
      <Modal open={open} title={editing ? "Update Channel" : "Add Channel"}>
        <ChannelForm initialValues={editing ? { code: editing.code, active: !!editing.active } : undefined} submitLabel={editing ? "Update" : "Save"} loading={createMutation.isPending || updateMutation.isPending} onCancel={() => setOpen(false)} onSubmit={(values) => {
          const action = editing ? updateMutation.mutateAsync({ id: editing.id, payload: values }) : createMutation.mutateAsync(values);
          action.then(() => { toast.success(editing ? "Channel updated" : "Channel created"); setOpen(false); }).catch((e) => toast.error(String(e)));
        }} />
      </Modal>
    </div>
  );
}
