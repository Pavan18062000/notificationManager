import { useNavigate } from "react-router-dom";
import { PageHeader } from "shared/components";
import { ChannelForm } from "../components/ChannelForm";
import { useCreateChannel } from "../hooks/useChannel";
import { useToast } from "hooks/useToast";

export default function CreateChannel() {
  const navigate = useNavigate();
  const mutation = useCreateChannel();
  const toast = useToast();
  return (
    <div>
      <PageHeader title="Create Channel" />
      <ChannelForm submitLabel="Save" loading={mutation.isPending} onCancel={() => navigate(-1)} onSubmit={(v) => mutation.mutate(v, { onSuccess: () => { toast.success("Created"); navigate(-1); }, onError: (e) => toast.error(String(e)) })} />
    </div>
  );
}
