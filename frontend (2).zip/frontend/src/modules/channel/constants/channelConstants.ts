export const channelConstants = {
  module: "channel"
};

