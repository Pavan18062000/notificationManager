import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { channelApi } from "../api/channelApi";

export function useChannelList() {
  return useQuery({ queryKey: ["channel"], queryFn: () => channelApi.list() });
}

export function useCreateChannel() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (payload: unknown) => channelApi.create(payload), onSuccess: () => qc.invalidateQueries({ queryKey: ["channel"] }) });
}

export function useUpdateChannel() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: ({ id, payload }: { id: string | number; payload: unknown }) => channelApi.update(id, payload), onSuccess: () => qc.invalidateQueries({ queryKey: ["channel"] }) });
}
