import { apiClient } from "services/apiClient";

export const channelApi = {
  list: async () => (await apiClient.get("/api/channels")).data,
  create: async (payload: unknown) => (await apiClient.post("/api/channels", payload)).data,
  update: async (id: string | number, payload: unknown) => (await apiClient.put(`/api/channels/${id}`, payload)).data
};

