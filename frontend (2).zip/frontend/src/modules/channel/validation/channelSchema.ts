import { z } from "zod";

export const channelSchema = z.object({
  name: z.string().min(2, "Name is required"),
  active: z.boolean().optional().default(true)
});

export type ChannelForm = z.infer<typeof channelSchema>;

