import { useNavigate } from "react-router-dom";
import { PageHeader } from "shared/components";
import { CountryForm } from "../components/CountryForm";
import { useCreateCountry } from "../hooks/useCountry";
import { useToast } from "hooks/useToast";

export default function CreateCountry() {
  const navigate = useNavigate();
  const mutation = useCreateCountry();
  const toast = useToast();
  return (
    <div>
      <PageHeader title="Create Country" />
      <CountryForm submitLabel="Save" loading={mutation.isPending} onCancel={() => navigate(-1)} onSubmit={(v) => mutation.mutate(v, { onSuccess: () => { toast.success("Created"); navigate(-1); }, onError: (e) => toast.error(String(e)) })} />
    </div>
  );
}
