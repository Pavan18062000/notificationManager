import { useState } from "react";
import { Button, DataTable, EmptyState, ListToolbar, LoadingSpinner, Modal, PageHeader, PaginationControls, StatusBadge } from "shared/components";
import { useToast } from "hooks/useToast";
import { CountryForm } from "../components/CountryForm";
import { useCountryList, useCreateCountry, useUpdateCountry } from "../hooks/useCountry";

export default function CountryList() {
  const toast = useToast();
  const { data, isLoading } = useCountryList();
  const createMutation = useCreateCountry();
  const updateMutation = useUpdateCountry();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const list = data?.data ?? data ?? [];
  const filtered = list.filter((x: any) => `${x.countryCode} ${x.countryName}`.toLowerCase().includes(query.toLowerCase()));
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);

  return (
    <div>
      <PageHeader title="Countries" description="Manage country master data" action={<Button onClick={() => { setEditing(null); setOpen(true); }}>+ Add Country</Button>} />
      <ListToolbar query={query} onQueryChange={(v) => { setQuery(v); setPage(1); }} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(1); }} />
      {isLoading ? <LoadingSpinner /> : !filtered.length ? <EmptyState text="Data not found" hint="Click Add button to create first record." action={<Button onClick={() => { setEditing(null); setOpen(true); }}>+ Add Country</Button>} /> : (
        <DataTable headers={["Id", "Code", "Name", "Status", "Actions"]} rows={paged.map((r: any) => [r.id, r.countryCode, r.countryName, <StatusBadge status={r.active ? "ACTIVE" : "INACTIVE"} />, <Button className="px-2 py-1 text-xs" onClick={() => { setEditing(r); setOpen(true); }}>Edit</Button>])} />
      )}
      {!isLoading && filtered.length > 0 && <PaginationControls page={page} totalPages={totalPages} onPageChange={setPage} />}
      <Modal open={open} title={editing ? "Update Country" : "Add Country"}>
        <CountryForm initialValues={editing ? { countryCode: editing.countryCode, countryName: editing.countryName, active: !!editing.active } : undefined} submitLabel={editing ? "Update" : "Save"} loading={createMutation.isPending || updateMutation.isPending} onCancel={() => setOpen(false)} onSubmit={(values) => {
          const action = editing ? updateMutation.mutateAsync({ id: editing.id, payload: values }) : createMutation.mutateAsync(values);
          action.then(() => { toast.success(editing ? "Country updated" : "Country created"); setOpen(false); }).catch((e) => toast.error(String(e)));
        }} />
      </Modal>
    </div>
  );
}
