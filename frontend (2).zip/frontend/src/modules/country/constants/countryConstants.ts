export const countryConstants = {
  module: "country"
};

