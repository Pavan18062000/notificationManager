export type CountryItem = {
  id: number;
  name: string;
  active?: boolean;
};

