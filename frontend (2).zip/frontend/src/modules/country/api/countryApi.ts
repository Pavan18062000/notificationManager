import { apiClient } from "services/apiClient";

export const countryApi = {
  list: async () => (await apiClient.get("/api/countries")).data,
  get: async (id: string | number) => (await apiClient.get(`/api/countries/${id}`)).data,
  create: async (payload: unknown) => (await apiClient.post("/api/countries", payload)).data,
  update: async (id: string | number, payload: unknown) => (await apiClient.put(`/api/countries/${id}`, payload)).data
};

