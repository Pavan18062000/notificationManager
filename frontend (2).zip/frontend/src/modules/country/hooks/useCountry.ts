import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { countryApi } from "../api/countryApi";

export function useCountryList() {
  return useQuery({ queryKey: ["country"], queryFn: () => countryApi.list() });
}

export function useCreateCountry() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (payload: unknown) => countryApi.create(payload), onSuccess: () => qc.invalidateQueries({ queryKey: ["country"] }) });
}

export function useUpdateCountry() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: ({ id, payload }: { id: string | number; payload: unknown }) => countryApi.update(id, payload), onSuccess: () => qc.invalidateQueries({ queryKey: ["country"] }) });
}
