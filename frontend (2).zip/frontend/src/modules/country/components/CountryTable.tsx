import { DataTable, StatusBadge } from "shared/components";

type CountryRow = { id: number; countryCode?: string; countryName?: string; active?: boolean };

export function CountryTable({ rows }: { rows: CountryRow[] }) {
  return <DataTable headers={["Id", "Code", "Name", "Status"]} rows={rows.map((r) => [r.id, r.countryCode ?? "-", r.countryName ?? "-", <StatusBadge status={r.active ? "ACTIVE" : "INACTIVE"} />])} />;
}
