import { useState } from "react";
import { Button, Input } from "shared/components";

type CountryPayload = { countryCode: string; countryName: string; active: boolean };

export function CountryForm({ initialValues, submitLabel, onSubmit, onCancel, loading }: { initialValues?: CountryPayload; submitLabel?: string; onSubmit: (v: CountryPayload) => void; onCancel?: () => void; loading?: boolean; }) {
  const [values, setValues] = useState<CountryPayload>(initialValues ?? { countryCode: "", countryName: "", active: true });
  return (
    <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); onSubmit(values); }}>
      <Input placeholder="Country Code" value={values.countryCode} onChange={(e) => setValues((s) => ({ ...s, countryCode: e.target.value }))} required />
      <Input placeholder="Country Name" value={values.countryName} onChange={(e) => setValues((s) => ({ ...s, countryName: e.target.value }))} required />
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={values.active} onChange={(e) => setValues((s) => ({ ...s, active: e.target.checked }))} /> Active</label>
      <div className="flex gap-2">
        <Button type="submit" disabled={loading}>{loading ? "Saving..." : submitLabel ?? "Save"}</Button>
        {onCancel && <Button type="button" className="bg-slate-500 hover:bg-slate-600" onClick={onCancel}>Cancel</Button>}
      </div>
    </form>
  );
}
