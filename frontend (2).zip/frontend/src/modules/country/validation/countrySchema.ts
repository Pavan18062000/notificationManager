import { z } from "zod";

export const countrySchema = z.object({
  name: z.string().min(2, "Name is required"),
  active: z.boolean().optional().default(true)
});

export type CountryForm = z.infer<typeof countrySchema>;

