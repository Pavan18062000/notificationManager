export type AuthItem = {
  id: number;
  name: string;
  active?: boolean;
};

