import { z } from "zod";

export const authSchema = z.object({
  name: z.string().min(2, "Name is required"),
  active: z.boolean().optional().default(true)
});

export type AuthForm = z.infer<typeof authSchema>;

