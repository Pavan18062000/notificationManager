import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { authApi } from "../api/authApi";

export function useAuthList() {
  return useQuery({ queryKey: ["auth"], queryFn: () => authApi.list() });
}

export function useCreateAuth() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (payload: unknown) => authApi.create(payload), onSuccess: () => qc.invalidateQueries({ queryKey: ["auth"] }) });
}

