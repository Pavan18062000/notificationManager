import { type FormEvent, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button, Input } from "shared/components";
import { apiClient } from "services/apiClient";
import { setAuthSession } from "services/authStorage";
import { useToast } from "hooks/useToast";

export default function LoginPage() {
  const navigate = useNavigate();
  const toast = useToast();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      setError("Email and password are required");
      return;
    }
    setError("");
    setLoading(true);
    try {
      const res = await apiClient.post("/api/auth/login", { email, password });
      const payload = res.data?.data;
      if (!payload?.token || !payload?.user) throw new Error("Invalid login response");
      setAuthSession({ token: payload.token, user: payload.user });
      toast.success("Login successful");
      navigate("/dashboard", { replace: true });
    } catch (err: any) {
      setError(String(err));
      toast.error(String(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-[var(--bg-primary)] px-4">
      <div className="w-full max-w-md rounded-xl border border-[var(--border-color)] bg-[var(--card-bg)] p-6 shadow-lg">
        <h1 className="text-2xl font-semibold">Login</h1>
        <p className="mt-1 text-sm text-[var(--text-secondary)]">Sign in to continue</p>
        <form className="mt-5 space-y-3" onSubmit={onSubmit}>
          <Input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          <Input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          {error ? <p className="text-sm text-red-500">{error}</p> : null}
          <Button type="submit" className="w-full" disabled={loading}>{loading ? "Signing in..." : "Login"}</Button>
        </form>
      </div>
    </div>
  );
}
