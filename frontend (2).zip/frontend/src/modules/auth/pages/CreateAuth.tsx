import { useNavigate } from "react-router-dom";
import { PageHeader } from "shared/components";
import { AuthForm } from "../components/AuthForm";
import { useCreateAuth } from "../hooks/useAuth";
import { useToast } from "hooks/useToast";

export default function CreateAuth() {
  const navigate = useNavigate();
  const mutation = useCreateAuth();
  const toast = useToast();
  return (
    <div>
      <PageHeader title="Create Auth" />
      <AuthForm onSubmit={(v) => mutation.mutate(v, { onSuccess: () => { toast.success("Created" ); navigate(-1); }, onError: (e) => toast.error(String(e)) })} />
    </div>
  );
}

