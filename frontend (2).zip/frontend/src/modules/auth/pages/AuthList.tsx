import { useAuthList } from "../hooks/useAuth";
import { PageHeader, LoadingSpinner, EmptyState } from "shared/components";
import { AuthTable } from "../components/AuthTable";

export default function AuthList() {
  const { data, isLoading } = useAuthList();
  const list = data?.data ?? data ?? [];
  return (
    <div>
      <PageHeader title="Auth List" />
      {isLoading ? <LoadingSpinner /> : list.length ? <AuthTable rows={list} /> : <EmptyState text="No data" />}
    </div>
  );
}

