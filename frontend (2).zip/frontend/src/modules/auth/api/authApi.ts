import { apiClient } from "services/apiClient";

const base = "/api/auth";

export const authApi = {
  login: async (payload: { email: string; password: string }) => (await apiClient.post(`${base}/login`, payload)).data,
  me: async () => (await apiClient.get(`${base}/me`)).data,
  logout: async () => (await apiClient.post(`${base}/logout`)).data
};


