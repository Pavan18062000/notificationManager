export const authConstants = {
  module: "auth"
};

