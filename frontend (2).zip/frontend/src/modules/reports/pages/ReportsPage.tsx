import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button, DataTable, EmptyState, Input, LoadingSpinner, PageHeader, Select, StatusBadge } from "shared/components";
import { reportsApi, type ReportFilters } from "../api/reportsApi";
import { useToast } from "hooks/useToast";

type Option = { id: number; label: string };

const today = new Date().toISOString().slice(0, 10);

function Card({ title, value }: { title: string; value: string | number }) {
  return <div className="rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-4"><p className="text-xs text-[var(--text-secondary)]">{title}</p><p className="mt-1 text-2xl font-semibold">{value}</p></div>;
}

function ChartCard({ title, items, valueKey = "count" }: { title: string; items: any[]; valueKey?: string }) {
  const max = Math.max(1, ...items.map((i) => Number(i[valueKey] ?? i.cnt ?? i.total ?? 0)));
  return (
    <div className="rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-4">
      <h3 className="mb-3 font-semibold">{title}</h3>
      {!items.length ? <p className="text-sm text-[var(--text-secondary)]">No data</p> :
        <div className="space-y-2">{items.slice(0, 8).map((it, i) => {
          const label = it.date ?? it.status ?? it.channel ?? it.providerCode ?? it.provider ?? it.projectCode ?? it.eventCode ?? `Item ${i + 1}`;
          const value = Number(it[valueKey] ?? it.cnt ?? it.total ?? 0);
          return <div key={`${label}-${i}`}><div className="mb-1 flex justify-between text-xs"><span>{label}</span><span>{value}</span></div><div className="h-2 rounded bg-[var(--bg-secondary)]"><div className="h-2 rounded bg-brand-500" style={{ width: `${(value / max) * 100}%` }} /></div></div>;
        })}</div>}
    </div>
  );
}

export default function ReportsPage() {
  const toast = useToast();
  const [filters, setFilters] = useState<ReportFilters>({ fromDate: today, toDate: today, page: 0, size: 20, sortBy: "createdAt", sortDirection: "DESC" });
  const [applied, setApplied] = useState<ReportFilters>(filters);
  const [selectedRequestId, setSelectedRequestId] = useState<string | null>(null);

  const pick = (obj: any, ...keys: string[]) => {
    for (const key of keys) {
      if (obj && obj[key] != null) return obj[key];
      const upper = key.toUpperCase();
      if (obj && obj[upper] != null) return obj[upper];
    }
    return undefined;
  };

  const lookups = useQuery({
    queryKey: ["report-lookups"],
    queryFn: async () => {
      const all = await reportsApi.filterAll();
      return all?.data ?? {};
    }
  });

  const countriesLookup = useQuery({
    queryKey: ["report-countries", filters.projectId ?? null],
    queryFn: async () => {
      const res = await reportsApi.filterCountries(filters.projectId);
      return res?.data ?? [];
    }
  });

  const summaryQ = useQuery({ queryKey: ["report-summary", applied], queryFn: () => reportsApi.summary(applied) });
  const trendQ = useQuery({ queryKey: ["report-trend", applied], queryFn: () => reportsApi.trend(applied) });
  const statusQ = useQuery({ queryKey: ["report-status", applied], queryFn: () => reportsApi.status(applied) });
  const channelQ = useQuery({ queryKey: ["report-channel", applied], queryFn: () => reportsApi.channel(applied) });
  const providerQ = useQuery({ queryKey: ["report-provider", applied], queryFn: () => reportsApi.provider(applied) });
  const projectQ = useQuery({ queryKey: ["report-project", applied], queryFn: () => reportsApi.project(applied) });
  const eventQ = useQuery({ queryKey: ["report-event", applied], queryFn: () => reportsApi.event(applied) });
  const detailsQ = useQuery({ queryKey: ["report-details", applied], queryFn: () => reportsApi.details(applied) });
  const detailByIdQ = useQuery({ queryKey: ["report-detail-by-id", selectedRequestId], enabled: !!selectedRequestId, queryFn: () => reportsApi.detailsByRequestId(selectedRequestId!) });

  const summary = summaryQ.data?.data ?? {};
  const details = detailsQ.data?.data?.items ?? [];
  const totalPages = detailsQ.data?.data?.totalPages ?? 0;
  const page = (applied.page ?? 0) + 1;

  const projectOptions: Option[] = useMemo(() => (lookups.data?.projects ?? []).map((x: any) => ({ id: Number(pick(x, "id")), label: `${pick(x, "project_code", "projectCode")} - ${pick(x, "project_name", "projectName")}` })), [lookups.data]);
  const countryOptions: Option[] = useMemo(() => (countriesLookup.data ?? []).map((x: any) => ({ id: Number(pick(x, "id")), label: `${pick(x, "country_code", "countryCode")} - ${pick(x, "country_name", "countryName")}` })), [countriesLookup.data]);
  const channelOptions: Option[] = useMemo(() => (lookups.data?.channels ?? []).map((x: any) => ({ id: Number(pick(x, "id")), label: String(pick(x, "code")) })), [lookups.data]);
  const providerOptions: Option[] = useMemo(() => (lookups.data?.providers ?? []).map((x: any) => ({ id: Number(pick(x, "id")), label: `${pick(x, "provider_code", "providerCode")} - ${pick(x, "provider_name", "providerName")}` })), [lookups.data]);
  const eventOptions: Option[] = useMemo(() => (lookups.data?.eventTypes ?? []).map((x: any) => ({ id: Number(pick(x, "id")), label: `${pick(x, "event_code", "eventCode")} - ${pick(x, "event_name", "eventName")}` })), [lookups.data]);

  const isLoading = summaryQ.isLoading || detailsQ.isLoading || lookups.isLoading || countriesLookup.isLoading;

  const applyFilters = () => setApplied({ ...filters, page: 0 });
  const resetFilters = () => {
    const next = { fromDate: today, toDate: today, page: 0, size: 20, sortBy: "createdAt", sortDirection: "DESC" } as ReportFilters;
    setFilters(next);
    setApplied(next);
  };

  const exportExcel = async () => {
    try {
      const res = await reportsApi.exportExcel(applied);
      const blob = new Blob([res.data], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      const contentDisposition = res.headers["content-disposition"] as string | undefined;
      const fileName = contentDisposition?.match(/filename="(.+)"/)?.[1] ?? `notification-report-${Date.now()}.xlsx`;
      a.href = url;
      a.download = fileName;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("Excel exported successfully");
    } catch (e: any) {
      toast.error(String(e?.message ?? "Failed to export report"));
    }
  };

  return (
    <div className="space-y-4">
      <PageHeader
        title="Notification Reports"
        description="Monitor delivery, failures, retries, provider performance, and project usage."
        action={<div className="flex gap-2"><Button className="bg-slate-600 hover:bg-slate-700" onClick={() => summaryQ.refetch()}>Refresh</Button><Button onClick={exportExcel}>Export Excel</Button></div>}
      />

      <div className="rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-4">
        <h3 className="mb-3 font-semibold">Report Filters</h3>
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-4">
          <Input type="date" value={filters.fromDate ?? ""} onChange={(e) => setFilters((s) => ({ ...s, fromDate: e.target.value }))} />
          <Input type="date" value={filters.toDate ?? ""} onChange={(e) => setFilters((s) => ({ ...s, toDate: e.target.value }))} />
          <Select value={filters.projectId ?? ""} onChange={(e) => setFilters((s) => ({ ...s, projectId: e.target.value ? Number(e.target.value) : undefined, countryId: undefined }))}><option value="">All Projects</option>{projectOptions.map((x) => <option key={x.id} value={x.id}>{x.label}</option>)}</Select>
          <Select value={filters.countryId ?? ""} onChange={(e) => setFilters((s) => ({ ...s, countryId: e.target.value ? Number(e.target.value) : undefined }))}><option value="">{filters.projectId ? "All Project Countries" : "All Countries"}</option>{countryOptions.map((x) => <option key={x.id} value={x.id}>{x.label}</option>)}</Select>
          <Select value={filters.channelId ?? ""} onChange={(e) => setFilters((s) => ({ ...s, channelId: e.target.value ? Number(e.target.value) : undefined }))}><option value="">All Channels</option>{channelOptions.map((x) => <option key={x.id} value={x.id}>{x.label}</option>)}</Select>
          <Select value={filters.eventTypeId ?? ""} onChange={(e) => setFilters((s) => ({ ...s, eventTypeId: e.target.value ? Number(e.target.value) : undefined }))}><option value="">All Events</option>{eventOptions.map((x) => <option key={x.id} value={x.id}>{x.label}</option>)}</Select>
          <Select value={filters.providerId ?? ""} onChange={(e) => setFilters((s) => ({ ...s, providerId: e.target.value ? Number(e.target.value) : undefined }))}><option value="">All Providers</option>{providerOptions.map((x) => <option key={x.id} value={x.id}>{x.label}</option>)}</Select>
          <Select value={filters.status ?? ""} onChange={(e) => setFilters((s) => ({ ...s, status: e.target.value || undefined }))}><option value="">All Status</option>{["QUEUED", "PROCESSING", "SENT", "FAILED", "ACCEPTED"].map((s) => <option key={s} value={s}>{s}</option>)}</Select>
          <Input placeholder="Recipient / Request ID" value={filters.recipient ?? ""} onChange={(e) => setFilters((s) => ({ ...s, recipient: e.target.value, requestId: e.target.value }))} />
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          <Button onClick={applyFilters}>Apply Filters</Button>
          <Button className="bg-slate-600 hover:bg-slate-700" onClick={resetFilters}>Reset</Button>
          <Button className="bg-emerald-700 hover:bg-emerald-800" onClick={exportExcel}>Export Excel</Button>
        </div>
      </div>

      {isLoading ? <LoadingSpinner /> : (
        <>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-8">
            <Card title="Total Requests" value={summary.totalRequests ?? 0} />
            <Card title="Queued" value={summary.queued ?? 0} />
            <Card title="Processing" value={summary.processing ?? 0} />
            <Card title="Sent" value={summary.sent ?? 0} />
            <Card title="Failed" value={summary.failed ?? 0} />
            <Card title="Success Rate %" value={`${Number(summary.successRate ?? 0).toFixed(2)}%`} />
            <Card title="Avg Latency" value={`${Number(summary.avgLatencyMs ?? 0).toFixed(0)} ms`} />
            <Card title="Retry Attempts" value={summary.retryAttempts ?? 0} />
          </div>

          <div>
            <h2 className="mb-3 text-lg font-semibold">Performance Overview</h2>
            <div className="grid gap-3 md:grid-cols-2">
              <ChartCard title="Daily Delivery Trend" items={trendQ.data?.data ?? []} valueKey="total" />
              <ChartCard title="Status Distribution" items={statusQ.data?.data ?? []} />
              <ChartCard title="Channel Summary" items={channelQ.data?.data ?? []} />
              <ChartCard title="Provider Performance" items={providerQ.data?.data ?? []} valueKey="count" />
              <ChartCard title="Project-wise Volume" items={projectQ.data?.data ?? []} valueKey="count" />
              <ChartCard title="Event-wise Volume" items={eventQ.data?.data ?? []} valueKey="count" />
            </div>
          </div>

          <div>
            <h2 className="mb-3 text-lg font-semibold">Detailed Delivery Logs</h2>
            {!details.length ? <EmptyState text="No reports found for selected filters." /> :
              <DataTable
                headers={["Request ID", "Project", "Country", "Event", "Channel", "Provider", "Recipient", "Status", "Attempt No", "Retry", "HTTP", "Provider Message ID", "Latency", "Created At", "Sent At", "Failed At", "Action"]}
                rows={details.map((r: any) => [
                  r.requestId,
                  `${r.projectCode ?? ""} ${r.projectName ?? ""}`,
                  `${r.countryCode ?? ""} ${r.countryName ?? ""}`,
                  `${r.eventCode ?? ""} ${r.eventName ?? ""}`,
                  r.channel,
                  r.provider,
                  r.recipient,
                  <StatusBadge status={r.status || "-"} />, 
                  r.attemptNo,
                  r.retryCount,
                  r.httpStatus ?? "-",
                  r.providerMessageId ?? "-",
                  r.latencyMs ? `${r.latencyMs} ms` : "-",
                  r.createdAt ?? "-",
                  r.sentAt ?? "-",
                  r.failedAt ?? "-",
                  <Button className="px-2 py-1 text-xs" onClick={() => setSelectedRequestId(r.requestId)}>View Details</Button>
                ])}
              />}
            <div className="mt-3 flex items-center justify-between">
              <p className="text-sm text-[var(--text-secondary)]">Page {page} of {Math.max(1, totalPages)}</p>
              <div className="flex gap-2">
                <Button className="bg-slate-600 hover:bg-slate-700" disabled={(applied.page ?? 0) <= 0} onClick={() => setApplied((s) => ({ ...s, page: Math.max(0, (s.page ?? 0) - 1) }))}>Prev</Button>
                <Button className="bg-slate-600 hover:bg-slate-700" disabled={(applied.page ?? 0) + 1 >= totalPages} onClick={() => setApplied((s) => ({ ...s, page: (s.page ?? 0) + 1 }))}>Next</Button>
              </div>
            </div>
          </div>
        </>
      )}

      {selectedRequestId ? (
        <div className="fixed inset-y-0 right-0 z-50 w-full max-w-2xl overflow-y-auto border-l border-[var(--border-color)] bg-[var(--card-bg)] p-4 shadow-2xl">
          <div className="mb-3 flex items-center justify-between"><h3 className="text-lg font-semibold">Request Details</h3><Button className="bg-slate-600 hover:bg-slate-700" onClick={() => setSelectedRequestId(null)}>Close</Button></div>
          {detailByIdQ.isLoading ? <LoadingSpinner /> : (
            <div className="space-y-4 text-sm">
              <section><h4 className="mb-2 font-semibold">Request Details</h4><pre className="overflow-auto rounded border border-[var(--border-color)] p-3">{JSON.stringify(detailByIdQ.data?.data ?? {}, null, 2)}</pre></section>
              <section><h4 className="mb-2 font-semibold">Delivery Attempts</h4><pre className="overflow-auto rounded border border-[var(--border-color)] p-3">{JSON.stringify(detailByIdQ.data?.data?.attempts ?? [], null, 2)}</pre></section>
              <section><h4 className="mb-2 font-semibold">Provider Response</h4><pre className="overflow-auto rounded border border-[var(--border-color)] p-3">{JSON.stringify({ providerMessageId: detailByIdQ.data?.data?.providerMessageId, httpStatus: detailByIdQ.data?.data?.httpStatus, providerResponse: detailByIdQ.data?.data?.providerResponse }, null, 2)}</pre></section>
              <section><h4 className="mb-2 font-semibold">Error Details</h4><pre className="overflow-auto rounded border border-[var(--border-color)] p-3">{JSON.stringify({ errorMessage: detailByIdQ.data?.data?.errorMessage, failedAt: detailByIdQ.data?.data?.failedAt }, null, 2)}</pre></section>
            </div>
          )}
        </div>
      ) : null}
    </div>
  );
}
