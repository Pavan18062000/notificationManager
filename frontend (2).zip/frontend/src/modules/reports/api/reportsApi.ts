import { apiClient } from "services/apiClient";

export type ReportFilters = {
  fromDate?: string;
  toDate?: string;
  projectId?: number;
  countryId?: number;
  channelId?: number;
  eventTypeId?: number;
  providerId?: number;
  status?: string;
  recipient?: string;
  requestId?: string;
  page?: number;
  size?: number;
  sortBy?: string;
  sortDirection?: "ASC" | "DESC";
};

const q = (filters: ReportFilters) => ({ params: filters });

export const reportsApi = {
  summary: async (filters: ReportFilters) => (await apiClient.get("/api/v1/reports/notification-summary", q(filters))).data,
  trend: async (filters: ReportFilters) => (await apiClient.get("/api/v1/reports/notification-trend", q(filters))).data,
  status: async (filters: ReportFilters) => (await apiClient.get("/api/v1/reports/status-distribution", q(filters))).data,
  channel: async (filters: ReportFilters) => (await apiClient.get("/api/v1/reports/channel-summary", q(filters))).data,
  provider: async (filters: ReportFilters) => (await apiClient.get("/api/v1/reports/provider-summary", q(filters))).data,
  project: async (filters: ReportFilters) => (await apiClient.get("/api/v1/reports/project-summary", q(filters))).data,
  event: async (filters: ReportFilters) => (await apiClient.get("/api/v1/reports/event-summary", q(filters))).data,
  details: async (filters: ReportFilters) => (await apiClient.get("/api/v1/reports/notification-details", q(filters))).data,
  detailsByRequestId: async (requestId: string) => (await apiClient.get(`/api/v1/reports/notification-details/${requestId}`)).data,
  filterAll: async (projectId?: number) => (await apiClient.get("/api/v1/reports/filters", { params: { projectId } })).data,
  filterCountries: async (projectId?: number) => (await apiClient.get("/api/v1/reports/filters/countries", { params: { projectId } })).data,
  exportExcel: async (filters: ReportFilters) =>
    await apiClient.get("/api/v1/reports/export/excel", { params: filters, responseType: "blob" }),
};
