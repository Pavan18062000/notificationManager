import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { notificationRouteApi } from "../api/notificationRouteApi";

export function useNotificationRouteList() {
  return useQuery({ queryKey: ["notification-routes"], queryFn: () => notificationRouteApi.list() });
}

export function useCreateNotificationRoute() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (payload: unknown) => notificationRouteApi.create(payload),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["notification-routes"] })
  });
}

export function useUpdateNotificationRoute() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, payload }: { id: string | number; payload: unknown }) => notificationRouteApi.update(id, payload),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["notification-routes"] })
  });
}
