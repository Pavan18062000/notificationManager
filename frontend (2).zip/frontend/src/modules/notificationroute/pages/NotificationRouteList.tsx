import { useMemo, useState } from "react";
import { Button, DataTable, EmptyState, LoadingSpinner, Modal, PageHeader, Select, Input } from "shared/components";
import { useNotificationRouteList, useCreateNotificationRoute, useUpdateNotificationRoute } from "../hooks/useNotificationRoute";
import { useProjectList } from "modules/project/hooks/useProject";
import { useCountryList } from "modules/country/hooks/useCountry";
import { useChannelList } from "modules/channel/hooks/useChannel";
import { useEventtypeList } from "modules/eventtype/hooks/useEventtype";
import { useProviderList } from "modules/provider/hooks/useProvider";
import { useToast } from "hooks/useToast";
import { buildOptionLabel } from "utils/optionLabel";

export default function NotificationRouteList() {
  const toast = useToast();
  const { data, isLoading } = useNotificationRouteList();
  const createMutation = useCreateNotificationRoute();
  const updateMutation = useUpdateNotificationRoute();
  const { data: projectData } = useProjectList();
  const { data: countryData } = useCountryList();
  const { data: channelData } = useChannelList();
  const { data: eventData } = useEventtypeList();
  const { data: providerData } = useProviderList();
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<"create" | "edit" | "view">("create");
  const [selectedRouteId, setSelectedRouteId] = useState<number | null>(null);
  const list = data?.data ?? data ?? [];
  const projects = useMemo(() => (projectData?.data ?? projectData ?? []).map((x: any) => ({ id: x.id, label: buildOptionLabel([x.projectCode, x.projectName], `Project #${x.id}`) })), [projectData]);
  const countries = useMemo(() => (countryData?.data ?? countryData ?? []).map((x: any) => ({ id: x.id, label: buildOptionLabel([x.countryCode, x.countryName], `Country #${x.id}`) })), [countryData]);
  const channels = useMemo(() => (channelData?.data ?? channelData ?? []).map((x: any) => ({ id: x.id, label: buildOptionLabel([x.code], `Channel #${x.id}`) })), [channelData]);
  const events = useMemo(() => (eventData?.data ?? eventData ?? []).map((x: any) => ({ id: x.id, label: buildOptionLabel([x.eventCode, x.eventName], `Event #${x.id}`) })), [eventData]);
  const providers = useMemo(() => (providerData?.data ?? providerData ?? []).map((x: any) => ({ id: x.id, label: buildOptionLabel([x.providerCode, x.providerName], `Provider #${x.id}`) })), [providerData]);
  const label = (arr: {id:number;label:string}[], id: any, fallback: string) => arr.find((x) => x.id === id)?.label ?? fallback;
  const [form, setForm] = useState<any>({ projectId: "", countryId: "", channelId: "", eventTypeId: "", providerId: "", priority: 1, enabled: true, rateLimitPerMinute: "", maxRetries: "", fromEmail: "", senderId: "", providerApiKey: "", providerAccountKey: "default" });
  const missingFields = [
    !form.projectId ? "Project" : null,
    !form.channelId ? "Channel" : null,
    !form.providerId ? "Provider" : null
  ].filter(Boolean) as string[];
  const requiredMissing = missingFields.length > 0;
  const readOnly = mode === "view";
  const resetForm = () => setForm({ projectId: "", countryId: "", channelId: "", eventTypeId: "", providerId: "", priority: 1, enabled: true, rateLimitPerMinute: "", maxRetries: "", fromEmail: "", senderId: "", providerApiKey: "", providerAccountKey: "default" });

  const openCreate = () => {
    setMode("create");
    setSelectedRouteId(null);
    resetForm();
    setOpen(true);
  };

  const openView = (route: any) => {
    setMode("view");
    setSelectedRouteId(route.id);
    setForm({
      projectId: String(route.projectId ?? ""),
      countryId: route.countryId ? String(route.countryId) : "",
      channelId: String(route.channelId ?? ""),
      eventTypeId: route.eventTypeId ? String(route.eventTypeId) : "",
      providerId: String(route.providerId ?? ""),
      priority: route.priority ?? 1,
      enabled: !!route.enabled,
      rateLimitPerMinute: route.rateLimitPerMinute ?? "",
      maxRetries: route.maxRetries ?? "",
      fromEmail: route.fromEmail ?? "",
      senderId: route.senderId ?? "",
      providerApiKey: "",
      providerAccountKey: route.providerAccountKey ?? "default"
    });
    setOpen(true);
  };

  const openEdit = (route: any) => {
    setMode("edit");
    setSelectedRouteId(route.id);
    setForm({
      projectId: String(route.projectId ?? ""),
      countryId: route.countryId ? String(route.countryId) : "",
      channelId: String(route.channelId ?? ""),
      eventTypeId: route.eventTypeId ? String(route.eventTypeId) : "",
      providerId: String(route.providerId ?? ""),
      priority: route.priority ?? 1,
      enabled: !!route.enabled,
      rateLimitPerMinute: route.rateLimitPerMinute ?? "",
      maxRetries: route.maxRetries ?? "",
      fromEmail: route.fromEmail ?? "",
      senderId: route.senderId ?? "",
      providerApiKey: "",
      providerAccountKey: route.providerAccountKey ?? "default"
    });
    setOpen(true);
  };

  return (
    <div>
      <PageHeader title="Notification Routes" description="Unified routing for project/country/channel/event/provider." action={<Button onClick={openCreate}>+ Add Route</Button>} />
      {isLoading ? <LoadingSpinner /> : !list.length ? <EmptyState text="No routes found" /> : (
        <DataTable headers={["Id", "Project", "Country", "Channel", "Event", "Provider", "Priority", "Enabled", "Actions"]} rows={list.map((r: any) => [
          r.id,
          label(projects, r.projectId, `Project #${r.projectId}`),
          r.countryId ? label(countries, r.countryId, `Country #${r.countryId}`) : "GLOBAL",
          label(channels, r.channelId, `Channel #${r.channelId}`),
          r.eventTypeId ? label(events, r.eventTypeId, `Event #${r.eventTypeId}`) : "ANY",
          label(providers, r.providerId, `Provider #${r.providerId}`),
          r.priority,
          r.enabled ? "Yes" : "No",
          <div className="flex gap-2">
            <Button className="px-2 py-1 text-xs bg-slate-600 hover:bg-slate-700" onClick={() => openView(r)}>View</Button>
            <Button className="px-2 py-1 text-xs" onClick={() => openEdit(r)}>Edit</Button>
          </div>
        ])} />
      )}

      <Modal open={open} title={mode === "create" ? "Add Notification Route" : mode === "edit" ? "Edit Notification Route" : "View Notification Route"}>
        <form className="space-y-2" onSubmit={(e) => {
          e.preventDefault();
          if (readOnly) {
            setOpen(false);
            return;
          }
          if (requiredMissing) {
            toast.error(`Please select required fields: ${missingFields.join(", ")}`);
            return;
          }
          const payload = {
            ...form,
            projectId: Number(form.projectId),
            countryId: form.countryId ? Number(form.countryId) : null,
            channelId: Number(form.channelId),
            eventTypeId: form.eventTypeId ? Number(form.eventTypeId) : null,
            providerId: Number(form.providerId),
            priority: Number(form.priority),
            rateLimitPerMinute: form.rateLimitPerMinute ? Number(form.rateLimitPerMinute) : null,
            maxRetries: form.maxRetries ? Number(form.maxRetries) : null
          };

          const action = mode === "edit" && selectedRouteId
            ? updateMutation.mutateAsync({ id: selectedRouteId, payload })
            : createMutation.mutateAsync(payload);

          action.then(() => {
            toast.success(mode === "edit" ? "Route updated" : "Route created");
            setOpen(false);
          }).catch((err: any) => {
            toast.error(String(err?.response?.data?.message ?? err?.message ?? "Failed to save route"));
          });
        }}>
          <Select disabled={readOnly} value={form.projectId} onChange={(e) => setForm((s: any) => ({ ...s, projectId: e.target.value }))}><option value="">Select project *</option>{projects.map((x) => <option key={x.id} value={x.id}>{x.label}</option>)}</Select>
          <Select disabled={readOnly} value={form.countryId} onChange={(e) => setForm((s: any) => ({ ...s, countryId: e.target.value }))}><option value="">GLOBAL (all countries)</option>{countries.map((x) => <option key={x.id} value={x.id}>{x.label}</option>)}</Select>
          <Select disabled={readOnly} value={form.channelId} onChange={(e) => setForm((s: any) => ({ ...s, channelId: e.target.value }))}><option value="">Select channel *</option>{channels.map((x) => <option key={x.id} value={x.id}>{x.label}</option>)}</Select>
          <Select disabled={readOnly} value={form.eventTypeId} onChange={(e) => setForm((s: any) => ({ ...s, eventTypeId: e.target.value }))}><option value="">ANY event</option>{events.map((x) => <option key={x.id} value={x.id}>{x.label}</option>)}</Select>
          <Select disabled={readOnly} value={form.providerId} onChange={(e) => setForm((s: any) => ({ ...s, providerId: e.target.value }))}><option value="">Select provider *</option>{providers.map((x) => <option key={x.id} value={x.id}>{x.label}</option>)}</Select>
          <Input disabled={readOnly} type="number" placeholder="Priority" value={form.priority} onChange={(e) => setForm((s: any) => ({ ...s, priority: e.target.value }))} />
          <Input disabled={readOnly} type="number" placeholder="Rate limit per minute" value={form.rateLimitPerMinute} onChange={(e) => setForm((s: any) => ({ ...s, rateLimitPerMinute: e.target.value }))} />
          <Input disabled={readOnly} type="number" placeholder="Max retries" value={form.maxRetries} onChange={(e) => setForm((s: any) => ({ ...s, maxRetries: e.target.value }))} />
          <Input disabled={readOnly} placeholder="From Email (EMAIL)" value={form.fromEmail} onChange={(e) => setForm((s: any) => ({ ...s, fromEmail: e.target.value }))} />
          <Input disabled={readOnly} placeholder="Sender ID (SMS)" value={form.senderId} onChange={(e) => setForm((s: any) => ({ ...s, senderId: e.target.value }))} />
          <Input disabled={readOnly} placeholder="Provider API Key" value={form.providerApiKey} onChange={(e) => setForm((s: any) => ({ ...s, providerApiKey: e.target.value }))} />
          <Input disabled={readOnly} placeholder="Provider Account Key (default)" value={form.providerAccountKey} onChange={(e) => setForm((s: any) => ({ ...s, providerAccountKey: e.target.value }))} />
          <label className="flex items-center gap-2 text-sm"><input disabled={readOnly} type="checkbox" checked={!!form.enabled} onChange={(e) => setForm((s: any) => ({ ...s, enabled: e.target.checked }))} /> Enabled</label>
          {!readOnly && requiredMissing ? (
            <p className="text-xs text-amber-500">Required: {missingFields.join(", ")}</p>
          ) : null}
          <div className="flex gap-2">
            {!readOnly ? (
              <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending || requiredMissing}>
                {createMutation.isPending || updateMutation.isPending ? "Saving..." : "Save"}
              </Button>
            ) : null}
            <Button type="button" className="bg-slate-500 hover:bg-slate-600" onClick={() => setOpen(false)}>
              {readOnly ? "Close" : "Cancel"}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
