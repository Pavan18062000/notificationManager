import { apiClient } from "services/apiClient";

export const notificationRouteApi = {
  list: async () => (await apiClient.get("/api/notification-routes")).data,
  create: async (payload: unknown) => (await apiClient.post("/api/notification-routes", payload)).data,
  update: async (id: string | number, payload: unknown) => (await apiClient.put(`/api/notification-routes/${id}`, payload)).data
};
