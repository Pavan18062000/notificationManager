export type TemplateItem = {
  id: number;
  name: string;
  active?: boolean;
};

