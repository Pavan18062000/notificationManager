import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { templateApi } from "../api/templateApi";

export function useTemplateList() {
  return useQuery({ queryKey: ["template"], queryFn: () => templateApi.list() });
}

export function useCreateTemplate() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (payload: unknown) => templateApi.create(payload), onSuccess: () => qc.invalidateQueries({ queryKey: ["template"] }) });
}

export function useUpdateTemplate() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: ({ id, payload }: { id: string | number; payload: unknown }) => templateApi.update(id, payload), onSuccess: () => qc.invalidateQueries({ queryKey: ["template"] }) });
}
