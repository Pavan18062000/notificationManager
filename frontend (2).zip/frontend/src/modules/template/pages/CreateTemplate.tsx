import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { PageHeader } from "shared/components";
import { TemplateForm } from "../components/TemplateForm";
import { useCreateTemplate } from "../hooks/useTemplate";
import { useProjectList } from "modules/project/hooks/useProject";
import { useCountryList } from "modules/country/hooks/useCountry";
import { useChannelList } from "modules/channel/hooks/useChannel";
import { useEventtypeList } from "modules/eventtype/hooks/useEventtype";
import { useToast } from "hooks/useToast";

export default function CreateTemplate() {
  const navigate = useNavigate();
  const mutation = useCreateTemplate();
  const toast = useToast();
  const { data: projectData } = useProjectList();
  const { data: countryData } = useCountryList();
  const { data: channelData } = useChannelList();
  const { data: eventTypeData } = useEventtypeList();

  const projects = useMemo(() => (projectData?.data ?? projectData ?? []).map((x: any) => ({ id: x.id, label: `${x.projectCode} - ${x.projectName}` })), [projectData]);
  const countries = useMemo(() => (countryData?.data ?? countryData ?? []).map((x: any) => ({ id: x.id, label: `${x.countryCode} - ${x.countryName}` })), [countryData]);
  const channels = useMemo(() => (channelData?.data ?? channelData ?? []).map((x: any) => ({ id: x.id, label: String(x.code) })), [channelData]);
  const eventTypes = useMemo(() => (eventTypeData?.data ?? eventTypeData ?? []).map((x: any) => ({ id: x.id, label: `${x.eventCode} - ${x.eventName}` })), [eventTypeData]);

  return (
    <div>
      <PageHeader title="Create Template" />
      <TemplateForm projects={projects} countries={countries} channels={channels} eventTypes={eventTypes} submitLabel="Save" loading={mutation.isPending} onCancel={() => navigate(-1)} onSubmit={(v) => mutation.mutate(v, { onSuccess: () => { toast.success("Created"); navigate(-1); }, onError: (e) => toast.error(String(e)) })} />
    </div>
  );
}
