import { useMemo, useState } from "react";
import { Button, DataTable, EmptyState, ListToolbar, LoadingSpinner, Modal, PageHeader, PaginationControls, StatusBadge } from "shared/components";
import { useToast } from "hooks/useToast";
import { TemplateForm } from "../components/TemplateForm";
import { useCreateTemplate, useTemplateList, useUpdateTemplate } from "../hooks/useTemplate";
import { useProjectList } from "modules/project/hooks/useProject";
import { useCountryList } from "modules/country/hooks/useCountry";
import { useChannelList } from "modules/channel/hooks/useChannel";
import { useEventtypeList } from "modules/eventtype/hooks/useEventtype";
import { buildOptionLabel } from "utils/optionLabel";

export default function TemplateList() {
  const toast = useToast();
  const { data, isLoading } = useTemplateList();
  const { data: projectData } = useProjectList();
  const { data: countryData } = useCountryList();
  const { data: channelData } = useChannelList();
  const { data: eventTypeData } = useEventtypeList();
  const createMutation = useCreateTemplate();
  const updateMutation = useUpdateTemplate();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const list = data?.data ?? data ?? [];
  const filtered = list.filter((x: any) => `${x.templateName} ${x.language ?? ""} ${x.subject ?? ""}`.toLowerCase().includes(query.toLowerCase()));
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);
  const projects = useMemo(() => (projectData?.data ?? projectData ?? []).map((x: any) => ({ id: x.id, label: buildOptionLabel([x.projectCode, x.projectName], `Project #${x.id}`) })), [projectData]);
  const countries = useMemo(() => (countryData?.data ?? countryData ?? []).map((x: any) => ({ id: x.id, label: buildOptionLabel([x.countryCode, x.countryName], `Country #${x.id}`) })), [countryData]);
  const channels = useMemo(() => (channelData?.data ?? channelData ?? []).map((x: any) => ({ id: x.id, label: buildOptionLabel([x.code], `Channel #${x.id}`) })), [channelData]);
  const eventTypes = useMemo(() => (eventTypeData?.data ?? eventTypeData ?? []).map((x: any) => ({ id: x.id, label: buildOptionLabel([x.eventCode, x.eventName], `Event Type #${x.id}`) })), [eventTypeData]);
  const labelById = (items: Array<{ id: number; label: string }>, id: number | null | undefined, fallback: string) =>
    id == null ? fallback : items.find((x) => x.id === id)?.label ?? fallback;

  return (
    <div>
      <PageHeader
        title="Templates"
        description="Manage communication templates"
        action={<Button onClick={() => { setEditing(null); setOpen(true); }}>+ Add Template</Button>}
      />
      <ListToolbar query={query} onQueryChange={(v) => { setQuery(v); setPage(1); }} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(1); }} />
      {isLoading ? <LoadingSpinner /> : !filtered.length ? <EmptyState text="Data not found" hint="Click Add button to create first record." action={<Button onClick={() => { setEditing(null); setOpen(true); }}>+ Add Template</Button>} /> : (
        <DataTable
          headers={["Id", "Template", "Project", "Country", "Channel", "Event", "Status", "Actions"]}
          rows={paged.map((r: any) => [
            r.id,
            r.templateName,
            labelById(projects, r.projectId, `Project #${r.projectId}`),
            labelById(countries, r.countryId, `Country #${r.countryId}`),
            labelById(channels, r.channelId, `Channel #${r.channelId}`),
            labelById(eventTypes, r.eventTypeId, `Event #${r.eventTypeId}`),
            <StatusBadge status={r.active ? "ACTIVE" : "INACTIVE"} />,
            <Button className="px-2 py-1 text-xs" onClick={() => { setEditing(r); setOpen(true); }}>Edit</Button>
          ])}
        />
      )}
      {!isLoading && filtered.length > 0 && <PaginationControls page={page} totalPages={totalPages} onPageChange={setPage} />}

      <Modal open={open} title={editing ? "Update Template" : "Add Template"}>
        <TemplateForm
          projects={projects}
          countries={countries}
          channels={channels}
          eventTypes={eventTypes}
          initialValues={editing ? {
            projectId: editing.projectId,
            countryId: editing.countryId,
            channelId: editing.channelId,
            eventTypeId: editing.eventTypeId,
            templateName: editing.templateName,
            language: editing.language,
            subject: editing.subject,
            body: editing.body,
            active: !!editing.active
          } : undefined}
          submitLabel={editing ? "Update" : "Save"}
          loading={createMutation.isPending || updateMutation.isPending}
          onCancel={() => setOpen(false)}
          onSubmit={(values) => {
            const action = editing ? updateMutation.mutateAsync({ id: editing.id, payload: values }) : createMutation.mutateAsync(values);
            action.then(() => { toast.success(editing ? "Template updated" : "Template created"); setOpen(false); }).catch((e) => toast.error(String(e)));
          }}
        />
      </Modal>
    </div>
  );
}
