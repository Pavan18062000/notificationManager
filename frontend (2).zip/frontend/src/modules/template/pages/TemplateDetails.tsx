import { useParams } from "react-router-dom";
import { PageHeader } from "shared/components";

export default function TemplateDetails() {
  const { id } = useParams();
  return <div><PageHeader title="Template Details" /><p className="text-sm text-slate-600">ID: {id}</p></div>;
}

