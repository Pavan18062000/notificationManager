import { apiClient } from "services/apiClient";

export const templateApi = {
  list: async () => (await apiClient.get("/api/templates")).data,
  create: async (payload: unknown) => (await apiClient.post("/api/templates", payload)).data,
  update: async (id: string | number, payload: unknown) => (await apiClient.put(`/api/templates/${id}`, payload)).data,
  search: async (params: { projectId: string; countryId: string; channelId: string; eventTypeId: string }) =>
    (await apiClient.get("/api/templates/search", { params })).data
};

