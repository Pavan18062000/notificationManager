import { DataTable, StatusBadge } from "shared/components";

type TemplateRow = {
  id: number;
  templateName?: string;
  projectId?: number;
  countryId?: number;
  channelId?: number;
  eventTypeId?: number;
  active?: boolean;
};

export function TemplateTable({ rows }: { rows: TemplateRow[] }) {
  return <DataTable headers={["Id", "Template", "Project", "Country", "Channel", "Event", "Status"]} rows={rows.map((r) => [r.id, r.templateName ?? "-", r.projectId ?? "-", r.countryId ?? "-", r.channelId ?? "-", r.eventTypeId ?? "-", <StatusBadge status={r.active ? "ACTIVE" : "INACTIVE"} />])} />;
}
