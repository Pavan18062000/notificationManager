import { useState } from "react";
import { Button, Input, Select } from "shared/components";
import { getAuthSession, isProjectAdmin } from "services/authStorage";

type TemplatePayload = {
  projectId: number;
  countryId: number;
  channelId: number;
  eventTypeId: number;
  templateName: string;
  language?: string;
  subject?: string;
  body: string;
  active: boolean;
};

type Option = { id: number; label: string };

export function TemplateForm({
  initialValues,
  projects,
  countries,
  channels,
  eventTypes,
  submitLabel,
  onSubmit,
  onCancel,
  loading
}: {
  initialValues?: TemplatePayload;
  projects: Option[];
  countries: Option[];
  channels: Option[];
  eventTypes: Option[];
  submitLabel?: string;
  onSubmit: (v: TemplatePayload) => void;
  onCancel?: () => void;
  loading?: boolean;
}) {
  const projectAdmin = isProjectAdmin();
  const assignedProjectId = getAuthSession()?.user?.projectId ?? null;
  const hasProjects = projects.length > 0;
  const hasCountries = countries.length > 0;
  const hasChannels = channels.length > 0;
  const hasEventTypes = eventTypes.length > 0;
  const canSubmit = hasProjects && hasCountries && hasChannels && hasEventTypes;
  const [values, setValues] = useState<TemplatePayload>(
    initialValues ?? {
      projectId: Number(assignedProjectId ?? projects[0]?.id ?? 0),
      countryId: countries[0]?.id ?? 0,
      channelId: channels[0]?.id ?? 0,
      eventTypeId: eventTypes[0]?.id ?? 0,
      templateName: "",
      language: "en",
      subject: "",
      body: "",
      active: true
    }
  );

  return (
    <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); onSubmit(values); }}>
      <Select value={hasProjects ? values.projectId : ""} onChange={(e) => setValues((s) => ({ ...s, projectId: Number(e.target.value) }))} required disabled={!hasProjects || projectAdmin}>
        {hasProjects ? projects.map((x) => <option key={x.id} value={x.id}>{x.label}</option>) : <option value="">No projects found</option>}
      </Select>
      {!hasProjects ? <p className="text-xs text-slate-500">Please add project first</p> : null}
      <Select value={hasCountries ? values.countryId : ""} onChange={(e) => setValues((s) => ({ ...s, countryId: Number(e.target.value) }))} required disabled={!hasCountries}>
        {hasCountries ? countries.map((x) => <option key={x.id} value={x.id}>{x.label}</option>) : <option value="">No countries found</option>}
      </Select>
      {!hasCountries ? <p className="text-xs text-slate-500">Please add country first</p> : null}
      <Select value={hasChannels ? values.channelId : ""} onChange={(e) => setValues((s) => ({ ...s, channelId: Number(e.target.value) }))} required disabled={!hasChannels}>
        {hasChannels ? channels.map((x) => <option key={x.id} value={x.id}>{x.label}</option>) : <option value="">No channels found</option>}
      </Select>
      {!hasChannels ? <p className="text-xs text-slate-500">Please add channel first</p> : null}
      <Select value={hasEventTypes ? values.eventTypeId : ""} onChange={(e) => setValues((s) => ({ ...s, eventTypeId: Number(e.target.value) }))} required disabled={!hasEventTypes}>
        {hasEventTypes ? eventTypes.map((x) => <option key={x.id} value={x.id}>{x.label}</option>) : <option value="">No event types found</option>}
      </Select>
      {!hasEventTypes ? <p className="text-xs text-slate-500">Please add event type first</p> : null}
      <Input placeholder="Template Name" value={values.templateName} onChange={(e) => setValues((s) => ({ ...s, templateName: e.target.value }))} required />
      <Input placeholder="Language" value={values.language ?? ""} onChange={(e) => setValues((s) => ({ ...s, language: e.target.value }))} />
      <Input placeholder="Subject" value={values.subject ?? ""} onChange={(e) => setValues((s) => ({ ...s, subject: e.target.value }))} />
      <textarea className="w-full rounded-md border border-slate-300 px-3 py-2" rows={5} placeholder="Template Body" value={values.body} onChange={(e) => setValues((s) => ({ ...s, body: e.target.value }))} required />
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={values.active} onChange={(e) => setValues((s) => ({ ...s, active: e.target.checked }))} /> Active</label>
      <div className="flex gap-2">
        <Button type="submit" disabled={loading || !canSubmit}>{loading ? "Saving..." : submitLabel ?? "Save"}</Button>
        {onCancel && <Button type="button" className="bg-slate-500 hover:bg-slate-600" onClick={onCancel}>Cancel</Button>}
      </div>
    </form>
  );
}
