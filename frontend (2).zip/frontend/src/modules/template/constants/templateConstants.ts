export const templateConstants = {
  module: "template"
};

