import { z } from "zod";

export const templateSchema = z.object({
  name: z.string().min(2, "Name is required"),
  active: z.boolean().optional().default(true)
});

export type TemplateForm = z.infer<typeof templateSchema>;

