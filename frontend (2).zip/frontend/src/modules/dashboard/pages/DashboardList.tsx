import { useQuery } from "@tanstack/react-query";
import { apiClient } from "services/apiClient";
import { PageHeader, StatusBadge } from "shared/components";

async function fetchStats() {
  const [projects] = await Promise.allSettled([apiClient.get("/api/projects")]);
  const projectList = projects.status === "fulfilled" ? projects.value.data?.data ?? projects.value.data ?? [] : [];
  return {
    totalProjects: projectList.length,
    activeProjects: projectList.filter((p: any) => p.active).length,
    totalNotifications: 0,
    failedNotifications: 0,
    smsSent: 0,
    emailSent: 0,
    whatsappSent: 0,
    pushSent: 0
  };
}

export default function DashboardList() {
  const { data } = useQuery({ queryKey: ["dashboard-stats"], queryFn: fetchStats });
  const cards = [
    ["Total Projects", data?.totalProjects ?? 0],
    ["Active Projects", data?.activeProjects ?? 0],
    ["Total Notifications", data?.totalNotifications ?? 0],
    ["Failed Notifications", data?.failedNotifications ?? 0],
    ["SMS Sent", data?.smsSent ?? 0],
    ["Email Sent", data?.emailSent ?? 0],
    ["WhatsApp Sent", data?.whatsappSent ?? 0],
    ["Push Sent", data?.pushSent ?? 0]
  ];

  return (
    <div>
      <PageHeader title="Dashboard" />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map(([label, value]) => (
          <div key={String(label)} className="rounded-xl border border-[var(--border-color)] bg-[var(--card-bg)] p-4 shadow-sm">
            <p className="text-sm text-[var(--text-secondary)]">{label}</p>
            <p className="mt-2 text-2xl font-semibold">{value}</p>
            <div className="mt-2"><StatusBadge status={Number(value) > 0 ? "ACTIVE" : "PENDING"} /></div>
          </div>
        ))}
      </div>
    </div>
  );
}
