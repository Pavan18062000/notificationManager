export const projectConstants = {
  module: "project"
};

