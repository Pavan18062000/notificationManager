export type ProjectItem = {
  id: number;
  name: string;
  active?: boolean;
};

