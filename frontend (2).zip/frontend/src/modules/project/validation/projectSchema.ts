import { z } from "zod";

export const projectSchema = z.object({
  name: z.string().min(2, "Name is required"),
  active: z.boolean().optional().default(true)
});

export type ProjectForm = z.infer<typeof projectSchema>;

