import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { projectApi } from "../api/projectApi";

export function useProjectList() {
  return useQuery({ queryKey: ["project"], queryFn: () => projectApi.list() });
}

export function useCreateProject() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (payload: unknown) => projectApi.create(payload), onSuccess: () => qc.invalidateQueries({ queryKey: ["project"] }) });
}

export function useUpdateProject() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: ({ id, payload }: { id: string | number; payload: unknown }) => projectApi.update(id, payload), onSuccess: () => qc.invalidateQueries({ queryKey: ["project"] }) });
}
