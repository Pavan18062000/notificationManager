import { apiClient } from "services/apiClient";

export const projectApi = {
  list: async () => (await apiClient.get("/api/projects")).data,
  get: async (id: string | number) => (await apiClient.get(`/api/projects/${id}`)).data,
  create: async (payload: unknown) => (await apiClient.post("/api/projects", payload)).data,
  update: async (id: string | number, payload: unknown) => (await apiClient.put(`/api/projects/${id}`, payload)).data
};

