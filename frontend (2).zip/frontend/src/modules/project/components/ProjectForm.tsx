import { useState } from "react";
import { Button, Input } from "shared/components";

type ProjectPayload = { projectCode: string; projectName: string; active: boolean };

export function ProjectForm({
  initialValues,
  submitLabel,
  onSubmit,
  onCancel,
  loading
}: {
  initialValues?: ProjectPayload;
  submitLabel?: string;
  onSubmit: (v: ProjectPayload) => void;
  onCancel?: () => void;
  loading?: boolean;
}) {
  const [values, setValues] = useState<ProjectPayload>(initialValues ?? { projectCode: "", projectName: "", active: true });
  return (
    <form
      className="space-y-3"
      onSubmit={(e) => {
        e.preventDefault();
        onSubmit(values);
      }}
    >
      <Input placeholder="Project Code" value={values.projectCode} onChange={(e) => setValues((s) => ({ ...s, projectCode: e.target.value }))} required />
      <Input placeholder="Project Name" value={values.projectName} onChange={(e) => setValues((s) => ({ ...s, projectName: e.target.value }))} required />
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={values.active} onChange={(e) => setValues((s) => ({ ...s, active: e.target.checked }))} /> Active
      </label>
      <div className="flex gap-2">
        <Button type="submit" disabled={loading}>{loading ? "Saving..." : submitLabel ?? "Save"}</Button>
        {onCancel && <Button type="button" className="bg-slate-500 hover:bg-slate-600" onClick={onCancel}>Cancel</Button>}
      </div>
    </form>
  );
}
