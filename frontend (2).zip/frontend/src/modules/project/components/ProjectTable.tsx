import { DataTable, StatusBadge } from "shared/components";

type ProjectRow = { id: number; projectCode?: string; projectName?: string; active?: boolean };

export function ProjectTable({ rows }: { rows: ProjectRow[] }) {
  return <DataTable headers={["Id", "Code", "Name", "Status"]} rows={rows.map((r) => [r.id, r.projectCode ?? "-", r.projectName ?? "-", <StatusBadge status={r.active ? "ACTIVE" : "INACTIVE"} />])} />;
}

