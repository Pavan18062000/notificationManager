import { useState } from "react";
import { Button, DataTable, EmptyState, ListToolbar, LoadingSpinner, Modal, PageHeader, PaginationControls, StatusBadge } from "shared/components";
import { useToast } from "hooks/useToast";
import { ProjectForm } from "../components/ProjectForm";
import { useCreateProject, useProjectList, useUpdateProject } from "../hooks/useProject";

export default function ProjectList() {
  const toast = useToast();
  const { data, isLoading, isError, error } = useProjectList();
  const createMutation = useCreateProject();
  const updateMutation = useUpdateProject();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const raw = data?.data ?? data ?? [];
  const list = Array.isArray(raw) ? raw : [];
  const filtered = list.filter((x: any) => `${x.projectCode} ${x.projectName}`.toLowerCase().includes(query.toLowerCase()));
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);

  return (
    <div>
      <PageHeader title="Projects" description="Manage project master data" action={<Button onClick={() => { setEditing(null); setOpen(true); }}>+ Add Project</Button>} />
      {isError ? <EmptyState text={`Failed to load projects: ${String(error)}`} /> : null}
      <ListToolbar query={query} onQueryChange={(v) => { setQuery(v); setPage(1); }} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(1); }} />
      {isLoading ? <LoadingSpinner /> : isError ? null : !filtered.length ? <EmptyState text="Data not found" hint="Click Add button to create first record." action={<Button onClick={() => { setEditing(null); setOpen(true); }}>+ Add Project</Button>} /> : (
        <DataTable
          headers={["Id", "Code", "Name", "Status", "Actions"]}
          rows={paged.map((r: any) => [
            r.id,
            r.projectCode,
            r.projectName,
            <StatusBadge status={r.active ? "ACTIVE" : "INACTIVE"} />,
            <Button className="px-2 py-1 text-xs" onClick={() => { setEditing(r); setOpen(true); }}>Edit</Button>
          ])}
        />
      )}
      {!isLoading && filtered.length > 0 && <PaginationControls page={page} totalPages={totalPages} onPageChange={setPage} />}
      <Modal open={open} title={editing ? "Update Project" : "Add Project"}>
        <ProjectForm
          initialValues={editing ? { projectCode: editing.projectCode, projectName: editing.projectName, active: !!editing.active } : undefined}
          submitLabel={editing ? "Update" : "Save"}
          loading={createMutation.isPending || updateMutation.isPending}
          onCancel={() => setOpen(false)}
          onSubmit={(values) => {
            const action = editing ? updateMutation.mutateAsync({ id: editing.id, payload: values }) : createMutation.mutateAsync(values);
            action.then(() => { toast.success(editing ? "Project updated" : "Project created"); setOpen(false); }).catch((e) => toast.error(String(e)));
          }}
        />
      </Modal>
    </div>
  );
}
