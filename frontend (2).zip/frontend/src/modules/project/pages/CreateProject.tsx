import { useNavigate } from "react-router-dom";
import { PageHeader } from "shared/components";
import { ProjectForm } from "../components/ProjectForm";
import { useCreateProject } from "../hooks/useProject";
import { useToast } from "hooks/useToast";

export default function CreateProject() {
  const navigate = useNavigate();
  const mutation = useCreateProject();
  const toast = useToast();
  return (
    <div>
      <PageHeader title="Create Project" />
      <ProjectForm submitLabel="Save" loading={mutation.isPending} onCancel={() => navigate(-1)} onSubmit={(v) => mutation.mutate(v, { onSuccess: () => { toast.success("Created"); navigate(-1); }, onError: (e) => toast.error(String(e)) })} />
    </div>
  );
}
