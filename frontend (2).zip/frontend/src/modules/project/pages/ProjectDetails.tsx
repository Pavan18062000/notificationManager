import { useState } from "react";
import { useParams } from "react-router-dom";
import { PageHeader } from "shared/components";

const tabs = ["Overview", "Countries", "Channels", "Providers", "Templates", "Logs"] as const;

export default function ProjectDetails() {
  const { id } = useParams();
  const [activeTab, setActiveTab] = useState<(typeof tabs)[number]>("Overview");

  return (
    <div>
      <PageHeader title={`Project Details #${id}`} />
      <div className="mb-4 flex flex-wrap gap-2">
        {tabs.map((tab) => (
          <button key={tab} onClick={() => setActiveTab(tab)} className={`rounded-md px-3 py-2 text-sm ${activeTab === tab ? "bg-brand-500 text-white" : "bg-white hover:bg-slate-100"}`}>
            {tab}
          </button>
        ))}
      </div>
      <div className="rounded-lg bg-white p-4 text-sm text-slate-700">
        {activeTab} content area for project {id}. Connect this tab to module APIs for full management flows.
      </div>
    </div>
  );
}
