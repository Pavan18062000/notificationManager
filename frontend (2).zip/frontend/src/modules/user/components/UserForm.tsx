import { type FormEvent, useMemo, useState } from "react";
import { Button, Input, Select } from "shared/components";
import type { UserPayload } from "../api/userApi";

type ProjectOption = { id: number; label: string };

export function UserForm({
  projects,
  initialValues,
  isEdit,
  loading,
  onCancel,
  onSubmit
}: {
  projects: ProjectOption[];
  initialValues?: UserPayload;
  isEdit?: boolean;
  loading?: boolean;
  onCancel?: () => void;
  onSubmit: (payload: UserPayload) => void;
}) {
  const [values, setValues] = useState<UserPayload>(initialValues ?? {
    email: "",
    password: "",
    role: "PROJECT_ADMIN",
    projectId: projects[0]?.id ?? null,
    active: true
  });
  const [error, setError] = useState("");
  const requireProject = values.role === "PROJECT_ADMIN";
  const canSubmit = !requireProject || !!values.projectId;
  const projectMissing = requireProject && projects.length === 0;
  const helper = useMemo(() => {
    if (!requireProject) return "";
    if (projects.length === 0) return "Please add project first";
    return "";
  }, [requireProject, projects.length]);

  function submit(e: FormEvent) {
    e.preventDefault();
    if (!isEdit && !values.password?.trim()) {
      setError("Password is required");
      return;
    }
    if (requireProject && !values.projectId) {
      setError("Project is required for PROJECT_ADMIN");
      return;
    }
    setError("");
    onSubmit({
      ...values,
      email: values.email.trim(),
      projectId: requireProject ? values.projectId : null,
      password: values.password?.trim() ? values.password : undefined
    });
  }

  return (
    <form className="space-y-3" onSubmit={submit}>
      <Input type="email" placeholder="Email" value={values.email} onChange={(e) => setValues((s) => ({ ...s, email: e.target.value }))} required />
      <Input type="password" placeholder={isEdit ? "Password (optional for reset)" : "Password"} value={values.password ?? ""} onChange={(e) => setValues((s) => ({ ...s, password: e.target.value }))} required={!isEdit} />
      <Select value={values.role} onChange={(e) => setValues((s) => ({ ...s, role: e.target.value as UserPayload["role"], projectId: e.target.value === "SUPER_ADMIN" ? null : (projects[0]?.id ?? null) }))}>
        <option value="SUPER_ADMIN">SUPER_ADMIN</option>
        <option value="PROJECT_ADMIN">PROJECT_ADMIN</option>
      </Select>
      {requireProject ? (
        <>
          <Select value={projectMissing ? "" : (values.projectId ?? "")} onChange={(e) => setValues((s) => ({ ...s, projectId: Number(e.target.value) }))} disabled={projectMissing} required>
            {projectMissing ? <option value="">No projects found</option> : projects.map((p) => <option key={p.id} value={p.id}>{p.label}</option>)}
          </Select>
          {helper ? <p className="text-xs text-[var(--text-secondary)]">{helper}</p> : null}
        </>
      ) : null}
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={values.active} onChange={(e) => setValues((s) => ({ ...s, active: e.target.checked }))} />
        Active
      </label>
      {error ? <p className="text-sm text-red-500">{error}</p> : null}
      <div className="flex gap-2">
        <Button type="submit" disabled={loading || !canSubmit}>{loading ? "Saving..." : (isEdit ? "Update" : "Save")}</Button>
        {onCancel ? <Button type="button" className="bg-slate-500 hover:bg-slate-600" onClick={onCancel}>Cancel</Button> : null}
      </div>
    </form>
  );
}
