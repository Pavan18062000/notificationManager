import { apiClient } from "services/apiClient";

export type UserPayload = {
  email: string;
  password?: string;
  role: "SUPER_ADMIN" | "PROJECT_ADMIN";
  projectId?: number | null;
  active: boolean;
};

export const userApi = {
  list: async () => (await apiClient.get("/api/users")).data,
  create: async (payload: UserPayload) => (await apiClient.post("/api/users", payload)).data,
  update: async (id: number, payload: UserPayload) => (await apiClient.put(`/api/users/${id}`, payload)).data
};

