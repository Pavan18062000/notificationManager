import { useMemo, useState } from "react";
import { Button, DataTable, EmptyState, ListToolbar, LoadingSpinner, Modal, PageHeader, PaginationControls, StatusBadge } from "shared/components";
import { useToast } from "hooks/useToast";
import { useProjectList } from "modules/project/hooks/useProject";
import { buildOptionLabel } from "utils/optionLabel";
import { useCreateUser, useUpdateUser, useUserList } from "../hooks/useUser";
import { UserForm } from "../components/UserForm";
import type { UserPayload } from "../api/userApi";

export default function UserList() {
  const toast = useToast();
  const { data, isLoading } = useUserList();
  const { data: projectsData } = useProjectList();
  const createMutation = useCreateUser();
  const updateMutation = useUpdateUser();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const list = data?.data ?? data ?? [];
  const projects = useMemo(() => (projectsData?.data ?? projectsData ?? []).map((x: any) => ({ id: x.id, label: buildOptionLabel([x.projectCode, x.projectName], `Project #${x.id}`) })), [projectsData]);
  const projectNameById = useMemo(() => Object.fromEntries(projects.map((p) => [p.id, p.label])), [projects]);
  const filtered = list.filter((x: any) => `${x.email ?? ""} ${x.role ?? ""} ${x.projectName ?? ""}`.toLowerCase().includes(query.toLowerCase()));
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);

  function openAdd() {
    setEditing(null);
    setOpen(true);
  }

  function openEdit(row: any) {
    setEditing(row);
    setOpen(true);
  }

  function save(values: UserPayload) {
    const action = editing
      ? updateMutation.mutateAsync({ id: editing.id, payload: values })
      : createMutation.mutateAsync(values);
    action
      .then(() => {
        toast.success(editing ? "User updated" : "User created");
        setOpen(false);
      })
      .catch((e) => toast.error(String(e)));
  }

  return (
    <div>
      <PageHeader title="Users" description="Manage application users and access roles" action={<Button onClick={openAdd}>+ Add User</Button>} />
      <ListToolbar query={query} onQueryChange={(v) => { setQuery(v); setPage(1); }} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(1); }} />
      {isLoading ? <LoadingSpinner /> : !filtered.length ? <EmptyState text="Data not found" hint="Click Add button to create first record." action={<Button onClick={openAdd}>+ Add User</Button>} /> : (
        <DataTable
          headers={["Id", "Email", "Role", "Project", "Status", "Actions"]}
          rows={paged.map((r: any) => [
            r.id,
            r.email,
            r.role,
            r.projectName ?? (r.projectId ? projectNameById[r.projectId] : "Not assigned") ?? "Not assigned",
            <StatusBadge status={r.active ? "ACTIVE" : "INACTIVE"} />,
            <div className="flex gap-2">
              <Button className="px-2 py-1 text-xs" onClick={() => openEdit(r)}>Edit</Button>
              {r.active ? (
                <Button className="bg-red-600 px-2 py-1 text-xs hover:bg-red-700" onClick={() => {
                  if (!window.confirm("Deactivate this user?")) return;
                  save({ email: r.email, role: r.role, projectId: r.projectId ?? null, active: false });
                }}>Deactivate</Button>
              ) : null}
            </div>
          ])}
        />
      )}
      {!isLoading && filtered.length > 0 && <PaginationControls page={page} totalPages={totalPages} onPageChange={setPage} />}
      <Modal open={open} title={editing ? "Update User" : "Add User"}>
        <UserForm
          projects={projects}
          isEdit={!!editing}
          initialValues={editing ? {
            email: editing.email,
            role: editing.role,
            projectId: editing.projectId ?? null,
            active: !!editing.active
          } : undefined}
          loading={createMutation.isPending || updateMutation.isPending}
          onCancel={() => setOpen(false)}
          onSubmit={save}
        />
      </Modal>
    </div>
  );
}
