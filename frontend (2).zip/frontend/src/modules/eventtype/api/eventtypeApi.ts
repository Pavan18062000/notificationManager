import { apiClient } from "services/apiClient";

export const eventtypeApi = {
  list: async () => (await apiClient.get("/api/event-types")).data,
  create: async (payload: unknown) => (await apiClient.post("/api/event-types", payload)).data
};

