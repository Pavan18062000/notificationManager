import { useState } from "react";
import { Button, Input } from "shared/components";

type EventTypePayload = { eventCode: string; eventName: string };

export function EventtypeForm({ initialValues, submitLabel, onSubmit, onCancel, loading }: { initialValues?: EventTypePayload; submitLabel?: string; onSubmit: (v: EventTypePayload) => void; onCancel?: () => void; loading?: boolean; }) {
  const [values, setValues] = useState<EventTypePayload>(initialValues ?? { eventCode: "", eventName: "" });
  return (
    <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); onSubmit(values); }}>
      <Input placeholder="Event Code" value={values.eventCode} onChange={(e) => setValues((s) => ({ ...s, eventCode: e.target.value }))} required />
      <Input placeholder="Event Name" value={values.eventName} onChange={(e) => setValues((s) => ({ ...s, eventName: e.target.value }))} required />
      <div className="flex gap-2">
        <Button type="submit" disabled={loading}>{loading ? "Saving..." : submitLabel ?? "Save"}</Button>
        {onCancel && <Button type="button" className="bg-slate-500 hover:bg-slate-600" onClick={onCancel}>Cancel</Button>}
      </div>
    </form>
  );
}
