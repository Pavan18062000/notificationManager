import { DataTable } from "shared/components";

type EventTypeRow = { id: number; eventCode?: string; eventName?: string };

export function EventtypeTable({ rows }: { rows: EventTypeRow[] }) {
  return <DataTable headers={["Id", "Code", "Name"]} rows={rows.map((r) => [r.id, r.eventCode ?? "-", r.eventName ?? "-"])} />;
}
