import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { eventtypeApi } from "../api/eventtypeApi";

export function useEventtypeList() {
  return useQuery({ queryKey: ["eventtype"], queryFn: () => eventtypeApi.list() });
}

export function useCreateEventtype() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (payload: unknown) => eventtypeApi.create(payload), onSuccess: () => qc.invalidateQueries({ queryKey: ["eventtype"] }) });
}

