export type EventtypeItem = {
  id: number;
  name: string;
  active?: boolean;
};

