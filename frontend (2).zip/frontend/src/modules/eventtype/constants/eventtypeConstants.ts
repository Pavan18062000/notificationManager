export const eventtypeConstants = {
  module: "eventtype"
};

