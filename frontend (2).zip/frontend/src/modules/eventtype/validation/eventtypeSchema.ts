import { z } from "zod";

export const eventtypeSchema = z.object({
  name: z.string().min(2, "Name is required"),
  active: z.boolean().optional().default(true)
});

export type EventtypeForm = z.infer<typeof eventtypeSchema>;

