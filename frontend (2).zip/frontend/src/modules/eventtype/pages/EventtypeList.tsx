import { useState } from "react";
import { Button, DataTable, EmptyState, ListToolbar, LoadingSpinner, Modal, PageHeader, PaginationControls } from "shared/components";
import { useToast } from "hooks/useToast";
import { EventtypeForm } from "../components/EventtypeForm";
import { useCreateEventtype, useEventtypeList } from "../hooks/useEventtype";

export default function EventtypeList() {
  const toast = useToast();
  const { data, isLoading } = useEventtypeList();
  const createMutation = useCreateEventtype();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const list = data?.data ?? data ?? [];
  const filtered = list.filter((x: any) => `${x.eventCode} ${x.eventName}`.toLowerCase().includes(query.toLowerCase()));
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);

  return (
    <div>
      <PageHeader
        title="Event Types"
        description="Manage event type master data"
        action={<Button onClick={() => setOpen(true)}>+ Add Event Type</Button>}
      />
      <ListToolbar query={query} onQueryChange={(v) => { setQuery(v); setPage(1); }} pageSize={pageSize} onPageSizeChange={(v) => { setPageSize(v); setPage(1); }} />
      {isLoading ? <LoadingSpinner /> : !filtered.length ? <EmptyState text="Data not found" hint="Click Add button to create first record." action={<Button onClick={() => setOpen(true)}>+ Add Event Type</Button>} /> : (
        <DataTable headers={["Id", "Code", "Name"]} rows={paged.map((r: any) => [r.id, r.eventCode, r.eventName])} />
      )}
      {!isLoading && filtered.length > 0 && <PaginationControls page={page} totalPages={totalPages} onPageChange={setPage} />}
      <Modal open={open} title="Add Event Type">
        <EventtypeForm loading={createMutation.isPending} onCancel={() => setOpen(false)} onSubmit={(values) => createMutation.mutate(values, { onSuccess: () => { toast.success("Event type created"); setOpen(false); }, onError: (e) => toast.error(String(e)) })} />
      </Modal>
    </div>
  );
}
