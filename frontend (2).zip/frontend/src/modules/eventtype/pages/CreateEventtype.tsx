import { useNavigate } from "react-router-dom";
import { PageHeader } from "shared/components";
import { EventtypeForm } from "../components/EventtypeForm";
import { useCreateEventtype } from "../hooks/useEventtype";
import { useToast } from "hooks/useToast";

export default function CreateEventtype() {
  const navigate = useNavigate();
  const mutation = useCreateEventtype();
  const toast = useToast();
  return (
    <div>
      <PageHeader title="Create Event Type" />
      <EventtypeForm submitLabel="Save" loading={mutation.isPending} onCancel={() => navigate(-1)} onSubmit={(v) => mutation.mutate(v, { onSuccess: () => { toast.success("Created"); navigate(-1); }, onError: (e) => toast.error(String(e)) })} />
    </div>
  );
}
