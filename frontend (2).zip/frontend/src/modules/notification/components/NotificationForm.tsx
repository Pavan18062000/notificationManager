import { Input, Button } from "shared/components";

export function NotificationForm({ onSubmit }: { onSubmit: (v: { name: string }) => void }) {
  return (
    <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); const name = (e.currentTarget.elements.namedItem('name') as HTMLInputElement).value; onSubmit({ name }); }}>
      <Input name="name" placeholder="Name" />
      <Button type="submit">Save</Button>
    </form>
  );
}

