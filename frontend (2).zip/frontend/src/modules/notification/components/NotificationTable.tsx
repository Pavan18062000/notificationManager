import { DataTable, StatusBadge } from "shared/components";

export function NotificationTable({ rows }: { rows: Array<{ id: number; name?: string; active?: boolean }> }) {
  return <DataTable headers={["Id", "Name", "Status"]} rows={rows.map((r) => [r.id, r.name ?? "-", <StatusBadge status={r.active ? "ACTIVE" : "INACTIVE"} />])} />;
}

