import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { notificationApi } from "../api/notificationApi";

export function useNotificationList() {
  return useQuery({ queryKey: ["notification"], queryFn: () => notificationApi.list() });
}

export function useCreateNotification() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (payload: unknown) => notificationApi.create(payload), onSuccess: () => qc.invalidateQueries({ queryKey: ["notification"] }) });
}

