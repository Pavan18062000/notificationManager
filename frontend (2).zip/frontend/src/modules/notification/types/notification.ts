export type NotificationItem = {
  id: number;
  name: string;
  active?: boolean;
};

