export const notificationConstants = {
  module: "notification"
};

