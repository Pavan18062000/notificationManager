import { apiClient } from "services/apiClient";

export const notificationApi = {
  send: async (payload: unknown, options?: { apiKey?: string; idempotencyKey?: string }) => {
    const headers = {
      ...(options?.apiKey ? { "x-api-key": options.apiKey } : {}),
      ...(options?.idempotencyKey ? { "Idempotency-Key": options.idempotencyKey } : {})
    };
    const maskedKey = options?.apiKey ? `${options.apiKey.slice(0, 8)}...${options.apiKey.slice(-4)}` : "(missing)";
    const curlHeaders = [
      `-H "Content-Type: application/json"`,
      `-H "x-api-key: ${maskedKey}"`,
      ...(options?.idempotencyKey ? [`-H "Idempotency-Key: ${options.idempotencyKey}"`] : [])
    ].join(" ");
    const curlBody = JSON.stringify(payload);
    const curl = `curl -X POST "http://localhost:5000/open-api/v1/notifications/send" ${curlHeaders} -d '${curlBody}'`;
    console.log("[NotificationAPI] CURL (masked):", curl);
    return (await apiClient.post("/open-api/v1/notifications/send", payload, { headers })).data;
  },
  listLogs: async () => ({ data: [] })
};

