import { useState } from "react";
import { DataTable, Input, PageHeader, Select, StatusBadge } from "shared/components";

export default function NotificationDetails() {
  const [rows] = useState<any[]>([]);
  return (
    <div className="space-y-4">
      <PageHeader title="Notification Logs" />
      <div className="grid gap-2 rounded-lg bg-white p-4 md:grid-cols-6">
        <Input placeholder="project" />
        <Input placeholder="country" />
        <Input placeholder="channel" />
        <Input placeholder="provider" />
        <Select><option>status</option><option>SENT</option><option>FAILED</option></Select>
        <Input type="date" />
      </div>
      <DataTable
        headers={["requestId", "project", "country", "channel", "provider", "recipient", "status", "retryCount"]}
        rows={rows.map((r) => [r.requestId, r.project, r.country, r.channel, r.provider, r.recipient, <StatusBadge status={r.status} />, r.retryCount])}
      />
    </div>
  );
}
