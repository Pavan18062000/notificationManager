import { useNavigate } from "react-router-dom";
import { PageHeader } from "shared/components";
import { NotificationForm } from "../components/NotificationForm";
import { useCreateNotification } from "../hooks/useNotification";
import { useToast } from "hooks/useToast";

export default function CreateNotification() {
  const navigate = useNavigate();
  const mutation = useCreateNotification();
  const toast = useToast();
  return (
    <div>
      <PageHeader title="Create Notification" />
      <NotificationForm onSubmit={(v) => mutation.mutate(v, { onSuccess: () => { toast.success("Created" ); navigate(-1); }, onError: (e) => toast.error(String(e)) })} />
    </div>
  );
}

