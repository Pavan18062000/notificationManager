import { useEffect, useMemo, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button, Input, PageHeader, Select } from "shared/components";
import { useToast } from "hooks/useToast";
import { notificationApi } from "../api/notificationApi";
import { getAuthSession, isProjectAdmin } from "services/authStorage";
import { useProjectList } from "modules/project/hooks/useProject";
import { useCountryList } from "modules/country/hooks/useCountry";
import { useEventtypeList } from "modules/eventtype/hooks/useEventtype";
import { useChannelList } from "modules/channel/hooks/useChannel";
import { useNotificationRouteList } from "modules/notificationroute/hooks/useNotificationRoute";
import { buildOptionLabel } from "utils/optionLabel";
import { openApiApi } from "modules/openapi/api/openApiApi";

const channelOptions = ["SMS", "EMAIL", "WHATSAPP", "PUSH"] as const;
type ChannelType = (typeof channelOptions)[number];

type TemplateRow = { id: string; key: string; value: string };

type FormData = {
  channel: ChannelType;
  projectCode: string;
  countryCode: string;
  eventCode: string;
  recipient: string;
  subject: string;
  body: string;
};

const schema = z.object({
  channel: z.enum(channelOptions),
  projectCode: z.string().min(1, "Project is required"),
  countryCode: z.string().min(1, "Country is required"),
  eventCode: z.string().min(1, "Event Type is required"),
  recipient: z.string().min(1, "Recipient is required"),
  subject: z.string().optional(),
  body: z.string().min(1, "Body is required")
}).superRefine((v, ctx) => {
  if ((v.channel === "EMAIL" || v.channel === "PUSH") && !v.subject?.trim()) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["subject"], message: v.channel === "EMAIL" ? "Subject is required" : "Title is required" });
  }
});

function jsonToRows(data: Record<string, unknown> | undefined): TemplateRow[] {
  if (!data) return [{ id: crypto.randomUUID(), key: "", value: "" }];
  const entries = Object.entries(data);
  if (!entries.length) return [{ id: crypto.randomUUID(), key: "", value: "" }];
  return entries.map(([k, v]) => ({ id: crypto.randomUUID(), key: String(k), value: typeof v === "string" ? v : JSON.stringify(v) }));
}

function rowsToJson(rows: TemplateRow[]): Record<string, unknown> | undefined {
  const out: Record<string, unknown> = {};
  rows.forEach((r) => {
    const key = r.key.trim();
    if (!key) return;
    const value = r.value.trim();
    out[key] = value;
  });
  return Object.keys(out).length ? out : undefined;
}

function parseJson(raw: string): { ok: true; value?: Record<string, unknown> } | { ok: false } {
  if (!raw.trim()) return { ok: true, value: undefined };
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) return { ok: true, value: parsed as Record<string, unknown> };
    return { ok: false };
  } catch {
    return { ok: false };
  }
}

export default function NotificationList() {
  const OPEN_API_KEY_CACHE = "open_api_keys_by_project";
  const toast = useToast();
  const session = getAuthSession();
  const projectAdmin = isProjectAdmin();
  const assignedProjectCode = session?.user?.projectCode ?? "";

  const [showPayload, setShowPayload] = useState(false);
  const [showHtmlPreview, setShowHtmlPreview] = useState(false);
  const [result, setResult] = useState<any | null>(null);
  const [openApiKey, setOpenApiKey] = useState("");
  const [idempotencyKey, setIdempotencyKey] = useState("");
  const [advancedJsonMode, setAdvancedJsonMode] = useState(false);
  const [templateRows, setTemplateRows] = useState<TemplateRow[]>([{ id: crypto.randomUUID(), key: "name", value: "Pavan" }, { id: crypto.randomUUID(), key: "otp", value: "123456" }]);
  const [templateDataRaw, setTemplateDataRaw] = useState('{\n  "name": "Pavan",\n  "otp": "123456"\n}');

  const { data: projectData } = useProjectList();
  const { data: countryData } = useCountryList();
  const { data: eventData } = useEventtypeList();
  const { data: channelData } = useChannelList();
  const { data: routeData } = useNotificationRouteList();

  const projects = useMemo(() => (projectData?.data ?? projectData ?? []), [projectData]);
  const countries = useMemo(() => (countryData?.data ?? countryData ?? []), [countryData]);
  const events = useMemo(() => (eventData?.data ?? eventData ?? []), [eventData]);
  const channels = useMemo(() => (channelData?.data ?? channelData ?? []), [channelData]);
  const notificationRoutes = useMemo(() => (routeData?.data ?? routeData ?? []), [routeData]);

  const { watch, setValue, reset, handleSubmit, formState: { errors, touchedFields, isSubmitted } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      channel: "SMS",
      projectCode: assignedProjectCode,
      countryCode: "",
      eventCode: "",
      recipient: "",
      subject: "",
      body: ""
    }
  });

  const values = watch();
  const selectedProjectCode = values.projectCode;
  const selectedChannel = values.channel;

  const projectByCode = useMemo(() => Object.fromEntries(projects.map((x: any) => [String(x.projectCode), x])), [projects]);
  const selectedProject = projectByCode[selectedProjectCode];

  const templateFromRows = rowsToJson(templateRows);
  const parsedTemplate = parseJson(templateDataRaw);
  const templateData = advancedJsonMode ? (parsedTemplate.ok ? parsedTemplate.value : undefined) : templateFromRows;

  useEffect(() => {
    if (!selectedProjectCode) return;
    const current = JSON.parse(localStorage.getItem(OPEN_API_KEY_CACHE) || "{}");
    const cached = current?.[selectedProjectCode];
    setOpenApiKey(cached ? String(cached) : "");
  }, [selectedProjectCode]);

  useEffect(() => {
    if (!selectedProject?.id || !selectedProject?.projectCode) return;
    let cancelled = false;
    const fetchFromBackend = async () => {
      try {
        const res: any = await openApiApi.getApiKey(Number(selectedProject.id));
        if (cancelled) return;
        const payload = res?.data ?? res;
        const raw = String(payload?.apiKey ?? "").trim();
        if (!raw) return;
        const current = JSON.parse(localStorage.getItem(OPEN_API_KEY_CACHE) || "{}");
        current[selectedProject.projectCode] = raw;
        localStorage.setItem(OPEN_API_KEY_CACHE, JSON.stringify(current));
        setOpenApiKey(raw);
      } catch {
        // surface through send flow if key is still unavailable
      }
    };
    void fetchFromBackend();
    return () => { cancelled = true; };
  }, [selectedProject?.id, selectedProject?.projectCode]);

  useEffect(() => {
    if (!advancedJsonMode) {
      setTemplateDataRaw(JSON.stringify(templateFromRows ?? {}, null, 2));
    }
  }, [advancedJsonMode, templateFromRows]);

  useEffect(() => {
    if (advancedJsonMode && parsedTemplate.ok) {
      setTemplateRows(jsonToRows(parsedTemplate.value));
    }
  }, [advancedJsonMode]);

  const countryOptions = useMemo(() => {
    if (!selectedProject?.id) return [];
    const allowed = new Set(
      notificationRoutes
        .filter((x: any) => x.projectId === selectedProject.id && x.enabled !== false && x.countryId != null)
        .map((x: any) => x.countryId)
    );
    return countries.filter((x: any) => allowed.has(x.id));
  }, [countries, notificationRoutes, selectedProject?.id]);

  const mappedChannelCodes = useMemo(() => {
    if (!selectedProject?.id || !values.countryCode) return [];
    const selectedCountry = countries.find((c: any) => c.countryCode === values.countryCode);
    if (!selectedCountry?.id) return [];
    const channelIds = new Set(
      notificationRoutes
        .filter((x: any) => x.projectId === selectedProject.id && x.enabled !== false && (x.countryId === selectedCountry.id || x.countryId == null))
        .map((x: any) => x.channelId)
    );
    return channels
      .filter((x: any) => channelIds.has(x.id) && x.active !== false)
      .map((x: any) => String(x.code).toUpperCase())
      .filter((x: string) => channelOptions.includes(x as ChannelType));
  }, [channels, countries, notificationRoutes, selectedProject?.id, values.countryCode]);

  const selectableChannels = selectedProjectCode && values.countryCode ? channelOptions.filter((x) => mappedChannelCodes.includes(x)) : channelOptions;
  const channelNotConfigured = Boolean(selectedProjectCode && values.countryCode && !mappedChannelCodes.includes(selectedChannel));

  const recipientPlaceholder = selectedChannel === "EMAIL"
    ? "Enter email address"
    : selectedChannel === "PUSH"
      ? "Enter device token"
      : "Enter phone number";

  const step1Complete = Boolean(values.channel && values.projectCode?.trim() && values.countryCode?.trim() && values.eventCode?.trim() && !channelNotConfigured);
  const missingStep3 = [
    !values.recipient?.trim() ? "Recipient" : null,
    (selectedChannel === "EMAIL" || selectedChannel === "PUSH") && !values.subject?.trim() ? (selectedChannel === "EMAIL" ? "Subject" : "Title") : null,
    !values.body?.trim() ? "Body" : null
  ].filter(Boolean) as string[];

  const canSend = step1Complete && missingStep3.length === 0 && !(advancedJsonMode && !parsedTemplate.ok);

  const openApiRequestPayload = useMemo(() => Object.fromEntries(
    Object.entries({
      countryCode: values.countryCode?.trim(),
      eventCode: values.eventCode?.trim(),
      channel: values.channel,
      recipient: values.recipient?.trim(),
      subject: (selectedChannel === "EMAIL" || selectedChannel === "PUSH") ? values.subject?.trim() : undefined,
      body: values.body?.trim(),
      templateData
    }).filter(([, v]) => v !== undefined && v !== null && v !== "")
  ), [selectedChannel, templateData, values]);

  const ensureApiKeyForSelectedProject = async () => {
    if (openApiKey.trim()) return openApiKey.trim();
    throw new Error("API key is not available. Generate it once in Developer / Open API / API Credentials and reuse the same key.");
  };

  const sendMutation = useMutation({
    mutationFn: async (request: unknown) => {
      const apiKey = await ensureApiKeyForSelectedProject();
      return notificationApi.send(request, { apiKey, idempotencyKey: idempotencyKey.trim() || undefined });
    },
    onSuccess: (resp: any) => {
      setResult({
        status: String(resp?.status ?? resp?.data?.status ?? "ACCEPTED"),
        requestId: resp?.requestId ?? resp?.data?.requestId ?? "N/A",
        provider: "Queued",
        queue: "notification.exchange",
        error: "",
        timestamp: new Date().toISOString()
      });
      toast.success("Notification test sent");
    },
    onError: (e: any) => {
      const message = typeof e === "string" ? e : String(e?.response?.data?.message ?? e?.message ?? "Failed to send notification");
      setResult({ status: "FAILED", requestId: "N/A", provider: "N/A", queue: "N/A", error: message, timestamp: new Date().toISOString() });
      toast.error(message);
    }
  });

  const progressSteps = ["Configuration", "Authentication", "Recipient", "Template", "Preview"];
  const progressIndex = !step1Complete ? 0 : missingStep3.length > 0 ? 2 : 4;

  return (
    <div className="space-y-4">
      <PageHeader title="Notification Send Test" description="Test SMS, Email, WhatsApp and Push delivery using configured project mappings." />

      <div className="rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-3">
        <div className="grid grid-cols-5 gap-2 text-xs md:text-sm">
          {progressSteps.map((step, i) => (
            <div key={step} className={`rounded-md px-2 py-2 text-center ${i <= progressIndex ? "bg-brand-500/20 text-brand-400" : "bg-[var(--bg-secondary)] text-[var(--text-secondary)]"}`}>
              {step}
            </div>
          ))}
        </div>
      </div>

      <form
        className="space-y-4"
        onSubmit={handleSubmit(() => sendMutation.mutate(openApiRequestPayload), (formErrors) => {
          const first = Object.values(formErrors)[0] as { message?: string } | undefined;
          toast.error(first?.message ?? "Please complete required fields");
        })}
      >
        <section className="rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-4">
          <h2 className="mb-3 text-base font-semibold">Step 1: Select Notification Context</h2>
          <div className="grid gap-3 md:grid-cols-2">
            <div>
              <label className="mb-1 block text-sm">Channel / Test Type *</label>
              <Select value={values.channel} onChange={(e) => setValue("channel", e.target.value as ChannelType, { shouldValidate: isSubmitted, shouldDirty: true })}>
                {selectableChannels.length > 0 ? selectableChannels.map((ch) => <option key={ch} value={ch}>{ch}</option>) : <option value="">No enabled channels found</option>}
              </Select>
            </div>
            <div>
              <label className="mb-1 block text-sm">Project *</label>
              <Select
                value={values.projectCode ?? ""}
                disabled={projectAdmin}
                onChange={(e) => {
                  setValue("projectCode", e.target.value, { shouldValidate: isSubmitted, shouldDirty: true });
                  setValue("countryCode", "", { shouldValidate: isSubmitted });
                  setValue("eventCode", "", { shouldValidate: isSubmitted });
                }}
              >
                <option value="">{projectAdmin ? "Assigned Project" : "Select project"}</option>
                {projects.map((x: any) => <option key={x.id} value={x.projectCode}>{buildOptionLabel([x.projectCode, x.projectName], `Project #${x.id}`)}</option>)}
              </Select>
              {(isSubmitted || touchedFields.projectCode) && errors.projectCode ? <p className="mt-1 text-xs text-red-600">{errors.projectCode.message}</p> : null}
            </div>
            <div>
              <label className="mb-1 block text-sm">Country *</label>
              <Select value={values.countryCode ?? ""} onChange={(e) => setValue("countryCode", e.target.value, { shouldValidate: isSubmitted, shouldDirty: true })}>
                <option value="">{selectedProjectCode ? "Select country" : "Select project first"}</option>
                {countryOptions.map((x: any) => <option key={x.id} value={x.countryCode}>{buildOptionLabel([x.countryCode, x.countryName], `Country #${x.id}`)}</option>)}
              </Select>
              {(isSubmitted || touchedFields.countryCode) && errors.countryCode ? <p className="mt-1 text-xs text-red-600">{errors.countryCode.message}</p> : null}
            </div>
            <div>
              <label className="mb-1 block text-sm">Event Type *</label>
              <Select disabled={!values.projectCode || !values.countryCode} value={values.eventCode ?? ""} onChange={(e) => setValue("eventCode", e.target.value, { shouldValidate: isSubmitted, shouldDirty: true })}>
                <option value="">{values.projectCode && values.countryCode ? "Select event type" : "Select project and country first"}</option>
                {events.map((x: any) => <option key={x.id} value={x.eventCode}>{buildOptionLabel([x.eventCode, x.eventName], `Event #${x.id}`)}</option>)}
              </Select>
              {(isSubmitted || touchedFields.eventCode) && errors.eventCode ? <p className="mt-1 text-xs text-red-600">{errors.eventCode.message}</p> : null}
            </div>
          </div>
          {channelNotConfigured ? <p className="mt-2 text-sm text-amber-600">Selected channel is not configured for this project/country.</p> : null}
        </section>

        <section className="rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-4">
          <h2 className="mb-3 text-base font-semibold">Step 2: Authentication</h2>
          <div className="grid gap-3 md:grid-cols-2">
            <div className="rounded-md border border-[var(--border-color)] bg-[var(--bg-secondary)] px-3 py-2 text-sm">
              <div className="font-medium">x-api-key</div>
              <p className="mt-1 text-xs text-[var(--text-secondary)]">
                {openApiKey ? "Loaded from secure local cache for selected project." : "Not available in cache. Generate once from Developer / Open API / API Credentials."}
              </p>
            </div>
            <div>
              <label className="mb-1 block text-sm">Idempotency-Key</label>
              <Input value={idempotencyKey} onChange={(e) => setIdempotencyKey(e.target.value)} placeholder="Optional" />
            </div>
          </div>
        </section>

        <section className="rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-4">
          <h2 className="mb-3 text-base font-semibold">Step 3: Recipient & Message</h2>
          {!step1Complete ? (
            <p className="text-sm text-[var(--text-secondary)]">Complete Step 1 to continue.</p>
          ) : (
            <div className="grid gap-3">
              <div>
                <label className="mb-1 block text-sm">Recipient *</label>
                <Input placeholder={recipientPlaceholder} value={values.recipient ?? ""} onChange={(e) => setValue("recipient", e.target.value, { shouldValidate: isSubmitted, shouldDirty: true })} />
                {(isSubmitted || touchedFields.recipient) && errors.recipient ? <p className="mt-1 text-xs text-red-600">{errors.recipient.message}</p> : null}
              </div>
              {(selectedChannel === "EMAIL" || selectedChannel === "PUSH") ? (
                <div>
                  <label className="mb-1 block text-sm">{selectedChannel === "EMAIL" ? "Subject" : "Title"} *</label>
                  <Input value={values.subject ?? ""} onChange={(e) => setValue("subject", e.target.value, { shouldValidate: isSubmitted, shouldDirty: true })} />
                  {(isSubmitted || touchedFields.subject) && errors.subject ? <p className="mt-1 text-xs text-red-600">{errors.subject.message}</p> : null}
                </div>
              ) : null}
              <div>
                <label className="mb-1 block text-sm">Body / Message *</label>
                <textarea rows={selectedChannel === "EMAIL" ? 12 : 7} className={`w-full rounded-md border border-[var(--border-color)] bg-[var(--card-bg)] px-3 py-2 text-[var(--text-primary)] outline-none focus:border-brand-500 ${selectedChannel === "EMAIL" ? "min-h-[320px]" : "min-h-[160px]"}`} value={values.body ?? ""} onChange={(e) => setValue("body", e.target.value, { shouldValidate: isSubmitted, shouldDirty: true })} />
                {(isSubmitted || touchedFields.body) && errors.body ? <p className="mt-1 text-xs text-red-600">{errors.body.message}</p> : null}
                {selectedChannel === "EMAIL" ? <div className="mt-2"><Button type="button" className="bg-slate-700 px-3 py-1.5 text-xs hover:bg-slate-800 dark:bg-slate-600 dark:hover:bg-slate-500" onClick={() => setShowHtmlPreview((s) => !s)}>{showHtmlPreview ? "Hide HTML Preview" : "Preview HTML"}</Button></div> : null}
                {selectedChannel === "EMAIL" && showHtmlPreview ? <div className="mt-2 rounded-md border border-[var(--border-color)] bg-[var(--bg-secondary)] p-3"><div className="text-xs text-[var(--text-secondary)]">HTML Preview</div><div className="mt-2 text-sm" dangerouslySetInnerHTML={{ __html: values.body ?? "" }} /></div> : null}
              </div>
            </div>
          )}
        </section>

        <section className="rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-4">
          <h2 className="mb-3 text-base font-semibold">Step 4: Template Data</h2>
          {!step1Complete ? (
            <p className="text-sm text-[var(--text-secondary)]">Complete Step 1 to continue.</p>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-sm">
                <input id="advanced-json" type="checkbox" checked={advancedJsonMode} onChange={(e) => setAdvancedJsonMode(e.target.checked)} />
                <label htmlFor="advanced-json">Advanced JSON Mode</label>
              </div>
              {advancedJsonMode ? (
                <div>
                  <textarea value={templateDataRaw} onChange={(e) => setTemplateDataRaw(e.target.value)} rows={8} className="min-h-[180px] w-full rounded-md border border-[var(--border-color)] bg-[var(--card-bg)] px-3 py-2 font-mono text-sm text-[var(--text-primary)] outline-none focus:border-brand-500" />
                  {!parsedTemplate.ok ? <p className="mt-1 text-xs text-red-600">Template JSON is invalid</p> : null}
                </div>
              ) : (
                <div className="space-y-2">
                  {templateRows.map((row) => (
                    <div key={row.id} className="grid gap-2 md:grid-cols-[1fr_1fr_auto]">
                      <Input placeholder="Key" value={row.key} onChange={(e) => setTemplateRows((prev) => prev.map((r) => r.id === row.id ? { ...r, key: e.target.value } : r))} />
                      <Input placeholder="Value" value={row.value} onChange={(e) => setTemplateRows((prev) => prev.map((r) => r.id === row.id ? { ...r, value: e.target.value } : r))} />
                      <Button type="button" className="bg-slate-500 hover:bg-slate-600" onClick={() => setTemplateRows((prev) => prev.length === 1 ? [{ id: crypto.randomUUID(), key: "", value: "" }] : prev.filter((r) => r.id !== row.id))}>Remove</Button>
                    </div>
                  ))}
                  <Button type="button" className="bg-slate-700 hover:bg-slate-800 dark:bg-slate-600 dark:hover:bg-slate-500" onClick={() => setTemplateRows((prev) => [...prev, { id: crypto.randomUUID(), key: "", value: "" }])}>Add Variable</Button>
                </div>
              )}
            </div>
          )}
        </section>

        <section className="rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-4">
          <h2 className="mb-3 text-base font-semibold">Step 5: Payload Preview & Send</h2>
          <div className="flex flex-wrap gap-2">
            <Button type="button" className="bg-slate-700 hover:bg-slate-800 dark:bg-slate-600 dark:hover:bg-slate-500" onClick={() => setShowPayload((s) => !s)}>{showPayload ? "Hide Preview" : "Show Preview"}</Button>
            <Button type="button" className="bg-slate-700 hover:bg-slate-800 dark:bg-slate-600 dark:hover:bg-slate-500" onClick={() => navigator.clipboard.writeText(JSON.stringify(openApiRequestPayload, null, 2)).then(() => toast.success("Payload copied"))}>Copy Payload</Button>
            <Button type="button" className="bg-slate-500 hover:bg-slate-600" onClick={() => {
              reset({ channel: "SMS", projectCode: assignedProjectCode, countryCode: "", eventCode: "", recipient: "", subject: "", body: "" });
              setTemplateRows([{ id: crypto.randomUUID(), key: "name", value: "Pavan" }, { id: crypto.randomUUID(), key: "otp", value: "123456" }]);
              setTemplateDataRaw('{\n  "name": "Pavan",\n  "otp": "123456"\n}');
              setShowHtmlPreview(false);
              setShowPayload(false);
              setResult(null);
            }}>Reset</Button>
            <Button type="submit" disabled={sendMutation.isPending || !canSend}>{sendMutation.isPending ? "Sending..." : "Send Test"}</Button>
          </div>

          {!step1Complete ? (
            <p className="mt-2 text-sm text-amber-600">Complete Step 1 to continue.</p>
          ) : missingStep3.length > 0 ? (
            <p className="mt-2 text-sm text-amber-600">Missing required fields: {missingStep3.join(", ")}</p>
          ) : null}

          {showPayload ? <pre className="mt-3 overflow-auto rounded-md border border-[var(--border-color)] bg-[var(--bg-secondary)] p-3 text-xs text-[var(--text-primary)]">{JSON.stringify(openApiRequestPayload, null, 2)}</pre> : null}
        </section>
      </form>

      {result ? (
        <section className="rounded-lg border border-[var(--border-color)] bg-[var(--card-bg)] p-4">
          <h2 className="mb-3 text-base font-semibold">Result</h2>
          <div className="grid gap-2 text-sm md:grid-cols-2">
            <div><span className="text-[var(--text-secondary)]">Status:</span> <span className={result.status === "FAILED" ? "font-semibold text-red-600" : "font-semibold text-emerald-600"}>{result.status}</span></div>
            <div><span className="text-[var(--text-secondary)]">Request ID:</span> {result.requestId}</div>
            <div><span className="text-[var(--text-secondary)]">Provider:</span> {result.provider}</div>
            <div><span className="text-[var(--text-secondary)]">Queue:</span> {result.queue}</div>
            <div><span className="text-[var(--text-secondary)]">Timestamp:</span> {result.timestamp}</div>
            {result.error ? <div className="md:col-span-2"><span className="text-[var(--text-secondary)]">Error:</span> <span className="text-red-600">{result.error}</span></div> : null}
          </div>
        </section>
      ) : null}
    </div>
  );
}
