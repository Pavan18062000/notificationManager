import { z } from "zod";

export const notificationSchema = z.object({
  name: z.string().min(2, "Name is required"),
  active: z.boolean().optional().default(true)
});

export type NotificationForm = z.infer<typeof notificationSchema>;

